#!/usr/bin/env python3
"""Bounded, read-only ZIP and JSON integrity audit; no extraction or execution."""
import argparse
import io
import json
import re
import stat
import zipfile
import zlib
from pathlib import Path


class Auditor:
    def __init__(self, limits):
        self.limits = limits
        self.findings = []
        self.members = 0
        self.bytes_read = 0
        self.json_files = 0
        self.archives = 0

    def issue(self, location, code, detail):
        self.findings.append({'location': location, 'code': code, 'detail': detail})

    def audit(self, source, label, depth=0):
        self.archives += 1
        with zipfile.ZipFile(source) as archive:
            infos = archive.infolist()
            if self.members + len(infos) > self.limits.max_members:
                self.issue(label, 'member_limit', 'Shared member count limit exceeded')
                return
            self.members += len(infos)
            targets = set()
            folded = set()
            target_kinds = {}
            for info in infos:
                name = info.filename
                location = label + '!' + name
                parts = name.replace('\\', '/').split('/')
                normalized = '/'.join(parts).rstrip('/')
                if (name.startswith(('/', '\\')) or re.match(r'^[A-Za-z]:', name)
                        or '\\' in name or any(x in ('.', '..') for x in parts)
                        or any(not x for x in parts[:-1])
                        or any(ord(c) < 32 for c in info.orig_filename)):
                    self.issue(location, 'unsafe_name', 'Unsafe or ambiguous archive path')
                if normalized in targets:
                    self.issue(location, 'duplicate_target', 'Repeated archive target')
                elif normalized.casefold() in folded:
                    self.issue(location, 'case_collision', 'Targets collide on case-insensitive filesystems')
                for part in parts:
                    if part and (':' in part or part.endswith((' ', '.'))
                                 or re.match(r'^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)', part, re.I)):
                        self.issue(location, 'nonportable_name', 'Member name is unsafe on Windows')
                        break
                key = normalized.casefold()
                parents = ['/'.join(key.split('/')[:i]) for i in range(1, len(key.split('/')))]
                if (any(parent in target_kinds and not target_kinds[parent] for parent in parents)
                        or (not info.is_dir() and any(old.startswith(key + '/') for old in target_kinds))
                        or (key in target_kinds and target_kinds[key] != info.is_dir())):
                    self.issue(location, 'target_conflict', 'File and directory extraction targets conflict')
                target_kinds[key] = info.is_dir()
                targets.add(normalized)
                folded.add(normalized.casefold())
                if stat.S_ISLNK(info.external_attr >> 16):
                    self.issue(location, 'symlink', 'Symbolic link member requires manual review')
                    continue
                if info.flag_bits & 1:
                    self.issue(location, 'encrypted', 'Encrypted member cannot be validated')
                    continue
                if info.is_dir():
                    if info.file_size:
                        self.issue(location, 'directory_payload', 'Directory member declares a nonempty payload')
                    continue
                if info.file_size > self.limits.max_member_bytes:
                    self.issue(location, 'member_size', 'Declared member size exceeds limit')
                    continue
                if self.bytes_read + info.file_size > self.limits.max_total_bytes:
                    self.issue(location, 'total_size', 'Shared decompressed byte budget exceeded')
                    continue
                if info.file_size / max(1, info.compress_size) > self.limits.max_ratio:
                    self.issue(location, 'compression_ratio', 'Declared compression ratio exceeds limit')
                    continue
                try:
                    with archive.open(info) as member:
                        data = member.read(info.file_size + 1)
                    self.bytes_read += len(data)
                    if len(data) != info.file_size:
                        self.issue(location, 'size_mismatch', 'Read size differs from declared size')
                        continue
                except (OSError, RuntimeError, NotImplementedError, zipfile.BadZipFile, EOFError, zlib.error) as exc:
                    self.issue(location, 'member_read', type(exc).__name__)
                    continue
                if name.lower().endswith('.json'):
                    self.json_files += 1
                    try:
                        def pairs(items):
                            result = {}
                            for key, value in items:
                                if key in result:
                                    raise ValueError('Duplicate JSON object key')
                                result[key] = value
                            return result
                        def constant(value):
                            raise ValueError('Non-finite JSON numeric literal')
                        json.loads(data.decode('utf-8-sig'), object_pairs_hook=pairs,
                                   parse_constant=constant)
                    except json.JSONDecodeError as exc:
                        self.issue(location, 'invalid_json', f'JSON syntax at line {exc.lineno}, column {exc.colno}')
                    except UnicodeDecodeError:
                        self.issue(location, 'invalid_json', 'JSON is not UTF-8')
                    except (ValueError, RecursionError) as exc:
                        self.issue(location, 'invalid_json', str(exc) if isinstance(exc, ValueError) else 'JSON nesting exceeds parser limit')
                if name.lower().endswith(('.zip', '.mcpack', '.mcaddon')):
                    if depth >= self.limits.max_depth:
                        self.issue(location, 'depth_limit', 'Nested archive depth exceeds limit')
                    else:
                        try:
                            self.audit(io.BytesIO(data), location, depth + 1)
                        except (OSError, zipfile.BadZipFile, EOFError, zlib.error) as exc:
                            self.issue(location, 'nested_archive', type(exc).__name__)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--max-member-bytes', type=int, default=64 * 1024 * 1024)
    parser.add_argument('--max-total-bytes', type=int, default=256 * 1024 * 1024)
    parser.add_argument('--max-members', type=int, default=10000)
    parser.add_argument('--max-ratio', type=int, default=200)
    parser.add_argument('--max-depth', type=int, default=3)
    args = parser.parse_args()
    if (min(args.max_member_bytes, args.max_total_bytes, args.max_members, args.max_ratio) <= 0
            or args.max_depth < 0):
        print(json.dumps({'ok': False, 'error': 'Limits must be positive; depth must be nonnegative'}))
        return 2
    auditor = Auditor(args)
    try:
        auditor.audit(args.archive, args.archive.name)
    except (OSError, zipfile.BadZipFile, EOFError, zlib.error) as exc:
        print(json.dumps({'ok': False, 'error': type(exc).__name__}))
        return 2
    print(json.dumps({'ok': not auditor.findings, 'archives': auditor.archives,
                      'members': auditor.members, 'bytes_read': auditor.bytes_read,
                      'json_files': auditor.json_files, 'findings': auditor.findings}, indent=2))
    return 1 if auditor.findings else 0


if __name__ == '__main__':
    raise SystemExit(main())
