# Security-related defect repair

Apply when evidence or the requested sweep reaches permission, untrusted input, file handling, network, credentials or sensitive data boundaries. Stay within the authorized project; do not probe unrelated live systems.

Trace actor → entry point → trust boundary → protected effect. Write the actual invariant, such as “only the entity owner may modify this record.” Validate on the authoritative side; hidden UI controls are not access control. Verify validation precedes effects and is repeated when time-of-check state can change.

| Boundary | Inspect | Isolated regression |
|---|---|---|
| Authorization | Ownership, tenant scope, revoked grants, object identifiers | Owner/non-owner, missing/revoked grant, cached decision |
| Parsing/injection | Structured parameters, shell/SQL/HTML context, type/size limits | Malformed and special-character corpus without live effects |
| Files/archives | Traversal, absolute paths, symlinks, duplicate targets, decompression limits | Sandbox fixture with hostile member names and bounded sizes |
| Credentials/logs | Source, errors, artifacts and diagnostics | Verify redaction and absence of secrets in generated output |
| Remote requests | Allowed destination, redirects, timeouts and response limits | Mock redirects, unavailable service and oversized response |
| Session/state | Expiry, replay, stale callbacks, cross-user caches | Controlled time and duplicate/stale operation |

Distinguish demonstrated exploitability from suspected weakness. Fix the trust boundary rather than only filtering one sample payload. Preserve useful errors without leaking internals. Do not broaden privileges, disable TLS/certificate checks or expose secrets as a workaround. If credentials are actually exposed, explain the evidence and the necessary rotation; do not claim that deleting a string revokes it.
