# Scoped bug sweeps

## Inventory and coverage

Define the actual revision, runtime and deliverable. List entry points, subsystems, data stores, external dependencies and representative journeys. Include install/import, first use, normal use, invalid input, restart/reload and recovery. Map reachable code and critical contracts; do not count files read as proof of behavior.

Use a compact coverage table: area | journey/boundary | inspection or executable check | result | gap. For a large project, prioritize by impact and exposure, then expand while the requested scope remains incomplete. Do not silently call a partial inspection complete.

## Audit surfaces

| Surface | Questions and useful checks |
|---|---|
| Inputs and contracts | Empty, malformed, missing, oversized, wrong units/types, stale versions; validate before effects |
| State and ownership | Illegal transitions, multiple writers, stale references, save/load equivalence, authority |
| Lifecycle | Create/destroy, pause/resume, reconnect, unload/reload, cancellation and late completion |
| Persistence | Partial commit, duplicate request, lost response, old reader/new writer, restore after interruption |
| Resources | Listener cleanup, queue caps, cache growth, task cancellation, file/socket closure |
| UI and controls | Disabled states, repeated taps, touch hit areas, async loading/error feedback, screen changes |
| Logic | Boundaries, integer/float conversion, overflow, deterministic seeds, timestep dependence |
| Integration | Dependency resolution, identifiers, linked resources, entry point, build and import |
| Permissions | Actor ownership and server authority, cross-user access, revoked access, cached decisions |
| Performance | Expensive hot path, repeated scanning, work amplification, frame spikes, low-memory behavior |

## Findings and batching

Record each actionable finding as:

`ID | impact | trigger | evidence | cause/status | repair | checks | remaining gap`

Rank impact: critical = exposed credential, severe corruption or uncontrolled destructive effect; high = core journey blocked or frequent serious loss; medium = recoverable incorrect behavior; low = limited annoyance. Adjust for actual exposure and likelihood, and avoid false numerical precision. Static suspicion without proof stays suspected regardless of severity.

Group symptoms with a shared cause. Repair correctness and data integrity before tuning their execution. Separate unrelated repairs so failures are attributable. Check coupled mechanisms after each batch: retries/effects, cancellation/cleanup, caching/permissions, pooling/identity, reload/authority and migrations/old readers.

Report confirmed and verified counts separately. Explain unresolved high-impact findings and what is needed to decide them. If no defects are found, report inspected boundaries and limitations without fabricating a repair.
