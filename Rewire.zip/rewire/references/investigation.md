# Investigate across boundaries

## Build a causal model

Record the trigger, first invalid state, propagation and visible failure. Write invariants in checkable terms: one owner per resource; committed effects never repeated; cache revision matches source; queues remain bounded; destroyed entities receive no callbacks.

For each hypothesis record supporting evidence, contradiction, cheapest falsification and confidence. Avoid numerical confidence without a basis. Seek counterexamples to the leading explanation. Separate mitigation from cause removal.

## Escalate deliberately

When two attempts fail for the same reason, revisit the model before another edit. Minimize the failing input; inspect actual runtime values; isolate the boundary with a fake or contract test; compare known-good revisions; verify tooling assumptions. Revert unsuccessful task-local experiments without disturbing user work.

Use a minimal reproduction that preserves ordering, resource ownership and external effects. Avoid reducing away the asynchronous boundary that triggers the defect. Diagnose tests and instrumentation if evidence conflicts.

## Interactions

Check paired mechanisms: retries plus side effects; caching plus authorization; cancellation plus cleanup; pooling plus mutable identity; parallelism plus ordering; migrations plus old readers; event duplication plus counters. Each mechanism can be correct alone and fail in combination.

For nondeterminism capture random seeds, logical time and event ordering where possible. Prefer controlled scheduling over arbitrary sleeps. Treat a single successful run as weak evidence for intermittent failures.
