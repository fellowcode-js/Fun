# Diagnostic playbook

Select experiments by failure class. Record predicted and observed outcomes before revising a hypothesis.

| Symptom | Collect | Experiment |
|---|---|---|
| Intermittent state failure | Event order, ownership, task IDs, before/after state | Control interleavings, cancellations and duplicate delivery |
| Memory growth | Retained owners, queue length, subscriptions | Repeat fixed workload and compare retention after cleanup |
| Slow or stalled work | Stage time, queue depth, tail latency, I/O waits | Vary one load dimension; separate service time from waiting |
| Lost/corrupt data | Commit boundaries and retry sequence | Interrupt each boundary; replay partial and duplicate operations |
| Runtime mismatch | Toolchain, resolved dependencies, manifests, logs | Isolate changed dependency and test supported target |
| Game/addon lifecycle bug | Spawn/despawn, world load, tick budget, identity | Reload, unload chunks, reconnect and repeat activation |

Reduce inputs without removing the trigger. Bisect only with a reliable reproduction and known-good revision. Prefer bounded structured tracing. Distinguish correlation from causation: slow work may expose a race rather than cause it.

For numerical failures, inspect units, overflow, conditioning, tolerance and bounds. For caches, distinguish key construction, invalidation, staleness and concurrent fill. For models and animations, inspect pivots, transform order, hierarchy, handedness and format contracts.

If blocked, preserve the reproduction, evidence and next discriminating experiment. Specify the missing capability; never report an unrun test as passing.

## Instrumentation with a purpose

Add only observations that distinguish current hypotheses: operation/correlation ID, logical order, owning task/entity, state revision, before/after transition, queue depth and elapsed stage time. Use monotonic clocks for duration; wall time is not a reliable ordering guarantee. Bound log volume, sample hot paths when appropriate, and remove temporary probes after verification. If logging changes the failure frequency, use controlled schedules or lower-overhead tracing and record the observer effect. Never include tokens, full user payloads or private saves merely to increase log detail.
