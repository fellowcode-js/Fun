# Advanced architecture choices

| Failure or limit | Candidate mechanism | Main constraint | Evidence required |
|---|---|---|---|
| State changes and notifications diverge | Transactional outbox/inbox | Atomic local persistence and deduplication | Crash between commit and delivery recovers without lost effects |
| Read-modify-write loses updates | Compare-and-swap with revision checks | Retry conflicts and revision semantics | Competing writers preserve every accepted update |
| Distributed lock survives old owner | Leases with fencing tokens | Downstream service must reject stale tokens | Expired owner cannot mutate guarded resources |
| Multi-stage external operation partially succeeds | Saga with compensations | Compensation can fail and may not fully reverse reality | Every interruption has an explicit reconciliation state |
| History must explain reconstructed state | Append-only events with validated reducers | Schema evolution, snapshots, operational cost | Replay yields equivalent state across supported schemas |
| Repeated global recomputation | Dependency graph and incremental invalidation | Cycles and invalidation correctness | Compare incremental results with full recomputation |
| Spatial scans exceed tick budget | Spatial partition or hierarchical index | Moving-object update cost and density | Compare queries with brute-force oracle |
| Cache refill spikes overload origin | Request coalescing and stale-while-revalidate | Staleness allowance and error behavior | Concurrent miss performs bounded origin work |
| Variable-cost jobs monopolize execution | Fair budgeted scheduler with aging | Preemption granularity | Bounded waiting under mixed workloads |
| Global mutable state couples modules | Explicit ownership and command/event boundaries | Migration effort, event ordering | Contracts prevent invalid cross-module writes |

Use structural upgrades only when simpler mechanisms fail requirements. Define durability, delivery, ordering, consistency and recovery semantics explicitly; do not claim exactly-once behavior without a scoped proof. Consider whether bounded staleness is acceptable before pursuing stronger consistency.

For rollout, keep old/new data compatibility explicit. Define success metrics and rollback triggers. Do not dual-run side effects. Prefer additive schema migration before removal; verify restore and recovery paths on isolated data.
