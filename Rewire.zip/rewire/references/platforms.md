# Platform-specific investigation

## Games and simulations

Trace input sampling, logical state, physics, animation and rendering separately. Check coordinate spaces, units, timestep dependence, determinism and entity lifetime. Simulate pause/resume, scene transitions, despawn and late callbacks. Measure per-frame or tick budgets; average FPS can hide severe spikes.

## Minecraft Bedrock addons

Read manifest and script dependency versions first. Verify APIs against the intended engine release. Inspect behavior/resource pack linkage, identifiers, format versions, component contracts and animation/controller references. Distinguish static pack validation from an in-game import and play test. Check chunk unload, world reload, multiplayer authority and entity validity around deferred tasks. Never pretend unsupported engine capabilities are native.

### Bedrock pack and script checks

Trace item/block/entity identifiers through behavior definitions, resource definitions, texture atlases, geometry, animation controllers, recipes and script lookups. Check names and casing against actual files. Preserve stable identifiers and pack UUIDs for updates; regenerate identifiers only for an intentionally distinct pack. Inspect pack dependency UUID/version alignment and the installed script API, including stable versus experimental requirements.

Inspect event subscriptions, deferred callbacks, invalid entities, dimension changes, unloaded chunks and world persistence. Bound per-tick scans and deferred queues. Check multiplayer ownership and authority for inventory, territory and combat changes. Keep simulation state separate from visible entities when unloaded-world behavior is required; do not promise arbitrary custom vehicle physics without engine support.

Audit `.mcaddon`/`.mcpack` nesting and validate the delivered archive rather than only its source directory. JSON parsing and reference inspection do not prove component validity or in-game compatibility. State which import, Content Log, world reload and multiplayer checks were actually run.

## Android and JVM projects

Inspect Gradle, SDK levels, Java/Kotlin targets, build variants and resolved libraries. Investigate UI-thread work, lifecycle cancellation, permission changes, process death and resource cleanup. Preserve user language/toolchain choices. Distinguish successful compilation from device behavior and do not claim APK validation without actually producing/checking it.

## Models and asset pipelines

Trace source geometry through export, rig, animation and import. Check transform conventions, scale, pivots, hierarchy, weights, UV seams and material references. Verify representative animations in the target viewer when available. Do not fix a rig problem solely by deforming geometry.

## APIs and packaged tools

Check contracts, schemas, errors, timeout/retry semantics, backpressure and cancellation. For archives validate expected paths, manifests, referenced resources and entry points. Never increase archive size with filler. Verify extraction and startup when feasible; report missing runtimes honestly.
