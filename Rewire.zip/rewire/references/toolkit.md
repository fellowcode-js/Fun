# Read-only archive auditor

Run `python <skill-root>/scripts/audit_archive.py <archive>` for ZIP, `.mcpack` and `.mcaddon` distributions. Replace `<skill-root>` with this skill's actual installed directory. The script never extracts or executes content.

It reports a JSON result and returns 0 when its checks pass, 1 for audit findings, or 2 for an unreadable archive/invalid limits. It checks unsafe or ambiguous names, duplicate/case-colliding targets, file/directory conflicts, Windows-unsafe names, symlinks, encrypted members, declared member/total sizes, excessive compression ratios, bounded member reads/CRC and UTF-8 JSON syntax. Nested archives are audited with shared byte/member limits and a depth cap. Defaults are conservative; change limits only with workload evidence. Unsafe sizes are rejected before content is read.

Examples:

```bash
python <skill-root>/scripts/audit_archive.py release.mcaddon
python <skill-root>/scripts/audit_archive.py release.zip --max-total-bytes 268435456
```

This is an archive-integrity and JSON-syntax check. It does not validate engine schemas, identifier references, JavaScript, malicious payloads, pack linkage or runtime behavior. A finding may be a packaging defect or an intentional portability tradeoff; inspect it before modifying files. Do not add JSON comments support to hide malformed strict JSON.

The limits bound member reads and nested work, not the memory used by Python to parse the ZIP central directory before checking member count. Use an external process memory/time limit when auditing adversarial archives. JSON numeric range and application-level schemas remain unchecked; valid exponent syntax can exceed a target runtime's finite number range. Passing this script is not a security certification or permission to extract arbitrary archives.
