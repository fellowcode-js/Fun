# Prove the repair

## Select checks by risk

| Change | Strong check |
|---|---|
| Pure algorithm | Differential oracle plus generated edge inputs |
| State machine | Transition coverage and invariants after every transition |
| Persistence | Restart/interruption at each write boundary |
| Concurrent ownership | Controlled interleavings, duplicate delivery, cancellation |
| Parser or importer | Valid/invalid corpus, round trips, malformed boundaries |
| Cache | Cold/warm equivalence, invalidation, concurrent miss |
| Performance | Equivalent output and repeated baseline/candidate workloads |
| Platform integration | Build plus actual target exercise when available |

Use metamorphic properties when no oracle exists: permutation invariance when ordering is irrelevant; idempotence where promised; round-trip fidelity; conservation; monotonicity under specified conditions. Check that the property actually belongs to the domain.

## Failure injection

In local or isolated fixtures, inject timeout before and after commit, dropped response, duplicate event, stale callback, partial write, full queue, dependency unavailability and process restart. Assert bounded resources and explicit recovery states. Restore fixture state after each run.

## Benchmark discipline

Record workload, environment, configuration and sample count. Warm up when relevant; report variability and tail behavior rather than one fastest sample. Include correctness, peak memory and regression in other workloads. Mark synthetic results and avoid extrapolating to untested targets. Use existing profiling tools before inventing instrumentation.

## Completion gates

Confirm the original defect is addressed, relevant regressions pass, introduced dependencies resolve, changed contracts are documented where needed and temporary debug paths are removed. List unavailable target checks. Distinguish observed behavior from predictions.

## Evidence and acceptance

Define the acceptance condition before choosing the check. Prefer externally observable behavior over implementation details. Validate the regression itself: a passing test on both original and repaired code does not demonstrate that repair. Use an independent oracle or explicit invariants when the implementation could contain the same mistake as the test. Record a seed for generated failures and minimize the input without losing the trigger.

For numerical or simulation changes, check units, finite values, tolerance relative to scale, conservation where promised, and behavior across relevant timesteps. For recovery, distinguish a safe explicit failure from silent data loss. For cancellation, assert no late mutation and correct release of owned resources.

Label evidence precisely: inspected, reproduced, fixed but unverified, verified under the listed checks, blocked, or deferred. A build verifies compilation and packaging for that build target; it does not establish touch behavior, multiplayer correctness or real-device performance. An unrelated pre-existing failure remains visible and does not become evidence against or for the repair without tracing its connection.
