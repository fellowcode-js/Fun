# Select stronger systems

Match mechanisms to demonstrated failures rather than novelty.

| Weakness | Candidate | Tradeoff | Verification |
|---|---|---|---|
| Conflicting lifecycle transitions | Guarded state machine | Migration complexity | Reject illegal transitions; preserve valid paths |
| Racing writers | Single owner, serialization or transactions | Contention or throughput limits | Controlled interleavings preserve invariants |
| Duplicate side effects | Idempotency keys and operation results | Key scope and retention | Repeated requests apply effects once |
| Partial writes | Atomic commits, journaling, recovery protocol | Storage/recovery complexity | Interrupt at each boundary and recover |
| Producer overload | Bounded queues and backpressure | Rejection or throughput reduction | Bounded memory and explicit overload behavior |
| Cascading remote failure | Deadlines, bounded jittered retries, circuit breaker | Recovery delays, retry amplification | Failure injection respects budgets |
| Stale derived state | Dependency-aware invalidation or revisioned cache | Tracking overhead | Mutations invalidate dependents |
| Repeated expensive work | Batching, indexing, memoization, incremental compute | Maintenance and staleness | Equivalent output and measured improvement |
| Frame/tick spikes | Budgeted scheduler, amortized work | Delayed completion | Budget compliance without starvation |
| Unloaded-world simulation loss | Virtual state and explicit materialization | Identity/reconciliation complexity | Reload preserves identity and outcomes |
| Platform assumptions | Adapters and capability checks | Indirection | Target contract tests |
| Hidden recurring failures | Structured events and invariant monitoring | Overhead/privacy | Diagnose without leaking secrets |

Compare correctness, latency, memory, compatibility, failure containment, maintenance and effort. Mark estimates and measure claims. Prefer focused repairs that remove the cause.

For broad migration, establish contracts, introduce an adapter, validate equivalence, migrate callers, then retire old code. Use shadow evaluation only when it cannot duplicate side effects. Make rollback concrete, including data compatibility after new writes.

Avoid infinite retries, unbounded queues, caches without invalidation, speculative microservices and rewrites driven solely by preference.
