# Performance and resource diagnosis

## Establish a budget

Identify the user's workload and limiting metric: frame/tick time, response tail latency, throughput, startup, peak memory, battery or sustained retention. Use the real target where available. Capture configuration, input size, concurrency, versions and baseline samples. Keep correctness checks attached to benchmarks.

Profile before optimizing. Decompose waiting, execution, allocation, garbage collection, rendering and I/O. A slow dependency, queue delay and CPU-bound loop need different repairs. Do not infer a memory leak solely from process RSS; inspect retained owners or repeated growth after realistic cleanup.

## Distinguishing experiments

| Observation | Experiment | Candidate if confirmed |
|---|---|---|
| Cost grows with all entities every tick | Vary total versus active entities; profile queries | Spatial index or active-set processing |
| Burst causes queue growth | Fix service rate; vary arrival burst | Bound queues, coalesce safe work, explicit overload |
| Repeated identical computation | Count calls and source revisions | Memoization with correct invalidation |
| Allocation/GC spikes | Compare allocation profiles on same journey | Reuse with explicit ownership; reduce temporaries |
| Startup dominated by eager work | Time stages; test deferred path and first interaction | Lazy initialization with predictable loading |
| Retention rises after scene changes | Repeat transitions; inspect listeners/tasks/owners | Dispose resources and cancel owned work |
| Cache stampede | Concurrent cold requests with counters | Coalesced fills; bounded cache and expiry |

Prefer algorithmic improvements over micro-optimizations. Define staleness, fairness and completion guarantees for amortized work. Do not trade correctness, simulation outcomes or accessibility for a faster number without making the behavior change explicit.

## Compare fairly

Run baseline and candidate under equivalent conditions with multiple samples; alternate order when drift matters. Separate warm and cold behavior. Report median and tail metrics when meaningful, sample count and variability; tiny samples do not establish stable percentiles. Include peak memory and a workload that could regress. Label synthetic or desktop-only results.

Define an acceptance threshold from requirements rather than choosing it after seeing results. If no measurable gain appears, reconsider or remove the optimization. A tenfold speedup in one microbenchmark does not establish a tenfold faster application.
