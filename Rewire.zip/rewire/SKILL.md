---
name: rewire
description: Diagnose and repair complex software failures, run scoped bug sweeps, remove root causes, measure performance, and strengthen weak systems with verified changes. Use for crashes, recurring bugs, races, leaks, corruption, lag, broken integrations, security defects, architectural weaknesses, and full bug sweeps in games, Minecraft Bedrock addons, Android apps, APIs, websites and packaged tools. Also use when explicitly invoked as Rewire.
---

# Rewire

Deliver evidence-backed repairs that preserve intended behavior. Interpret requests such as “stronger” or “10x better” as higher quality, coverage and robustness; claim a numerical gain only after measuring it. Use the smallest workflow that resolves the uncertainty and meets the user's scope.

## 1. Establish scope and acceptance

Inspect actual source, project instructions, user changes, runtime/toolchain, dependency locks, build configuration, entry points and existing checks. Identify the authoritative project and version before changing it; do not silently edit a stale export. Preserve unrelated work.

Respect diagnosis-only, suggestions-only, repair, or repair plus improvement mode. For repair requests, continue through implementation and delivery within authorization. Do not stop at a plan. Ask only for missing facts that block dependent work; progress on independent work meanwhile.

State the trigger, expected behavior, observed behavior, constraints and a checkable acceptance condition. Separate confirmed defects, provisional hypotheses, environment failures and optional improvements. Establish a baseline before edits when feasible. Do not invent defects when inspection finds none.

Choose depth:

| Situation | Path |
|---|---|
| Local, deterministic defect | Reproduce, trace violated invariant, focused repair, relevant checks |
| Intermittent, cross-system or recurring defect | Ownership map, evidence ledger, controlled experiments, recovery verification |
| Full bug sweep | Scope inventory, risk-ranked findings, representative journeys, repair batches and coverage report |
| Lag or resource growth | Profile baseline, isolate bottleneck, preserve correctness, repeat equivalent workloads |
| Major subsystem upgrade | Contracts and measurable goals, compare designs, staged migration and rollback |

Read only the references needed for the selected path; do not impose every technique on a small fix.

## 2. Reproduce and trace the causal chain

Capture the smallest representative reproduction: exact invocation/input, expected/actual output, revision, configuration, versions and relevant logs. Preserve seeds, logical time and event order when applicable. If runtime access is missing, use static evidence and say the failure was not reproduced.

Trace trigger → first violated invariant → propagation → symptom. Inspect actual values across input parsing, ownership, state transitions, async boundaries, persistence and outputs. Separate upstream causes from downstream symptoms. Map writers, resource lifetime, authority and failure recovery for difficult cases.

Maintain a compact evidence ledger for competing explanations: supporting observation, contradiction, next distinguishing experiment and status. Predict results before running the experiment. Prefer the cheapest experiment that can reject a plausible cause. Do not treat correlation, a successful retry or an exception location as causal proof.

Confirm the cause with a failing regression, trace, controlled interleaving or comparable evidence. Seek a counterexample. When two experiments or repair attempts fail on the same assumption, stop patching and revisit the model, reproduction, tooling and alternatives. Undo only unsuccessful task-local changes.

Read [investigation.md](references/investigation.md) for stalled or cross-boundary diagnosis and [diagnostics.md](references/diagnostics.md) for failure-specific experiments.

## 3. Sweep systematically when requested

Read [sweep.md](references/sweep.md). Inventory reachable subsystems and representative user journeys before auditing. Rank by impact, exposure and evidence; inspect high-risk boundaries first. Track findings as confirmed, suspected, repaired, verified, deferred or blocked. Consolidate duplicate symptoms under one cause.

Repair confirmed defects in coherent batches; recheck affected interactions after each batch. Record areas inspected and areas not exercised. “Full sweep” describes the declared coverage, never a guarantee that all bugs are gone. Treat feature requests separately from defect findings while completing both when authorized.

## 4. Select and implement the repair

Choose the least complex design that satisfies the invariant and acceptance conditions. Compare a focused repair with one or two structural alternatives only when evidence shows a recurring design weakness. Explain causal benefit, compatibility, complexity, resource cost and new failure modes. Preserve public contracts, saved data, identifiers and delivery format unless a change is required and authorized.

Prefer explicit ownership, guarded transitions, bounded queues, deadlines, meaningful errors and recoverable persistence. Implement one coherent path; remove superseded code when safe. Search sibling call sites and variants for the same violated assumption. Do not introduce a dependency, service or rewrite solely for novelty.

Verify unfamiliar or current APIs against official documentation and installed versions. For an unfamiliar algorithm or structural mechanism, consult primary research when needed; check dependency licensing, maintenance, platform restrictions and migration cost before adoption. Record unverified compatibility if that access is unavailable. Never invent engine features or performance claims.

Read [system-designs.md](references/system-designs.md) for common mechanisms and [architecture.md](references/architecture.md) for distributed or incremental systems. Define rollout signals and rollback conditions for broad changes, including compatibility with newly written data. Avoid duplicating effects during shadow comparisons.

Never hide exceptions, weaken assertions or tests, disable validation, return fake success, reset user data, or use infinite retries to make checks pass. Redact secrets and personal data from diagnostic outputs. Keep fault injection and destructive recovery exercises in isolated fixtures, within authorized scope.

## 5. Verify claims at the appropriate level

Run the original reproduction after the change. Where feasible, show the regression fails against the original behavior and passes after repair without changing its assertion. Check relevant edges, affected integration contracts and neighboring behavior. Use controlled scheduling for races; do not replace a race with an arbitrary sleep.

Select tests from [verification.md](references/verification.md): trusted oracles, meaningful properties, state transitions, restart recovery, duplicate delivery, malformed inputs or controlled faults. Diagnose failing tests rather than deleting them. Add tests that protect behavior, not tests that merely mirror implementation. Keep verification proportional to risk.

For lag or memory work, read [performance.md](references/performance.md). Compare equivalent workloads, configuration and environment; include correctness and regressions. Report sample count, variability and relevant latency, frame time or retention metrics. Estimates remain estimates.

For input, permission or secret-handling defects, read [security.md](references/security.md). For target-specific checks, read [platforms.md](references/platforms.md). Distinguish source inspection, static validation, automated tests, built-package checks and actual runtime/device/game checks; one does not prove the others.

Stop expanding checks once relevant gates pass unless new evidence warrants more. If a required target is unavailable, complete feasible checks, deliver the concrete changes and clearly state the outstanding target verification; do not imply a confirmed fix for an unresolved failure.

## 6. Inspect and deliver

Review the final diff for unrelated edits, duplicate paths, stale comments, debug instrumentation, accidental secrets and unresolved findings. Validate the actual deliverable, including manifests, references and packaging; avoid filler files. For ZIP-based distributions, optionally run `python <skill-root>/scripts/audit_archive.py <archive>` as described in [toolkit.md](references/toolkit.md). This read-only audit is not a substitute for platform schema or runtime checks.

Report outcome first: what changed, the causal explanation, executed checks and material limits. Separate completed changes from suggestions. Rank at most three optional improvements by evidence, expected impact and effort; omit speculative lists. For sweeps report severity counts and coverage gaps. Never label an unrun test passing or a suspected issue confirmed.

When work spans sessions, preserve a concise project-local checkpoint if appropriate using [continuity.md](references/continuity.md). Record evidence and next experiments, not secrets or unsupported conclusions. Follow the environment's saving and publication requirements for the actual project.
