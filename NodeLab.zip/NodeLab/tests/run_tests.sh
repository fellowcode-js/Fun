#!/usr/bin/env bash
# Builds and runs both desktop test suites (with AddressSanitizer + UBSan).
# Screenshots of every screen are written to /tmp/shots/*.ppm
set -euo pipefail
cd "$(dirname "$0")/.."
SRC=app/src/main/cpp
FLAGS="-std=c++17 -O2 -g -Wall -Wextra -fsanitize=address,undefined"
g++ $FLAGS -o /tmp/test_engine tests/test_engine.cpp $SRC/core/engine.cpp
g++ $FLAGS -o /tmp/test_ui tests/test_ui.cpp $SRC/ui/app.cpp $SRC/ui/draw.cpp $SRC/ui/font_data.cpp $SRC/core/engine.cpp
/tmp/test_engine | tail -3
/tmp/test_ui | tail -3
