// Desktop tests for the NodeLab engine. Build: see tests/run_tests.sh
#include <cmath>
#include <cstdio>
#include <string>

#include "../app/src/main/cpp/core/engine.h"

using namespace nl;

static int failures = 0;
#define CHECK(cond, msg)                                  \
  do {                                                    \
    if (!(cond)) {                                        \
      std::printf("FAIL: %s  (%s)\n", msg, #cond);        \
      ++failures;                                         \
    } else {                                              \
      std::printf("ok:   %s\n", msg);                     \
    }                                                     \
  } while (0)

static void testForwardMath() {
  Network n;
  int a = n.addNode(Kind::Input, 0, 0), b = n.addNode(Kind::Input, 0, 0);
  int h = n.addNode(Kind::Hidden, 0, 0);
  int o = n.addNode(Kind::Output, 0, 0);
  n.nodes[n.nodeIndex(h)].act = Act::Linear;
  n.nodes[n.nodeIndex(o)].act = Act::Linear;
  n.connectWithWeight(a, h, 2.f);
  n.connectWithWeight(b, h, -1.f);
  n.connectWithWeight(h, o, 3.f);
  n.nodes[n.nodeIndex(h)].bias = 0.5f;
  n.nodes[n.nodeIndex(o)].bias = 1.f;
  n.setInputs({1.f, 4.f});
  n.forward();
  // h = 2*1 - 1*4 + 0.5 = -1.5 ; o = 3*-1.5 + 1 = -3.5
  CHECK(std::fabs(n.nodes[n.nodeIndex(h)].value + 1.5f) < 1e-6f, "hidden node math");
  CHECK(std::fabs(n.outputs()[0] + 3.5f) < 1e-6f, "output node math");
}

static void testConnectRules() {
  Network n;
  int i = n.addNode(Kind::Input, 0, 0), h1 = n.addNode(Kind::Hidden, 0, 0), h2 = n.addNode(Kind::Hidden, 0, 0),
      o = n.addNode(Kind::Output, 0, 0);
  std::string err;
  CHECK(n.connect(i, h1), "input -> hidden allowed");
  CHECK(n.connect(h1, h2), "hidden -> hidden allowed");
  CHECK(!n.connect(h2, h1, &err) && err.find("loop") != std::string::npos, "loop rejected");
  CHECK(!n.connect(h1, h1), "self loop rejected");
  CHECK(!n.connect(h1, i), "wire into input rejected");
  CHECK(!n.connect(o, h1), "wire out of output rejected");
  CHECK(!n.connect(i, h1), "duplicate rejected");
  CHECK(n.removeNode(h1) && n.edges.empty(), "removing node removes its wires");
}

static void testGradient() {
  // numeric gradient check on a net with every activation type
  Network n = makeLayered({2, 3, 2}, Act::Tanh, Act::Sigmoid, 42);
  n.nodes[1].act = Act::Sigmoid;  // second input is linear by default; irrelevant
  int hidden = n.nodeIndex(3);
  n.nodes[hidden].act = Act::LeakyReLU;
  n.nodes[n.nodeIndex(4)].act = Act::Linear;
  n.setInputs({0.3f, -0.7f});
  std::vector<float> target = {0.2f, 0.9f};
  for (LossKind lk : {LossKind::MSE, LossKind::MAE}) {
    n.forward();
    std::vector<float> gW(n.edges.size(), 0.f), gB(n.nodes.size(), 0.f);
    n.backward(target, lk, gW, gB);
    double worst = 0;
    auto lossNow = [&]() {
      n.forward();
      std::vector<float> o = n.outputs();
      double s = 0;
      for (size_t k = 0; k < o.size(); ++k) {
        double d = o[k] - target[k];
        s += (lk == LossKind::MSE ? d * d : std::fabs(d)) / o.size();
      }
      return s;
    };
    const float eps = 1e-3f;
    for (size_t e = 0; e < n.edges.size(); ++e) {
      float w0 = n.edges[e].w;
      n.edges[e].w = w0 + eps;
      double lp = lossNow();
      n.edges[e].w = w0 - eps;
      double lm = lossNow();
      n.edges[e].w = w0;
      double num = (lp - lm) / (2 * eps);
      worst = std::max(worst, std::fabs(num - gW[e]));
    }
    for (size_t i = 0; i < n.nodes.size(); ++i) {
      if (n.nodes[i].kind == Kind::Input) continue;
      float b0 = n.nodes[i].bias;
      n.nodes[i].bias = b0 + eps;
      double lp = lossNow();
      n.nodes[i].bias = b0 - eps;
      double lm = lossNow();
      n.nodes[i].bias = b0;
      double num = (lp - lm) / (2 * eps);
      worst = std::max(worst, std::fabs(num - gB[i]));
    }
    std::printf("      worst gradient error (%s): %g\n", lossName(lk), worst);
    CHECK(worst < 2e-3, lk == LossKind::MSE ? "backprop matches numeric gradient (MSE)" : "backprop matches numeric gradient (MAE)");
  }
}

static void testPresetsTrain() {
  std::vector<Preset> ps = builtinPresets();
  CHECK(ps.size() >= 6, "built-in presets exist");
  for (Preset& p : ps) {
    std::string err;
    bool ok = datasetCompatible(p.net, p.data, &err);
    CHECK(ok, (p.name + " data matches network").c_str());
    Trainer t;
    float first = t.evaluate(p.net, p.data, p.cfg.loss);
    while (!t.finished(p.cfg)) t.epoch(p.net, p.data, p.cfg);
    float last = t.evaluate(p.net, p.data, p.cfg.loss);
    std::printf("      %-10s loss %.5f -> %.6f in %d epochs%s\n", p.name.c_str(), first, last, t.epochsDone,
                t.diverged ? " DIVERGED" : "");
    CHECK(!t.diverged && last < 0.01f && last < first, (p.name + " trains to low loss").c_str());
  }
  // XOR should actually classify
  Preset x = ps[0];
  Trainer t;
  while (!t.finished(x.cfg)) t.epoch(x.net, x.data, x.cfg);
  bool right = true;
  for (size_t i = 0; i < x.data.rows(); ++i) {
    x.net.setInputs(x.data.X[i]);
    x.net.forward();
    right &= (x.net.outputs()[0] > 0.5f) == (x.data.Y[i][0] > 0.5f);
  }
  CHECK(right, "XOR classified correctly after training");
}

static void testOptimizers() {
  for (OptKind o : {OptKind::SGD, OptKind::Momentum, OptKind::Adam}) {
    Preset p = builtinPresets()[4];  // line fit
    p.cfg.opt = o;
    p.cfg.lr = o == OptKind::Adam ? 0.05f : (o == OptKind::Momentum ? 0.02f : 0.2f);
    p.cfg.epochs = 4000;
    p.cfg.targetLoss = 0.f;
    p.cfg.batch = 3;
    Trainer t;
    while (!t.finished(p.cfg)) t.epoch(p.net, p.data, p.cfg);
    float l = t.evaluate(p.net, p.data, p.cfg.loss);
    std::printf("      %-8s final loss %.7f\n", optName(o), l);
    CHECK(l < 1e-3f && !t.diverged, (std::string(optName(o)) + " optimizer converges (mini-batch)").c_str());
  }
}

static void testDivergence() {
  Preset p = builtinPresets()[4];
  p.cfg.opt = OptKind::SGD;
  p.cfg.lr = 1e9f;
  p.cfg.epochs = 200;
  p.cfg.targetLoss = 0;
  Trainer t;
  while (!t.finished(p.cfg)) t.epoch(p.net, p.data, p.cfg);
  // gradient clipping keeps it finite, or divergence is flagged: never a silent NaN
  bool finite = true;
  for (auto& e : p.net.edges) finite &= std::isfinite(e.w);
  CHECK(!finite ? t.diverged : true, "absurd learning rate never leaves a silent NaN");
  p.net.sanitize();
  bool ok = true;
  for (auto& e : p.net.edges) ok &= std::isfinite(e.w);
  CHECK(ok, "sanitize() leaves finite weights");
}

static void testSerialization() {
  Preset p = builtinPresets()[3];
  p.name = "My | odd\nname";
  p.cfg.shuffle = false;
  p.cfg.batch = 2;
  Preset q;
  std::string err;
  bool ok = deserializePreset(serializePreset(p), q, &err);
  CHECK(ok, "preset round trip parses");
  CHECK(q.net.nodes.size() == p.net.nodes.size() && q.net.edges.size() == p.net.edges.size(), "node/edge counts survive");
  bool same = true;
  for (size_t i = 0; i < p.net.edges.size(); ++i) same &= std::fabs(p.net.edges[i].w - q.net.edges[i].w) < 1e-7f;
  CHECK(same, "weights survive exactly");
  CHECK(q.data.rows() == p.data.rows() && q.data.Y[3] == p.data.Y[3], "dataset survives");
  CHECK(q.cfg.batch == 2 && !q.cfg.shuffle && q.cfg.opt == p.cfg.opt, "trainer settings survive");
  CHECK(q.name.find('|') == std::string::npos && q.name.find('\n') == std::string::npos, "name is cleaned");
  CHECK(q.net.nextId == p.net.nextId, "id counter restored");
  q.net.addNode(Kind::Hidden, 0, 0);
  CHECK(q.net.nodeIndex(q.net.nextId - 1) >= 0, "new node ids don't collide after load");

  std::vector<Preset> many = {p, builtinPresets()[0]};
  CHECK(deserializePresets(serializePresets(many)).size() == 2, "multi-preset file round trip");
  CHECK(deserializePresets("garbage\nmore garbage").empty(), "garbage input gives no presets");
  Preset bad;
  CHECK(!deserializePreset("NODELAB 1\nnode x y z\nEND\n", bad), "corrupt node line rejected");
  CHECK(deserializePreset("NODELAB 1\nname t\nnode 1 0 0 0 0 0 0\nedge 1 99 0.5\nEND\n", bad) && bad.net.edges.empty(),
        "dangling edge dropped on load");

  std::vector<TrainerCfg> tv = builtinTrainers();
  std::vector<TrainerCfg> tr = deserializeTrainers(serializeTrainers(tv));
  CHECK(tr.size() == tv.size() && tr[1].opt == tv[1].opt && std::fabs(tr[2].momentum - tv[2].momentum) < 1e-7f,
        "trainer list round trip");
}

static void testRobustLoad() {
  // A diverged (NaN) network must still save into a file that loads again.
  Preset p = builtinPresets()[0];
  p.net.edges[0].w = NAN;
  p.net.nodes[3].bias = INFINITY;
  Preset q;
  std::string err;
  CHECK(deserializePreset(serializePreset(p), q, &err), "NaN/inf weights still produce a loadable save");
  CHECK(q.net.edges[0].w == 0.f && q.net.nodes[3].bias == 0.f, "non-finite values are saved as 0");
  Preset bad;
  CHECK(!deserializePreset("NODELAB 1\nnode 1 0 0 0 0 0 0\nnode 1 1 1 0 0 0 0\nEND\n", bad), "duplicate node ids rejected");
  CHECK(!deserializePreset("NODELAB 1\nnode -5 0 0 0 0 0 0\nEND\n", bad), "negative node id rejected");
  CHECK(!deserializePreset("NODELAB 1\nnode 2000000000 0 0 0 0 0 0\nEND\n", bad), "huge node id rejected (no giant allocation)");
  CHECK(deserializeTrainers("trainer x|0|0|0.1|0.9|0|0|1|0.001\n").empty(), "trainer with 0 epochs rejected");
  CHECK(deserializeTrainers("trainer x|0|0|0.1|0.9|10|-3|1|0.001\n").empty(), "trainer with negative batch rejected");
  CHECK(deserializeTrainers("trainer x|0|0|0.1|0.9|10|0|1|0.001\n").size() == 1, "valid trainer line accepted");
}

static void testFastPaths() {
  Network n = makeLayered({3, 5, 2}, Act::Tanh, Act::Sigmoid, 9);
  std::vector<float> in = {0.2f, -0.4f, 0.9f};
  n.setInputs(in);
  n.forward();
  std::vector<float> ref = n.outputs();
  n.setInputsRaw(in.data(), in.size());
  n.forward();
  CHECK(n.inputCount() == 3 && n.outputCount() == 2, "raw io counts");
  CHECK(n.outputValue(0) == ref[0] && n.outputValue(1) == ref[1], "raw io matches vector io");
  std::vector<float> p = n.getParams();
  CHECK(p.size() == n.edges.size() + 5 + 2, "params = edges + non-input biases");
  Network m = n;
  for (float& v : p) v += 0.1f;
  m.setParams(p);
  m.setInputs(in);
  m.forward();
  CHECK(std::fabs(m.outputs()[0] - ref[0]) > 1e-4f, "setParams changes the output");
  m.setParams(n.getParams());
  m.forward();
  CHECK(std::fabs(m.outputs()[0] - ref[0]) < 1e-7f, "params round trip is exact");
  // editing topology invalidates the cache correctly
  int extra = n.addNode(Kind::Hidden, 0, 0);
  n.connect(n.inputIds()[0], extra);
  n.connect(extra, n.outputIds()[0]);
  n.setInputsRaw(in.data(), in.size());
  n.forward();
  CHECK(n.outputValue(0) != ref[0], "new node feeds the output after topology change");
  // big layers lay out as a block, not a 3000dp column
  Network big = makeLayered({64, 8, 3}, Act::Tanh, Act::Sigmoid, 1);
  float minY = 1e9f, maxY = -1e9f;
  for (auto& nd : big.nodes) {
    minY = std::min(minY, nd.y);
    maxY = std::max(maxY, nd.y);
  }
  CHECK(maxY - minY < 500.f, "64-node layer is laid out as a compact grid");
}

static void testCheck() {
  Network n;
  CHECK(n.check().size() == 2, "empty network reports missing input/output");
  Preset p = builtinPresets()[0];
  CHECK(p.net.check().empty(), "preset network is healthy");
  p.net.edges[0].w = NAN;
  CHECK(!p.net.check().empty(), "NaN weight is reported");
  CHECK(p.net.sanitize() && p.net.check().empty(), "auto-fix clears it");
}

static void testDataset() {
  Dataset d;
  d.addRow(2, 1);
  d.addRow(2, 1);
  d.resizeCols(3, 2);
  CHECK(d.X[0].size() == 3 && d.Y[1].size() == 2, "dataset columns resize");
  d.removeRow(0);
  CHECK(d.rows() == 1, "dataset row removal");
  Network n = makeLayered({2, 1}, Act::Tanh, Act::Sigmoid, 1);
  std::string err;
  CHECK(!datasetCompatible(n, d, &err) && !err.empty(), "mismatched dataset is rejected with a message");
}

int main() {
  testForwardMath();
  testConnectRules();
  testGradient();
  testPresetsTrain();
  testOptimizers();
  testDivergence();
  testSerialization();
  testRobustLoad();
  testFastPaths();
  testCheck();
  testDataset();
  std::printf("\n%s (%d failures)\n", failures ? "SOME TESTS FAILED" : "ALL ENGINE TESTS PASSED", failures);
  return failures ? 1 : 0;
}
