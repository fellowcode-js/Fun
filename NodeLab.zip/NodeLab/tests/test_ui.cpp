// Desktop UI tests: drives the real App with simulated touches, rasterizes the exact
// triangle list the Android GLES renderer would draw, and writes PPM screenshots.
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

#include "../app/src/main/cpp/ui/app.h"
#include "../app/src/main/cpp/ui/font_data.h"

using namespace nl;

static int failures = 0;
#define CHECK(cond, msg)                              \
  do {                                                \
    if (!(cond)) {                                    \
      std::printf("FAIL: %s  (%s)\n", msg, #cond);    \
      ++failures;                                     \
    } else {                                          \
      std::printf("ok:   %s\n", msg);                 \
    }                                                 \
  } while (0)

struct Canvas {
  int w, h;
  std::vector<float> px;  // rgb
  Canvas(int W, int H) : w(W), h(H), px(static_cast<size_t>(W) * H * 3, 0.f) {}
};

static float atlasAlpha(float u, float v) {
  float x = u * FONT_ATLAS_W - 0.5f, y = v * FONT_ATLAS_H - 0.5f;
  int x0 = static_cast<int>(std::floor(x)), y0 = static_cast<int>(std::floor(y));
  float fx = x - x0, fy = y - y0;
  auto at = [](int xx, int yy) {
    xx = std::max(0, std::min(FONT_ATLAS_W - 1, xx));
    yy = std::max(0, std::min(FONT_ATLAS_H - 1, yy));
    return FONT_ATLAS[yy * FONT_ATLAS_W + xx] / 255.f;
  };
  return (at(x0, y0) * (1 - fx) + at(x0 + 1, y0) * fx) * (1 - fy) + (at(x0, y0 + 1) * (1 - fx) + at(x0 + 1, y0 + 1) * fx) * fy;
}

static void rasterize(const DrawList& dl, Canvas& cv) {
  for (const Batch& b : dl.batches) {
    int sx0 = 0, sy0 = 0, sx1 = cv.w, sy1 = cv.h;
    if (b.clip) {
      sx0 = std::max(0, b.cx);
      sy0 = std::max(0, b.cy);
      sx1 = std::min(cv.w, b.cx + b.cw);
      sy1 = std::min(cv.h, b.cy + b.ch);
    }
    for (size_t i = b.first; i + 2 < b.first + b.count; i += 3) {
      const Vertex &a = dl.verts[i], &bb = dl.verts[i + 1], &c = dl.verts[i + 2];
      float minx = std::min({a.x, bb.x, c.x}), maxx = std::max({a.x, bb.x, c.x});
      float miny = std::min({a.y, bb.y, c.y}), maxy = std::max({a.y, bb.y, c.y});
      int x0 = std::max(sx0, static_cast<int>(std::floor(minx))), x1 = std::min(sx1 - 1, static_cast<int>(std::ceil(maxx)));
      int y0 = std::max(sy0, static_cast<int>(std::floor(miny))), y1 = std::min(sy1 - 1, static_cast<int>(std::ceil(maxy)));
      float den = (bb.y - c.y) * (a.x - c.x) + (c.x - bb.x) * (a.y - c.y);
      if (std::fabs(den) < 1e-9f) continue;
      for (int y = y0; y <= y1; ++y)
        for (int x = x0; x <= x1; ++x) {
          float px = x + 0.5f, py = y + 0.5f;
          float l1 = ((bb.y - c.y) * (px - c.x) + (c.x - bb.x) * (py - c.y)) / den;
          float l2 = ((c.y - a.y) * (px - c.x) + (a.x - c.x) * (py - c.y)) / den;
          float l3 = 1.f - l1 - l2;
          if (l1 < -1e-4f || l2 < -1e-4f || l3 < -1e-4f) continue;
          float u = l1 * a.u + l2 * bb.u + l3 * c.u, v = l1 * a.v + l2 * bb.v + l3 * c.v;
          float ca[4];
          for (int k = 0; k < 4; ++k) {
            auto ch = [&](const Vertex& vv) { return ((vv.c >> (8 * k)) & 255) / 255.f; };
            ca[k] = l1 * ch(a) + l2 * ch(bb) + l3 * ch(c);
          }
          float alpha = ca[3] * atlasAlpha(u, v);
          float* d = &cv.px[(static_cast<size_t>(y) * cv.w + x) * 3];
          for (int k = 0; k < 3; ++k) d[k] = d[k] * (1 - alpha) + ca[k] * alpha;
        }
    }
  }
}

static void writePPM(const Canvas& cv, const std::string& path) {
  FILE* f = std::fopen(path.c_str(), "wb");
  if (!f) return;
  std::fprintf(f, "P6\n%d %d\n255\n", cv.w, cv.h);
  for (float v : cv.px) std::fputc(static_cast<int>(std::max(0.f, std::min(1.f, v)) * 255.f + 0.5f), f);
  std::fclose(f);
}

static double T = 0;
static DrawList g_dl;
static Canvas render(App& app, int W, int H, const std::string& shot = "") {
  T += 0.016;
  app.frame(T, g_dl);
  if (shot.empty()) return Canvas(1, 1);  // only rasterize when a screenshot is wanted
  Canvas cv(W, H);
  rasterize(g_dl, cv);
  writePPM(cv, "/tmp/shots/" + shot + ".ppm");
  return cv;
}
static void tapPx(App& app, float x, float y) {
  app.touch(0, x, y);
  app.touch(2, x, y);
}
static void tapNode(App& app, int id) {
  float x, y;
  if (!app.nodePixelPos(id, x, y)) {
    std::printf("      (node %d not found)\n", id);
    return;
  }
  tapPx(app, x, y);
}
static void settle(App& app, int W, int H, int frames = 3) {
  for (int i = 0; i < frames; ++i) render(app, W, H);
}
static bool tapL(App& app, const std::string& l, int W, int H) {
  settle(app, W, H, 1);
  return app.tapLabel(l);
}
static void runTraining(App& app, int W, int H, int maxFrames = 4000) {
  app.trainBudgetSeconds_ = 0.004;
  for (int i = 0; i < maxFrames && app.training_; ++i) render(app, W, H);
}

int main() {
  system("mkdir -p /tmp/shots");
  const int W = 1080, H = 2340;
  const float D = 3.0f;

  // ------------------------------------------------------------ first frame
  App app;
  app.setSurface(W, H, D);
  render(app, W, H, "01_build_xor");
  CHECK(g_dl.verts.size() > 1000 && g_dl.verts.size() % 3 == 0, "frame produces whole triangles");
  CHECK(g_dl.batches.size() >= 2, "clip batches are emitted");

  // ------------------------------------------------------------ select a node, see inspector
  std::vector<int> ids;
  for (auto& n : app.net_.nodes) ids.push_back(n.id);
  int hid = ids[2];  // a hidden node
  settle(app, W, H);
  tapNode(app, hid);
  CHECK(app.selNode_ == hid, "tapping a node selects it");
  render(app, W, H, "02_node_inspector");

  // activation cycle + bias stepper through real taps
  Act before = app.net_.nodes[app.net_.nodeIndex(hid)].act;
  CHECK(tapL(app, actName(before), W, H), "inspector shows activation button");
  CHECK(app.net_.nodes[app.net_.nodeIndex(hid)].act != before, "activation button cycles");
  float b0 = app.net_.nodes[app.net_.nodeIndex(hid)].bias;
  CHECK(tapL(app, "+", W, H), "bias + button exists");
  CHECK(std::fabs(app.net_.nodes[app.net_.nodeIndex(hid)].bias - (b0 + 0.1f)) < 1e-5f, "bias + adds 0.1 and math updates");

  // ------------------------------------------------------------ keypad: type a bias
  settle(app, W, H);
  CHECK(tapL(app, "value:Bias", W, H), "bias value opens keypad");
  CHECK(app.tapLabel("+/-") || true, "");
  render(app, W, H, "03_keypad");
  tapL(app, "DEL", W, H);
  tapL(app, "2", W, H);
  tapL(app, ".", W, H);
  tapL(app, "5", W, H);
  tapL(app, "+/-", W, H);
  tapL(app, "OK", W, H);
  CHECK(std::fabs(app.net_.nodes[app.net_.nodeIndex(hid)].bias + 2.5f) < 1e-5f, "keypad typed -2.5 into the bias");
  settle(app, W, H);
  {  // keypad rejects junk
    tapL(app, "value:Bias", W, H);
    tapL(app, "DEL", W, H);
    tapL(app, "OK", W, H);
    settle(app, W, H, 1);
    float bnow = app.net_.nodes[app.net_.nodeIndex(hid)].bias;
    CHECK(bnow == -2.5f, "empty keypad entry is rejected, value unchanged");
    tapL(app, "Cancel", W, H);
  }

  // ------------------------------------------------------------ drag a node & pan
  settle(app, W, H);
  float nx, ny;
  app.nodePixelPos(ids[0], nx, ny);
  float ox = app.net_.nodes[0].x;
  app.touch(0, nx, ny);
  app.touch(1, nx + 20, ny + 20);
  app.touch(1, nx + 90, ny + 60);
  app.touch(2, nx + 90, ny + 60);
  CHECK(app.net_.nodes[0].x > ox + 20, "dragging a node moves it");
  settle(app, W, H);
  float px0 = 0, py0 = 0;
  app.nodePixelPos(ids[1], px0, py0);
  app.selNode_ = -1;  // hide the inspector so the bottom of the canvas is free
  settle(app, W, H);
  app.touch(0, 900, 1500);  // empty canvas area
  app.touch(1, 880, 1460);
  app.touch(1, 800, 1300);
  app.touch(2, 800, 1300);
  float px1 = 0, py1 = 0;
  app.nodePixelPos(ids[1], px1, py1);
  CHECK(px1 < px0 - 30 && py1 < py0 - 30, "dragging empty canvas pans the view");

  // ------------------------------------------------------------ build a network from scratch with taps
  tapL(app, "nav:Presets", W, H);
  CHECK(app.tab_ == Tab::Presets, "nav bar switches tab");
  render(app, W, H, "04_presets");
  tapL(app, "New blank network", W, H);
  CHECK(app.net_.nodes.empty() && app.tab_ == Tab::Build, "new blank network clears the canvas");
  render(app, W, H, "05_blank");
  tapL(app, "+Input", W, H);
  tapL(app, "+Input", W, H);
  tapL(app, "+Hidden", W, H);
  tapL(app, "+Output", W, H);
  CHECK(app.net_.nodes.size() == 4, "+ buttons add four nodes");
  // spread them out so taps don't land on the same spot
  app.net_.nodes[0].x = 60;
  app.net_.nodes[0].y = 150;
  app.net_.nodes[1].x = 60;
  app.net_.nodes[1].y = 290;
  app.net_.nodes[2].x = 190;
  app.net_.nodes[2].y = 220;
  app.net_.nodes[3].x = 310;
  app.net_.nodes[3].y = 220;
  app.selNode_ = -1;
  settle(app, W, H);
  render(app, W, H, "06_unwired");  // shows the warning chip
  CHECK(!app.net_.check().empty(), "unwired net is flagged");
  tapL(app, "Link", W, H);
  tapNode(app, app.net_.nodes[0].id);
  tapNode(app, app.net_.nodes[2].id);
  settle(app, W, H);
  tapNode(app, app.net_.nodes[1].id);
  tapNode(app, app.net_.nodes[2].id);
  settle(app, W, H);
  tapNode(app, app.net_.nodes[3].id);  // output first, hidden second: app flips the direction
  tapNode(app, app.net_.nodes[2].id);
  CHECK(app.net_.edges.size() == 3, "link tool created three wires");
  CHECK(app.net_.edgeIndex(app.net_.nodes[2].id, app.net_.nodes[3].id) >= 0, "wire drawn 'backwards' is flipped to flow forward");
  CHECK(app.net_.check().empty(), "fully wired net has no warnings");
  render(app, W, H, "07_wired_edge_selected");
  // try an illegal wire
  size_t ecount = app.net_.edges.size();
  tapNode(app, app.net_.nodes[0].id);
  tapNode(app, app.net_.nodes[1].id);
  CHECK(app.net_.edges.size() == ecount, "illegal wire (input -> input) refused");

  // ------------------------------------------------------------ erase tool
  tapL(app, "Erase", W, H);
  size_t nodesBefore = app.net_.nodes.size();
  app.net_.addNode(Kind::Hidden, 200, 400);
  settle(app, W, H);
  tapNode(app, app.net_.nodes.back().id);
  CHECK(app.net_.nodes.size() == nodesBefore, "erase tool deletes a tapped node");
  tapL(app, "Move", W, H);

  // ------------------------------------------------------------ preset load + train via taps
  tapL(app, "nav:Presets", W, H);
  CHECK(tapL(app, "preset:XOR", W, H), "XOR preset card is tappable");
  CHECK(app.presetName_ == "XOR" && app.net_.nodes.size() == 7, "XOR preset loaded");
  tapL(app, "nav:Train", W, H);
  CHECK(app.tab_ == Tab::Train, "Train tab opens");
  render(app, W, H, "08_train_before");
  tapL(app, "Train", W, H);  // the big button (labels are searched newest first)
  CHECK(app.training_, "Train button starts training");
  runTraining(app, W, H);
  CHECK(!app.training_ && app.trainer_.lastLoss < 0.01f, "training runs in frames and stops at target");
  std::printf("      trained %d epochs, loss %.5f\n", app.trainer_.epochsDone, app.trainer_.lastLoss);
  render(app, W, H, "09_train_after");

  // scroll the train tab
  app.touch(0, 500, 1800);
  app.touch(1, 500, 1500);
  app.touch(1, 500, 600);
  app.touch(2, 500, 600);
  CHECK(app.tab_ == Tab::Train, "drag scroll does not trigger buttons");
  render(app, W, H, "10_train_scrolled");
  app.touch(0, 500, 1800);
  app.touch(1, 500, 600);
  app.touch(1, 500, -2000);
  app.touch(2, 500, -2000);
  render(app, W, H, "11_train_bottom");

  // keypad edit of learning rate
  tapL(app, "param:Learning rate", W, H);
  tapL(app, "0", W, H);
  tapL(app, ".", W, H);
  tapL(app, "2", W, H);
  tapL(app, "OK", W, H);
  CHECK(std::fabs(app.cfg_.lr - 0.2f) < 1e-6f, "keypad edits the learning rate");
  CHECK(app.cfg_.name == "Custom", "editing a trainer marks it Custom");
  tapL(app, "param:Optimizer", W, H);
  CHECK(app.cfg_.opt != OptKind::Adam, "optimizer cycles");
  // dataset cell edit
  tapL(app, "y0,0", W, H);
  tapL(app, "0", W, H);
  tapL(app, "OK", W, H);
  CHECK(app.data_.Y[0][0] == 0.f, "dataset cell edit through keypad");

  // custom trainer save + dataset add/remove rows
  size_t tcount = app.customTrainers_.size();
  tapL(app, "Save as my trainer", W, H);
  CHECK(app.customTrainers_.size() == tcount + 1, "custom trainer saved");
  size_t rows = app.data_.rows();
  tapL(app, "+ Add row", W, H);
  CHECK(app.data_.rows() == rows + 1, "add row button works");
  tapL(app, "x", W, H);
  CHECK(app.data_.rows() == rows, "row delete button works");

  // ------------------------------------------------------------ custom preset save/delete/persist
  {
    system("rm -rf /tmp/nodelab_store && mkdir -p /tmp/nodelab_store");
    app.setStorageDir("/tmp/nodelab_store");
    tapL(app, "nav:Presets", W, H);
    tapL(app, "Save current as new preset", W, H);
    CHECK(app.custom_.size() == 1, "custom preset saved");
    render(app, W, H, "12_presets_custom");
    App app2;
    app2.setSurface(W, H, D);
    app2.setStorageDir("/tmp/nodelab_store");
    app2.loadState();
    CHECK(app2.custom_.size() == 1 && app2.custom_[0].name == app.custom_[0].name, "custom presets survive restart");
    CHECK(app2.customTrainers_.size() == app.customTrainers_.size(), "custom trainers survive restart");
    CHECK(app2.net_.edges.size() == app.net_.edges.size() &&
              std::fabs(app2.net_.edges[0].w - app.net_.edges[0].w) < 1e-6f,
          "workspace (trained weights) survives restart");
    // two-tap delete
    tapL(app, "Delete", W, H);
    CHECK(app.custom_.size() == 1, "first Delete tap only arms confirmation");
    tapL(app, "Sure?", W, H);
    CHECK(app.custom_.empty(), "second tap deletes the preset");
  }

  // ------------------------------------------------------------ divergence is reported, not hidden
  {
    App a;
    a.setSurface(W, H, D);
    a.cfg_.opt = OptKind::SGD;
    a.cfg_.lr = 1e12f;
    a.cfg_.targetLoss = 0;
    a.cfg_.epochs = 100;
    a.tab_ = Tab::Train;
    settle(a, W, H);
    a.startTraining();
    runTraining(a, W, H, 200);
    render(a, W, H, "13_diverged_or_clipped");
    CHECK(!a.training_, "absurd learning rate still terminates");
    std::printf("      status: %s\n", a.statusText().c_str());
  }

  // ------------------------------------------------------------ regression tests for review findings
  {
    App a;
    a.setSurface(W, H, D);
    settle(a, W, H);
    // pan, then re-announce the same surface (what happens when returning from the background)
    a.touch(0, 900, 1500);
    a.touch(1, 880, 1460);
    a.touch(1, 700, 1300);
    a.touch(2, 700, 1300);
    float ax, ay, bx, by;
    a.nodePixelPos(a.net_.nodes[0].id, ax, ay);
    a.setSurface(W, H, D);
    a.nodePixelPos(a.net_.nodes[0].id, bx, by);
    CHECK(ax == bx && ay == by, "same-size setSurface keeps the user's pan");
    a.setSurface(720, 1280, 2.f);
    CHECK(true, "size change re-frames without crashing");

    // dragging has no slop lag: the node follows the finger by the full distance
    App d;
    d.setSurface(W, H, D);
    settle(d, W, H);
    float nx0, ny0;
    d.nodePixelPos(d.net_.nodes[0].id, nx0, ny0);
    float startX = d.net_.nodes[0].x;
    d.touch(0, nx0, ny0);
    d.touch(1, nx0 + 45, ny0);
    d.touch(1, nx0 + 90, ny0);
    d.touch(2, nx0 + 90, ny0);
    float moved = (d.net_.nodes[0].x - startX) * D;  // back to pixels
    CHECK(std::fabs(moved - 90.f) < 1.5f, "node moves the full finger distance (no slop lag)");

    // keypad: scientific-notation leftovers are not silently truncated
    d.tab_ = Tab::Train;
    settle(d, W, H);
    d.cfg_.lr = 1e-6f;
    settle(d, W, H);
    d.tapLabel("param:Learning rate");
    settle(d, W, H);
    d.tapLabel(".");  // "1e-06" is never offered as editable text; "." on a fresh pad starts "0."
    d.tapLabel("OK");
    CHECK(d.cfg_.lr >= 1e-6f, "keypad entry always yields a sane learning rate");
    d.tapLabel("Cancel");

    // animating(): idle app lets the platform sleep, training keeps frames coming
    App idle;
    idle.setSurface(W, H, D);
    T += 30;  // let the start-up toast expire
    render(idle, W, H);
    CHECK(!idle.animating(), "idle app is not animating (battery friendly)");
    idle.tab_ = Tab::Train;
    settle(idle, W, H);
    idle.startTraining();
    CHECK(idle.animating(), "training counts as animating");
    idle.touch(0, 500, 500);
    idle.stopTraining();
    CHECK(idle.animating(), "finger down counts as animating");
    idle.touch(3, 0, 0);

    // data cells tolerate a stale hit after the data shrank
    App s;
    s.setSurface(W, H, D);
    s.tab_ = Tab::Train;
    settle(s, W, H);
    while (s.data_.rows() > 0) s.data_.removeRow(0);
    s.tapLabel("x0,0");
    CHECK(true, "stale data-cell hit is harmless");

    // persistence: nothing is saved over real data before it was loaded
    system("rm -rf /tmp/nodelab_store2 && mkdir -p /tmp/nodelab_store2");
    {
      App one;
      one.setSurface(W, H, D);
      one.setStorageDir("/tmp/nodelab_store2");
      one.loadState();
      one.loadPreset(one.builtin_[5]);
      Preset sp;
      sp.name = "keep me";
      sp.net = one.net_;
      sp.data = one.data_;
      sp.cfg = one.cfg_;
      one.custom_.push_back(sp);
      one.saveState();
    }
    App two;  // the way android_main now starts: set dir + load first, then save on pause
    two.setStorageDir("/tmp/nodelab_store2");
    two.loadState();
    two.saveState();
    App three;
    three.setStorageDir("/tmp/nodelab_store2");
    three.loadState();
    CHECK(three.custom_.size() == 1 && three.presetName_ == "Sine wave", "early save after load keeps saved work");
  }

  // ------------------------------------------------------------ other screen sizes must not crash
  {
    int sizes[][3] = {{720, 1280, 2}, {1080, 1920, 3}, {480, 800, 1}, {1600, 2560, 2}, {1440, 3200, 4}};
    for (auto& s : sizes) {
      App a;
      a.setSurface(s[0], s[1], static_cast<float>(s[2]));
      for (Tab t : {Tab::Build, Tab::Train, Tab::Presets}) {
        a.tab_ = t;
        a.selNode_ = a.net_.nodes[2].id;
        render(a, s[0], s[1]);
      }
      char nm[64];
      std::snprintf(nm, sizeof nm, "size_%dx%d_build", s[0], s[1]);
      a.tab_ = Tab::Build;
      render(a, s[0], s[1], nm);
    }
    CHECK(true, "rendered 5 screen sizes without crashing");
  }

  // ------------------------------------------------------------ touch robustness
  {
    App a;
    a.setSurface(W, H, D);
    settle(a, W, H);
    a.touch(1, 10, 10);   // move without down
    a.touch(2, 10, 10);   // up without down
    a.touch(3, 0, 0);
    a.touch(0, -50, -50);
    a.touch(2, -50, -50);
    a.touch(0, 99999, 99999);
    a.touch(2, 99999, 99999);
    settle(a, W, H);
    CHECK(true, "stray/out-of-range touches are harmless");
    // keypad backdrop tap closes it
    a.tab_ = Tab::Train;
    settle(a, W, H);
    a.tapLabel("param:Epochs");
    settle(a, W, H);
    a.touch(0, 500, 200);
    a.touch(2, 500, 200);
    CHECK(true, "keypad backdrop tap handled");
    // remove all nodes then render + train attempt must not crash
    a.net_.clear();
    a.tab_ = Tab::Train;
    a.startTraining();
    settle(a, W, H);
    CHECK(!a.training_, "training an empty network is refused");
  }

  std::printf("\n%s (%d failures)\n", failures ? "SOME UI TESTS FAILED" : "ALL UI TESTS PASSED", failures);
  return failures ? 1 : 0;
}
