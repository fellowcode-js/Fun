# NodeLab

A free neural-network builder for Android, written in C++ (NativeActivity + OpenGL ES 2). No Java or Kotlin code, no ads, no paywalls, no network permission.

## What it does

- **Build tab**: add Input / Hidden / Output nodes with the `+` buttons, wire them with **Link**, drag them with **Move**, delete with **Erase**. Tap a node or wire to see the math in the inspector (for example `I1: -0.68 x 1.00 = -0.68`, then `sum + bias`, then `tanh(...) = ...`). Change weights, biases, input values and activation functions there.
- **Train tab**: pick a trainer (Adam, SGD, Momentum, or your own), edit the data table by tapping cells, press **Train** and watch the loss curve and per-row predictions update live.
- **Presets tab**: 6 built-in puzzles (XOR, AND, OR, half adder, line fit, sine wave). Save your own networks and trainers; they persist across restarts.
- Wiring mistakes (loops, wires into inputs, duplicates) are refused with a message. Tapping a wire from output to input flips it for you. The yellow banner on the Build tab explains what is missing and offers to fix data/NaN problems.

Tips: tap **Move** again to recentre the graph. Android's back button closes the keypad, then returns to Build.

## Build the APK

An APK must be compiled with the Android NDK, so a source zip can't just be renamed to `.apk`. The Android IDE phone app can't build C++ projects (it has no NDK support). Two things work:

**GitHub (phone friendly, free)**: see `START_HERE.txt`. Upload `NodeLab.zip` and the workflow file; GitHub builds the APK and posts it on the Releases page.

**Android Studio (PC)**: install the NDK and CMake from SDK Manager, open this folder, then Build > Build APK(s). Or from a terminal with the SDK installed: `./gradlew assembleDebug`, result in `app/build/outputs/apk/debug/`.

Build switches: `-Pnodelab.abis=arm64-v8a` builds only 64-bit (faster); `-Pnodelab.ndk=<version>` pins an NDK.

## Project layout

```
app/src/main/cpp/core/engine.*     the math: graph, forward pass, backprop, optimizers, presets, save format
app/src/main/cpp/ui/app.*          all screens and touch handling (no Android APIs)
app/src/main/cpp/ui/draw.*         tiny anti-aliased 2D renderer producing a triangle list
app/src/main/cpp/platform/         android_main.cpp: EGL/GLES2 + touch + lifecycle
tests/                             desktop tests (run_tests.sh)
tools/gen_font.py                  regenerates the font atlas
```

## Tests

`bash tests/run_tests.sh` builds the engine and UI with AddressSanitizer/UBSan and runs them. The UI test drives the real app with simulated touches and writes screenshots to `/tmp/shots`. Coverage includes a numeric gradient check of backprop, every preset training to low loss, save/load round trips, corrupt-file rejection and divergence handling.

What the tests cannot cover: `platform/android_main.cpp` and the Gradle/CMake files were only checked by reading and by a syntax check against stub NDK headers, because no Android SDK/NDK was available when this was written. The first real build on a device is the real test of that layer.
