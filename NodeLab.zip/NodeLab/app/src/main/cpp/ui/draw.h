// Tiny portable 2D draw list: everything is tessellated to a textured triangle list
// (one alpha atlas holds the font plus a solid white cell), so the Android GLES
// renderer and the desktop test rasterizer share exactly the same geometry.
// All coordinates passed in are in dp; `scale` converts dp -> pixels.
#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace nl {

struct Color {
  uint8_t r = 0, g = 0, b = 0, a = 255;
};
constexpr Color rgba(int r, int g, int b, int a = 255) {
  return Color{static_cast<uint8_t>(r), static_cast<uint8_t>(g), static_cast<uint8_t>(b), static_cast<uint8_t>(a)};
}
inline Color withAlpha(Color c, int a) { return Color{c.r, c.g, c.b, static_cast<uint8_t>(a)}; }

struct Vertex {
  float x, y;  // pixels, origin top-left
  float u, v;  // atlas coordinates 0..1
  uint32_t c;  // r | g<<8 | b<<16 | a<<24
};

struct Batch {
  size_t first = 0;   // first vertex
  size_t count = 0;   // vertex count
  bool clip = false;
  int cx = 0, cy = 0, cw = 0, ch = 0;  // scissor in pixels, origin top-left
};

class DrawList {
 public:
  void begin(float scale);  // clears everything
  float scale() const { return scale_; }

  void rect(float x, float y, float w, float h, Color c);
  void rrect(float x, float y, float w, float h, float radius, Color c);
  void circle(float cx, float cy, float r, Color c);
  void line(float x1, float y1, float x2, float y2, float thickness, Color c);
  void tri(float x1, float y1, float x2, float y2, float x3, float y3, Color c);
  // (x, y) is the top-left of the text box; h is the box height in dp.
  void text(float x, float y, float h, Color c, const std::string& s);
  float textWidth(const std::string& s, float h) const { return static_cast<float>(s.size()) * h * 0.5f; }

  void setClip(float x, float y, float w, float h);
  void clearClip();

  std::vector<Vertex> verts;
  std::vector<Batch> batches;

 private:
  void startBatch(bool clip, int cx, int cy, int cw, int ch);
  void push(float x, float y, float u, float v, Color c);
  void quadPx(float x0, float y0, float x1, float y1, float u0, float v0, float u1, float v1, Color c);
  void polyAA(const std::vector<float>& pts, Color c);  // convex polygon, pixel coords
  float scale_ = 1.f;
  float whiteU_ = 0.f, whiteV_ = 0.f;
};

}  // namespace nl
