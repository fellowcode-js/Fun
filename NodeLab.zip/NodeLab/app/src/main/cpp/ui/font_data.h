#pragma once
namespace nl {
constexpr int FONT_CELL_W = 16;
constexpr int FONT_CELL_H = 32;
constexpr int FONT_COLS = 16;
constexpr int FONT_ATLAS_W = 256;
constexpr int FONT_ATLAS_H = 192;
constexpr int FONT_WHITE_SLOT = 95;  // solid cell used for filled shapes
extern const unsigned char FONT_ATLAS[FONT_ATLAS_W * FONT_ATLAS_H];
}  // namespace nl
