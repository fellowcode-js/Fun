#include "app.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>

namespace nl {
namespace {

const Color BG = rgba(15, 18, 32);
const Color PANEL = rgba(24, 28, 48);
const Color PANEL2 = rgba(36, 42, 70);
const Color LINEC = rgba(56, 64, 104);
const Color TEXT = rgba(232, 236, 255);
const Color SUB = rgba(143, 152, 192);
const Color ACCENT = rgba(96, 130, 255);
const Color TEAL = rgba(70, 227, 183);
const Color CORAL = rgba(255, 112, 112);
const Color AMBER = rgba(255, 196, 90);
const Color KIN = rgba(77, 163, 255);
const Color KHID = rgba(181, 140, 255);
const Color KOUT = rgba(255, 184, 77);

constexpr float TOP = 56.f, NAV = 60.f, TOOLH = 52.f, NODE_R = 24.f;

Color kindColor(Kind k) { return k == Kind::Input ? KIN : (k == Kind::Hidden ? KHID : KOUT); }

std::string fmt(const char* f, double v) {
  char b[64];
  std::snprintf(b, sizeof b, f, v);
  return b;
}
std::string num2(float v) {
  if (!std::isfinite(v)) return "NaN";
  return std::fabs(v) >= 100.f ? fmt("%.0f", v) : fmt("%.2f", v);
}
std::string sgn2(float v) {
  if (!std::isfinite(v)) return "NaN";
  return std::fabs(v) >= 100.f ? fmt("%+.0f", v) : fmt("%+.2f", v);
}
std::string numS(float v) { return std::isfinite(v) ? fmt("%.3g", v) : "NaN"; }
std::string numEdit(float v) { return std::isfinite(v) ? fmt("%.6g", v) : "0"; }
std::string lossStr(float l) {
  if (!std::isfinite(l)) return "NaN";
  if (l >= 1e-4f || l == 0.f) return fmt("%.5f", l);
  return fmt("%.1e", l);
}
const char* actShort(Act a) {
  switch (a) {
    case Act::Linear: return "lin";
    case Act::Sigmoid: return "sig";
    case Act::Tanh: return "tanh";
    case Act::ReLU: return "relu";
    case Act::LeakyReLU: return "leaky";
    case Act::Step: return "step";
  }
  return "?";
}
std::vector<std::string> wrapText(const std::string& s, size_t maxChars) {
  std::vector<std::string> lines;
  std::istringstream is(s);
  std::string word, cur;
  while (is >> word) {
    if (!cur.empty() && cur.size() + 1 + word.size() > maxChars) {
      lines.push_back(cur);
      cur.clear();
    }
    cur += (cur.empty() ? "" : " ") + word;
  }
  if (!cur.empty()) lines.push_back(cur);
  return lines;
}
float distToSegment(float px, float py, float ax, float ay, float bx, float by) {
  float dx = bx - ax, dy = by - ay;
  float l2 = dx * dx + dy * dy;
  float t = l2 > 0 ? ((px - ax) * dx + (py - ay) * dy) / l2 : 0.f;
  t = std::max(0.f, std::min(1.f, t));
  float cx = ax + t * dx - px, cy = ay + t * dy - py;
  return std::sqrt(cx * cx + cy * cy);
}

}  // namespace

// ================================================================= setup
App::App() {
  builtin_ = builtinPresets();
  builtinTrainers_ = builtinTrainers();
  loadPreset(builtin_[0]);
  toastMsg_.clear();
  toastUntil_ = 0;
}

void App::setSurface(int pxW, int pxH, float density) {
  const float oldW = W_, oldH = H_;
  density_ = density > 0.1f ? density : 1.f;
  W_ = pxW / density_;
  H_ = pxH / density_;
  canvas_ = Rect{0, TOP + TOOLH, W_, H_ - NAV - TOP - TOOLH};
  // Only recentre when the size really changed, so coming back from the background keeps your pan.
  if (std::fabs(W_ - oldW) > 0.5f || std::fabs(H_ - oldH) > 0.5f) frameView();
}

void App::frameView() {
  float x0 = 1e9f, x1 = -1e9f, y0 = 1e9f, y1 = -1e9f;
  for (const Node& n : net_.nodes) {
    x0 = std::min(x0, n.x);
    x1 = std::max(x1, n.x);
    y0 = std::min(y0, n.y);
    y1 = std::max(y1, n.y);
  }
  if (net_.nodes.empty()) x0 = x1 = 180.f, y0 = y1 = 220.f;
  float ch = H_ - NAV - TOP - TOOLH;
  panX_ = W_ / 2.f - (x0 + x1) / 2.f;
  panY_ = (ch - 150.f) / 2.f - (y0 + y1) / 2.f;
}

bool App::onBack() {
  if (pad_.open) {
    pad_.open = false;
    return true;
  }
  if (tab_ != Tab::Build) {
    tab_ = Tab::Build;
    return true;
  }
  if (selNode_ >= 0 || selEdge_ >= 0 || linkFrom_ >= 0) {
    selNode_ = selEdge_ = linkFrom_ = -1;
    return true;
  }
  return false;
}

void App::toast(const std::string& msg) {
  toastMsg_ = msg;
  toastUntil_ = now_ + 2.4;
}

bool App::confirm(const std::string& key) {
  if (confirmKey_ == key && now_ < confirmUntil_) {
    confirmKey_.clear();
    return true;
  }
  confirmKey_ = key;
  confirmUntil_ = now_ + 3.0;
  toast("Tap again to confirm");
  return false;
}

// ================================================================= persistence
void App::setStorageDir(const std::string& dir) { dir_ = dir; }

void App::saveFile(const std::string& name, const std::string& text) const {
  if (dir_.empty()) return;
  std::string path = dir_ + "/" + name, tmp = path + ".tmp";
  {
    std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
    if (!f) return;
    f << text;
    if (!f.good()) return;
  }
  std::rename(tmp.c_str(), path.c_str());
}

std::string App::readFile(const std::string& name) const {
  if (dir_.empty()) return "";
  std::ifstream f(dir_ + "/" + name, std::ios::binary);
  if (!f) return "";
  std::stringstream ss;
  ss << f.rdbuf();
  return ss.str();
}

void App::saveState() {
  Preset w;
  w.name = presetName_;
  w.desc = "workspace";
  w.net = net_;
  w.data = data_;
  w.cfg = cfg_;
  saveFile("workspace.txt", serializePreset(w));
  saveFile("presets.txt", serializePresets(custom_));
  saveFile("trainers.txt", serializeTrainers(customTrainers_));
}

void App::loadState() {
  std::string ws = readFile("workspace.txt");
  Preset w;
  if (!ws.empty() && deserializePreset(ws, w)) {
    net_ = w.net;
    data_ = w.data;
    cfg_ = w.cfg;
    presetName_ = w.name.empty() ? "My network" : w.name;
    net_.forward();
    trainer_.reset();
    training_ = false;
    selNode_ = selEdge_ = linkFrom_ = -1;
    frameView();
  }
  custom_ = deserializePresets(readFile("presets.txt"));
  customTrainers_ = deserializeTrainers(readFile("trainers.txt"));
}

// ================================================================= actions
void App::loadPreset(const Preset& p) {
  Preset copy = p;  // p may alias something we are about to overwrite
  net_ = copy.net;
  data_ = copy.data;
  cfg_ = copy.cfg;
  presetName_ = copy.name;
  net_.forward();
  trainer_.reset();
  training_ = false;
  runStart_ = 0;
  selNode_ = selEdge_ = linkFrom_ = -1;
  tab_ = Tab::Build;
  frameView();
  toast("Loaded " + copy.name);
}

void App::newBlank() {
  net_.clear();
  data_ = Dataset();
  cfg_ = TrainerCfg();
  cfg_.name = "Adam";
  presetName_ = "Blank network";
  trainer_.reset();
  training_ = false;
  runStart_ = 0;
  selNode_ = selEdge_ = linkFrom_ = -1;
  tab_ = Tab::Build;
  frameView();
  toast("Blank canvas. Add nodes with the + buttons.");
}

void App::netEdited(bool structural) {
  if (structural) {
    trainer_.reset();
    training_ = false;
    runStart_ = 0;
    selEdge_ = -1;
  }
  net_.forward();
}

void App::addNode(Kind k) {
  float top = TOP + TOOLH, ch = H_ - NAV - top;
  float jitter = static_cast<float>((static_cast<int>(net_.nodes.size()) * 37) % 5 - 2) * 18.f;
  float wx = W_ / 2.f - panX_ + jitter;
  float wy = ch / 2.f - 60.f - panY_ + jitter * 0.7f;
  int id = net_.addNode(k, wx, wy);
  selNode_ = id;
  selEdge_ = -1;
  netEdited(true);
}

bool App::runFinished() const {
  if (trainer_.diverged) return true;
  int runDone = trainer_.epochsDone - runStart_;
  if (runDone >= cfg_.epochs) return true;
  if (cfg_.targetLoss > 0.f && runDone > 0 && trainer_.lastLoss <= cfg_.targetLoss) return true;
  return false;
}

void App::startTraining() {
  std::string err;
  if (!datasetCompatible(net_, data_, &err)) {
    toast(err);
    return;
  }
  if (trainer_.diverged) {
    toast("It diverged. Press Reset weights first.");
    return;
  }
  if (cfg_.targetLoss > 0.f && trainer_.epochsDone > 0 && trainer_.lastLoss <= cfg_.targetLoss) {
    toast("Already below the stop-at loss. Lower it to keep going.");
    return;
  }
  runStart_ = trainer_.epochsDone;
  training_ = true;
}

void App::stopTraining() { training_ = false; }

void App::resetWeights() {
  net_.randomize(seed_++);
  trainer_.reset();
  training_ = false;
  runStart_ = 0;
  toast("Weights reset");
}

void App::autoFix() {
  bool changed = net_.sanitize();
  size_t nIn = net_.inputIds().size(), nOut = net_.outputIds().size();
  bool mismatch = false;
  for (size_t i = 0; i < data_.rows(); ++i)
    if (data_.X[i].size() != nIn || data_.Y[i].size() != nOut) mismatch = true;
  if (mismatch && nIn > 0 && nOut > 0) {
    data_.resizeCols(nIn, nOut);
    changed = true;
  }
  if (changed) {
    trainer_.reset();
    training_ = false;
    toast("Fixed it");
  } else {
    std::vector<std::string> p = net_.check();
    toast(p.empty() ? "Nothing to fix" : p[0] + ". Use + to add nodes, Link to wire them.");
  }
}

std::string App::statusText() const {
  if (training_) return "Training...";
  if (trainer_.diverged) return "Diverged! Lower the learning rate, then press Reset weights.";
  if (trainer_.epochsDone == 0) return "Ready. Press Train.";
  if (cfg_.targetLoss > 0.f && trainer_.lastLoss <= cfg_.targetLoss) return "Done: reached the stop-at loss.";
  if (trainer_.epochsDone - runStart_ >= cfg_.epochs) return "Done: epoch limit reached. Press Train to continue.";
  return "Paused. Press Train to keep going.";
}

void App::trainSlice() {
  if (!training_) return;
  using clock = std::chrono::steady_clock;
  auto t0 = clock::now();
  int n = 0;
  while (training_ && n < 2000) {
    if (runFinished()) {
      training_ = false;
      break;
    }
    float l = trainer_.epoch(net_, data_, cfg_);
    if (l < 0.f) {
      std::string e;
      datasetCompatible(net_, data_, &e);
      toast(e);
      training_ = false;
      break;
    }
    ++n;
    if (std::chrono::duration<double>(clock::now() - t0).count() > trainBudgetSeconds_) break;
  }
  if (training_ && runFinished()) training_ = false;
}

// ================================================================= hits & widgets
void App::setClip(DrawList& dl, Rect r) {
  hasClip_ = true;
  clip_ = r;
  dl.setClip(r.x, r.y, r.w, r.h);
}
void App::clearClip(DrawList& dl) {
  hasClip_ = false;
  dl.clearClip();
}

void App::addHit(Rect r, std::function<void()> fn, const std::string& label) {
  if (blockInput_) return;
  if (hasClip_) {
    float x0 = std::max(r.x, clip_.x), y0 = std::max(r.y, clip_.y);
    float x1 = std::min(r.x + r.w, clip_.x + clip_.w), y1 = std::min(r.y + r.h, clip_.y + clip_.h);
    if (x1 <= x0 || y1 <= y0) return;
    r = Rect{x0, y0, x1 - x0, y1 - y0};
  }
  hits_.push_back(Hit{r, std::move(fn)});
  hitLabels_.push_back(label);
}

const App::Hit* App::hitAt(float x, float y) const {
  for (size_t i = hits_.size(); i-- > 0;)
    if (hits_[i].r.contains(x, y)) return &hits_[i];
  return nullptr;
}

bool App::tapLabel(const std::string& label) {
  for (size_t i = hitLabels_.size(); i-- > 0;) {
    if (hitLabels_[i] == label) {
      if (hits_[i].fn) hits_[i].fn();
      return true;
    }
  }
  return false;
}

void App::centeredText(DrawList& dl, Rect r, const std::string& s, float h, Color c) {
  if (s.empty()) return;
  float maxH = (r.w - 6.f) / (0.5f * static_cast<float>(s.size()));
  h = std::min(h, std::max(7.f, maxH));
  float tw = dl.textWidth(s, h);
  dl.text(r.x + (r.w - tw) / 2.f, r.y + (r.h - h) / 2.f, h, c, s);
}

void App::button(DrawList& dl, Rect r, const std::string& label, Color bg, Color fg, std::function<void()> fn,
                 float textH) {
  dl.rrect(r.x, r.y, r.w, r.h, 8.f, bg);
  centeredText(dl, r, label, textH, fg);
  addHit(r, std::move(fn), label);
}

void App::stepper(DrawList& dl, float x, float y, float w, const std::string& label, float value, float step,
                  std::function<void(float)> set, bool integer) {
  const float groupW = 34 + 4 + 76 + 4 + 34;
  float gx = x + w - groupW;
  if (!label.empty() && gx - x >= dl.textWidth(label, 12.f) + 4.f) dl.text(x, y + 10, 12.f, SUB, label);
  button(dl, Rect{gx, y, 34, 32}, "-", PANEL2, TEXT, [=]() { set(value - step); }, 16.f);
  Rect vr{gx + 38, y, 76, 32};
  dl.rrect(vr.x, vr.y, vr.w, vr.h, 8.f, BG);
  centeredText(dl, vr, num2(value), 13.f, TEXT);
  addHit(vr, [=]() { openKeypad(label.empty() ? "Value" : label, value, set, integer); }, "value:" + label);
  button(dl, Rect{gx + 118, y, 34, 32}, "+", PANEL2, TEXT, [=]() { set(value + step); }, 16.f);
}

void App::paramRow(DrawList& dl, float x, float& y, float w, const std::string& name, const std::string& value,
                   std::function<void()> onTap) {
  dl.text(x, y + 11, 13.f, TEXT, name);
  Rect r{x + w - 130, y + 2, 130, 32};
  dl.rrect(r.x, r.y, r.w, r.h, 8.f, PANEL2);
  centeredText(dl, r, value, 13.f, ACCENT);
  addHit(r, std::move(onTap), "param:" + name);
  y += 38.f;
}

// ================================================================= keypad
void App::openKeypad(const std::string& title, float value, std::function<void(float)> apply, bool integer) {
  pad_.open = true;
  pad_.fresh = true;
  pad_.integer = integer;
  pad_.title = title;
  pad_.text = numEdit(integer ? std::round(value) : value);
  pad_.apply = std::move(apply);
}

void App::keypadKey(const std::string& k) {
  if (k == "OK") {
    const std::string& t = pad_.text;
    char* end = nullptr;
    float v = std::strtof(t.c_str(), &end);
    if (t.empty() || t == "-" || t == "." || t == "-." || end == t.c_str() || *end != '\0' || !std::isfinite(v)) {
      toast("That isn't a number");
      return;
    }
    if (pad_.integer) v = std::round(v);
    auto fn = pad_.apply;
    pad_.open = false;
    if (fn) fn(v);
    return;
  }
  if (k == "Cancel") {
    pad_.open = false;
    return;
  }
  if (k == "DEL") {
    if (pad_.fresh) {
      pad_.text.clear();
      pad_.fresh = false;
    } else if (!pad_.text.empty()) {
      pad_.text.pop_back();
    }
    return;
  }
  if (k == "+/-") {
    pad_.fresh = false;
    if (!pad_.text.empty() && pad_.text[0] == '-')
      pad_.text.erase(0, 1);
    else
      pad_.text = "-" + pad_.text;
    return;
  }
  if (pad_.text.size() >= 12 && !pad_.fresh) return;
  if (k == ".") {
    if (pad_.integer) return;
    if (pad_.fresh) {
      pad_.text = "0.";
      pad_.fresh = false;
    } else if (pad_.text.find('.') == std::string::npos) {
      pad_.text += pad_.text.empty() || pad_.text == "-" ? "0." : ".";
    }
    return;
  }
  if (k.size() == 1 && k[0] >= '0' && k[0] <= '9') {
    if (pad_.fresh) {
      pad_.text = k;
      pad_.fresh = false;
    } else if (pad_.text == "0") {
      pad_.text = k;
    } else if (pad_.text == "-0") {
      pad_.text = "-" + k;
    } else {
      pad_.text += k;
    }
  }
}

void App::drawKeypad(DrawList& dl) {
  dl.rect(0, 0, W_, H_, rgba(0, 0, 0, 160));
  addHit(Rect{0, 0, W_, H_}, [this]() { pad_.open = false; }, "keypad:backdrop");
  const float keyH = 52.f, gap = 8.f;
  float ph = 14 + 22 + 50 + gap + 4 * (keyH + gap) + 6;
  Rect panel{0, H_ - ph, W_, ph};
  dl.rrect(panel.x, panel.y, panel.w, panel.h + 20, 18.f, PANEL);
  addHit(panel, nullptr, "keypad:panel");
  dl.text(18, panel.y + 12, 13.f, SUB, pad_.title);
  Rect disp{16, panel.y + 34, W_ - 32, 46};
  dl.rrect(disp.x, disp.y, disp.w, disp.h, 10.f, BG);
  std::string shown = pad_.text.empty() ? "0" : pad_.text;
  dl.text(disp.x + 12, disp.y + 10, 26.f, pad_.fresh ? ACCENT : TEXT, shown);
  float kw = (W_ - 32 - 3 * gap) / 4.f;
  float y0 = disp.y + disp.h + gap;
  auto key = [&](int row, int col, int span, const std::string& label, Color bg, Color fg) {
    Rect r{16 + col * (kw + gap), y0 + row * (keyH + gap), kw * span + gap * (span - 1), keyH};
    button(dl, r, label, bg, fg, [this, label]() { keypadKey(label); }, 20.f);
  };
  const char* rows[3][3] = {{"7", "8", "9"}, {"4", "5", "6"}, {"1", "2", "3"}};
  for (int r = 0; r < 3; ++r)
    for (int c = 0; c < 3; ++c) key(r, c, 1, rows[r][c], PANEL2, TEXT);
  key(0, 3, 1, "DEL", PANEL2, CORAL);
  key(1, 3, 1, "+/-", PANEL2, AMBER);
  key(2, 3, 1, "Cancel", PANEL2, SUB);
  key(3, 0, 1, "0", PANEL2, TEXT);
  key(3, 1, 1, ".", PANEL2, TEXT);
  key(3, 2, 2, "OK", ACCENT, rgba(255, 255, 255));
}

// ================================================================= chrome
void App::drawTopBar(DrawList& dl) {
  dl.rect(0, 0, W_, TOP, PANEL);
  dl.rect(0, TOP - 1, W_, 1, LINEC);
  dl.text(16, 8, 20, TEXT, "NodeLab");
  std::string nm = presetName_.size() > 20 ? presetName_.substr(0, 19) + "." : presetName_;
  dl.text(16, 33, 12, SUB, nm);
  std::string chip = training_ ? "Training " + lossStr(trainer_.lastLoss)
                               : (trainer_.epochsDone > 0 ? "Loss " + lossStr(trainer_.lastLoss) : "Not trained");
  float cw = dl.textWidth(chip, 12.f) + 22.f;
  dl.rrect(W_ - 14 - cw, 14, cw, 28, 14.f, PANEL2);
  dl.text(W_ - 14 - cw + 11, 21, 12.f, training_ ? TEAL : TEXT, chip);
}

void App::drawNav(DrawList& dl) {
  float y = H_ - NAV;
  dl.rect(0, y, W_, NAV, PANEL);
  dl.rect(0, y, W_, 1, LINEC);
  const char* names[3] = {"Build", "Train", "Presets"};
  float bw = W_ / 3.f;
  for (int i = 0; i < 3; ++i) {
    bool on = static_cast<int>(tab_) == i;
    Color c = on ? ACCENT : SUB;
    Rect r{i * bw, y, bw, NAV};
    float cx = r.x + bw / 2.f, cy = y + 19;
    if (i == 0) {
      dl.line(cx - 8, cy + 3, cx + 8, cy - 3, 2.f, c);
      dl.circle(cx - 8, cy + 3, 4.5f, c);
      dl.circle(cx + 8, cy - 3, 4.5f, c);
    } else if (i == 1) {
      dl.tri(cx - 6, cy - 9, cx - 6, cy + 9, cx + 9, cy, c);
    } else {
      for (int k = 0; k < 3; ++k) dl.rrect(cx - 9, cy - 8 + k * 7, 18, 3.f, 1.5f, c);
    }
    centeredText(dl, Rect{r.x, y + 33, bw, 20}, names[i], 12.f, c);
    if (on) dl.rrect(r.x + bw / 2 - 16, y + 1, 32, 3, 1.5f, ACCENT);
    Tab t = static_cast<Tab>(i);
    addHit(r, [this, t]() { tab_ = t; }, std::string("nav:") + names[i]);
  }
}

void App::drawToast(DrawList& dl) {
  if (now_ >= toastUntil_ || toastMsg_.empty()) return;
  std::string m = toastMsg_;
  size_t maxC = static_cast<size_t>((W_ - 40) / 6.5f);
  std::vector<std::string> lines = wrapText(m, maxC);
  if (lines.size() > 2) lines.resize(2);
  float w = 0;
  for (auto& l : lines) w = std::max(w, dl.textWidth(l, 13.f));
  w += 28;
  float h = 14 + lines.size() * 17.f;
  float x = (W_ - w) / 2.f, y = H_ - NAV - h - 14;
  dl.rrect(x, y, w, h, 12.f, rgba(230, 234, 255, 245));
  for (size_t i = 0; i < lines.size(); ++i) dl.text(x + 14, y + 8 + i * 17.f, 13.f, rgba(20, 24, 44), lines[i]);
}

// ================================================================= build tab
void App::nodeScreen(const Node& n, float& sx, float& sy) const {
  sx = n.x + panX_;
  sy = canvas_.y + n.y + panY_;
}

bool App::nodePixelPos(int id, float& xpx, float& ypx) const {
  int i = net_.nodeIndex(id);
  if (i < 0) return false;
  float sx, sy;
  nodeScreen(net_.nodes[i], sx, sy);
  xpx = sx * density_;
  ypx = sy * density_;
  return true;
}

int App::pickNode(float x, float y) const {
  for (size_t i = net_.nodes.size(); i-- > 0;) {
    float sx, sy;
    nodeScreen(net_.nodes[i], sx, sy);
    float dx = x - sx, dy = y - sy;
    if (dx * dx + dy * dy <= (NODE_R + 8) * (NODE_R + 8)) return static_cast<int>(i);
  }
  return -1;
}

int App::pickEdge(float x, float y) const {
  int best = -1;
  float bd = 16.f;
  for (size_t i = 0; i < net_.edges.size(); ++i) {
    int a = net_.nodeIndex(net_.edges[i].from), b = net_.nodeIndex(net_.edges[i].to);
    if (a < 0 || b < 0) continue;
    float ax, ay, bx, by;
    nodeScreen(net_.nodes[a], ax, ay);
    nodeScreen(net_.nodes[b], bx, by);
    float d = distToSegment(x, y, ax, ay, bx, by);
    if (d < bd) {
      bd = d;
      best = static_cast<int>(i);
    }
  }
  return best;
}

void App::canvasTap(float x, float y) {
  int ni = pickNode(x, y);
  int ei = ni < 0 ? pickEdge(x, y) : -1;
  switch (tool_) {
    case Tool::Move:
      if (ni >= 0) {
        selNode_ = net_.nodes[ni].id;
        selEdge_ = -1;
      } else if (ei >= 0) {
        selEdge_ = ei;
        selNode_ = -1;
      } else {
        selNode_ = selEdge_ = -1;
      }
      break;
    case Tool::Link:
      if (ni >= 0) {
        int id = net_.nodes[ni].id;
        if (linkFrom_ < 0) {
          linkFrom_ = id;
          toast("Now tap the node to connect it to");
        } else if (id == linkFrom_) {
          linkFrom_ = -1;
        } else {
          std::string err, err2;
          int a = linkFrom_, b = id;
          bool ok = net_.connect(a, b, &err);
          if (!ok && net_.connect(b, a, &err2)) {  // wired the "wrong" way round: flip it for them
            ok = true;
            std::swap(a, b);
          }
          if (ok) {
            netEdited(true);
            selEdge_ = net_.edgeIndex(a, b);
            selNode_ = -1;
          } else {
            toast(err);
          }
          linkFrom_ = -1;
        }
      } else {
        linkFrom_ = -1;
      }
      break;
    case Tool::Erase:
      if (ni >= 0) {
        net_.removeNode(net_.nodes[ni].id);
        selNode_ = -1;
        netEdited(true);
      } else if (ei >= 0) {
        net_.removeEdge(ei);
        netEdited(true);
      }
      break;
  }
}

void App::drawInspector(DrawList& dl, float bottom) {
  if (selNode_ >= 0 && net_.nodeIndex(selNode_) < 0) selNode_ = -1;
  if (selEdge_ >= static_cast<int>(net_.edges.size())) selEdge_ = -1;
  if (selNode_ < 0 && selEdge_ < 0) return;

  std::vector<std::string> lines;
  std::string title;
  int ni = selNode_ >= 0 ? net_.nodeIndex(selNode_) : -1;
  if (ni >= 0) {
    const Node& n = net_.nodes[ni];
    title = nodeLabel(net_, ni) + "  " + kindName(n.kind);
    if (n.kind == Kind::Input) {
      lines.push_back("value = " + num2(n.input));
    } else {
      const std::vector<int>& inc = net_.incoming(ni);
      int shown = 0;
      for (int e : inc) {
        if (shown >= 3) break;
        const Edge& ed = net_.edges[e];
        int p = net_.nodeIndex(ed.from);
        float pv = net_.nodes[p].value;
        lines.push_back(nodeLabel(net_, p) + ": " + sgn2(ed.w) + " x " + num2(pv) + " = " + sgn2(ed.w * pv));
        ++shown;
      }
      if (inc.size() > 3) lines.push_back("+" + std::to_string(inc.size() - 3) + " more wires");
      if (inc.empty()) lines.push_back("no incoming wires yet");
      lines.push_back("sum + bias " + num2(n.bias) + " = " + num2(n.sum));
      lines.push_back(std::string(actShort(n.act)) + "(" + num2(n.sum) + ") = " + num2(n.value));
    }
  } else {
    const Edge& e = net_.edges[selEdge_];
    int a = net_.nodeIndex(e.from), b = net_.nodeIndex(e.to);
    title = nodeLabel(net_, a) + " -> " + nodeLabel(net_, b) + "  wire";
    float pv = net_.nodes[a].value;
    lines.push_back(nodeLabel(net_, b) + " gets " + sgn2(e.w) + " x " + num2(pv) + " = " + sgn2(e.w * pv));
  }
  float ph = 14 + 26 + 42 + lines.size() * 15.f + 10;
  Rect p{8, bottom - ph - 8, W_ - 16, ph};
  dl.rrect(p.x - 1, p.y - 1, p.w + 2, p.h + 2, 13.f, LINEC);
  dl.rrect(p.x, p.y, p.w, p.h, 12.f, PANEL);
  addHit(p, nullptr, "inspector");
  dl.text(p.x + 14, p.y + 12, 14.f, TEXT, title);
  float cy = p.y + 40;

  if (ni >= 0) {
    int id = selNode_;
    button(dl, Rect{p.x + p.w - 84, p.y + 6, 76, 28}, "Delete", rgba(90, 36, 48), CORAL, [this, id]() {
      net_.removeNode(id);
      selNode_ = -1;
      netEdited(true);
    }, 12.f);
    const Node& n = net_.nodes[ni];
    if (n.kind == Kind::Input) {
      stepper(dl, p.x + 14, cy, p.w - 28, "Value", n.input, 0.1f, [this, id](float v) {
        int i = net_.nodeIndex(id);
        if (i >= 0) {
          net_.nodes[i].input = v;
          netEdited(false);
        }
      });
    } else {
      button(dl, Rect{p.x + 14, cy, 104, 32}, actName(n.act), PANEL2, ACCENT, [this, id]() {
        int i = net_.nodeIndex(id);
        if (i >= 0) {
          net_.nodes[i].act = nextAct(net_.nodes[i].act);
          netEdited(false);
        }
      }, 13.f);
      float sx = p.x + 14 + 112;
      stepper(dl, sx, cy, p.x + p.w - 14 - sx, "Bias", n.bias, 0.1f, [this, id](float v) {
        int i = net_.nodeIndex(id);
        if (i >= 0) {
          net_.nodes[i].bias = v;
          netEdited(false);
        }
      });
    }
  } else {
    int ei = selEdge_;
    button(dl, Rect{p.x + p.w - 84, p.y + 6, 76, 28}, "Delete", rgba(90, 36, 48), CORAL, [this, ei]() {
      net_.removeEdge(ei);
      netEdited(true);
    }, 12.f);
    button(dl, Rect{p.x + 14, cy, 70, 32}, "Flip +/-", PANEL2, AMBER, [this, ei]() {
      if (ei >= 0 && ei < static_cast<int>(net_.edges.size())) {
        net_.edges[ei].w = -net_.edges[ei].w;
        netEdited(false);
      }
    }, 12.f);
    float sx = p.x + 14 + 78;
    stepper(dl, sx, cy, p.x + p.w - 14 - sx, "", net_.edges[ei].w, 0.1f, [this, ei](float v) {
      if (ei >= 0 && ei < static_cast<int>(net_.edges.size())) {
        net_.edges[ei].w = v;
        netEdited(false);
      }
    });
  }
  float ly = cy + 42;
  for (size_t i = 0; i < lines.size(); ++i)
    dl.text(p.x + 14, ly + i * 15.f, 11.f, i + 1 == lines.size() ? TEAL : SUB, lines[i]);
}

void App::drawBuild(DrawList& dl) {
  float top = TOP + TOOLH;
  std::vector<std::string> probs = net_.check();
  float warnH = probs.empty() ? 0.f : 30.f;
  canvas_ = Rect{0, top + warnH, W_, H_ - NAV - top - warnH};

  setClip(dl, canvas_);
  // faint grid that follows the pan so movement is visible
  const float gs = 40.f;
  float ox = std::fmod(panX_, gs), oy = std::fmod(panY_, gs);
  if (ox < 0) ox += gs;
  if (oy < 0) oy += gs;
  for (float x = canvas_.x + ox; x < canvas_.x + canvas_.w; x += gs) dl.rect(x, canvas_.y, 1, canvas_.h, rgba(255, 255, 255, 9));
  for (float y = canvas_.y + oy; y < canvas_.y + canvas_.h; y += gs) dl.rect(canvas_.x, y, canvas_.w, 1, rgba(255, 255, 255, 9));

  // wires
  for (size_t i = 0; i < net_.edges.size(); ++i) {
    const Edge& e = net_.edges[i];
    int a = net_.nodeIndex(e.from), b = net_.nodeIndex(e.to);
    if (a < 0 || b < 0) continue;
    float ax, ay, bx, by;
    nodeScreen(net_.nodes[a], ax, ay);
    nodeScreen(net_.nodes[b], bx, by);
    float dx = bx - ax, dy = by - ay, len = std::sqrt(dx * dx + dy * dy);
    if (len < 1.f) continue;
    float ux = dx / len, uy = dy / len;
    float sx = ax + ux * NODE_R, sy = ay + uy * NODE_R, ex = bx - ux * (NODE_R + 3), ey = by - uy * (NODE_R + 3);
    Color wc = e.w >= 0 ? TEAL : CORAL;
    float th = 1.5f + std::min(4.5f, std::fabs(e.w) * 2.2f);
    bool sel = static_cast<int>(i) == selEdge_;
    if (sel) dl.line(sx, sy, ex, ey, th + 5.f, rgba(255, 255, 255, 80));
    dl.line(sx, sy, ex, ey, th, withAlpha(wc, sel ? 255 : 190));
    dl.tri(ex, ey, ex - ux * 11 + uy * 5.5f, ey - uy * 11 - ux * 5.5f, ex - ux * 11 - uy * 5.5f, ey - uy * 11 + ux * 5.5f,
           withAlpha(wc, sel ? 255 : 210));
  }
  for (size_t i = 0; i < net_.edges.size(); ++i) {  // labels on top of all wires
    const Edge& e = net_.edges[i];
    int a = net_.nodeIndex(e.from), b = net_.nodeIndex(e.to);
    if (a < 0 || b < 0) continue;
    float ax, ay, bx, by;
    nodeScreen(net_.nodes[a], ax, ay);
    nodeScreen(net_.nodes[b], bx, by);
    std::string s = num2(e.w);
    float tw = dl.textWidth(s, 10.f) + 8.f;
    float mx = (ax + bx) / 2.f, my = (ay + by) / 2.f;
    dl.rrect(mx - tw / 2, my - 7, tw, 14, 7.f, rgba(15, 18, 32, 225));
    dl.text(mx - tw / 2 + 4, my - 5, 10.f, e.w >= 0 ? TEAL : CORAL, s);
  }

  // nodes
  for (size_t i = 0; i < net_.nodes.size(); ++i) {
    const Node& n = net_.nodes[i];
    float sx, sy;
    nodeScreen(n, sx, sy);
    Color kc = kindColor(n.kind);
    bool sel = n.id == selNode_, lf = n.id == linkFrom_;
    dl.circle(sx, sy, NODE_R + 3.f, sel ? rgba(255, 255, 255) : (lf ? AMBER : kc));
    dl.circle(sx, sy, NODE_R, rgba(20, 24, 42));
    float v = n.kind == Kind::Input ? n.input : n.value;
    int glow = 30 + static_cast<int>(130.f * std::min(1.f, std::fabs(std::isfinite(v) ? v : 0.f)));
    dl.circle(sx, sy, NODE_R - 2.f, withAlpha(kc, glow));
    std::string vs = num2(v);
    float th = std::min(13.f, (NODE_R * 2 - 8) / (0.5f * vs.size()));
    dl.text(sx - dl.textWidth(vs, th) / 2, sy - th / 2, th, rgba(255, 255, 255), vs);
    std::string lab = nodeLabel(net_, static_cast<int>(i));
    if (n.kind != Kind::Input) lab += std::string(" ") + actShort(n.act);
    dl.text(sx - dl.textWidth(lab, 10.f) / 2, sy + NODE_R + 6, 10.f, SUB, lab);
  }

  if (tool_ == Tool::Link)
    dl.text(12, canvas_.y + 8, 11.f, AMBER, linkFrom_ >= 0 ? "Tap the node to connect to" : "Tap a node, then another, to wire them");
  else if (tool_ == Tool::Erase)
    dl.text(12, canvas_.y + 8, 11.f, CORAL, "Tap a node or a wire to delete it");
  else if (net_.nodes.empty())
    dl.text(12, canvas_.y + 8, 11.f, SUB, "Empty canvas. Add nodes with the + buttons above.");
  clearClip(dl);

  // tool row
  dl.rect(0, TOP, W_, TOOLH, BG);
  float bw = (W_ - 16 - 5 * 6) / 6.f;
  struct T {
    const char* label;
    bool tool;
    Tool t;
    Kind k;
  } items[6] = {{"Move", true, Tool::Move, Kind::Hidden}, {"Link", true, Tool::Link, Kind::Hidden},
                {"Erase", true, Tool::Erase, Kind::Hidden}, {"+Input", false, Tool::Move, Kind::Input},
                {"+Hidden", false, Tool::Move, Kind::Hidden}, {"+Output", false, Tool::Move, Kind::Output}};
  for (int i = 0; i < 6; ++i) {
    Rect r{8 + i * (bw + 6), TOP + 6, bw, 40};
    if (items[i].tool) {
      bool on = tool_ == items[i].t;
      Tool tt = items[i].t;
      button(dl, r, items[i].label, on ? ACCENT : PANEL2, on ? rgba(255, 255, 255) : TEXT, [this, tt]() {
        if (tt == Tool::Move && tool_ == Tool::Move) frameView();  // tapping Move again recentres the graph
        tool_ = tt;
        linkFrom_ = -1;
      }, 12.f);
    } else {
      Kind kk = items[i].k;
      button(dl, r, items[i].label, PANEL2, kindColor(kk), [this, kk]() { addNode(kk); }, 12.f);
    }
  }

  if (!probs.empty()) {
    Rect r{8, top + 3, W_ - 16, 24};
    std::string s = probs[0] + (probs.size() > 1 ? "  (+" + std::to_string(probs.size() - 1) + ")" : "");
    dl.rrect(r.x, r.y, r.w, r.h, 12.f, withAlpha(AMBER, 235));
    dl.text(r.x + 12, r.y + 6, 12.f, rgba(40, 28, 0), s.size() > static_cast<size_t>((r.w - 24) / 6.f) ? s.substr(0, static_cast<size_t>((r.w - 24) / 6.f)) : s);
    addHit(r, [this]() { autoFix(); }, "warning");
  }

  drawInspector(dl, canvas_.y + canvas_.h);
}

// ================================================================= train tab
void App::drawTrain(DrawList& dl) {
  Rect view{0, TOP, W_, H_ - NAV - TOP};
  setClip(dl, view);
  const float x = 12, w = W_ - 24;
  float y = TOP + 10 - scroll_[1];
  const float startY = y;

  // ---- status + loss chart
  {
    const float h = 236;
    dl.rrect(x, y, w, h, 14.f, PANEL);
    float cy = y + 12;
    dl.text(x + 14, cy, 11.f, SUB, "LOSS");
    dl.text(x + 14, cy + 14, 28.f, training_ ? TEAL : TEXT, trainer_.epochsDone ? lossStr(trainer_.lastLoss) : "--");
    std::string ep = "Epoch " + std::to_string(trainer_.epochsDone);
    dl.text(x + w - 14 - dl.textWidth(ep, 12.f), cy + 4, 12.f, SUB, ep);
    std::string lim = "run of " + std::to_string(cfg_.epochs);
    dl.text(x + w - 14 - dl.textWidth(lim, 11.f), cy + 20, 11.f, SUB, lim);

    Rect ch{x + 14, cy + 52, w - 28, 80};
    dl.rrect(ch.x, ch.y, ch.w, ch.h, 8.f, BG);
    const std::vector<float>& hs = trainer_.history;
    if (hs.size() < 2) {
      centeredText(dl, ch, "Press Train to draw the loss curve", 12.f, SUB);
    } else {
      float mn = 1e30f, mx = 0.f;
      for (float v : hs) {
        mn = std::min(mn, std::max(v, 1e-7f));
        mx = std::max(mx, std::max(v, 1e-7f));
      }
      float lo = std::log10(mn), hi = std::log10(mx);
      if (hi - lo < 0.5f) {
        hi += 0.25f;
        lo -= 0.25f;
      }
      size_t N = std::min<size_t>(hs.size(), 220);
      float px = 0, py = 0;
      for (size_t i = 0; i < N; ++i) {
        float v = hs[i * (hs.size() - 1) / (N - 1)];
        float t = (std::log10(std::max(v, 1e-7f)) - lo) / (hi - lo);
        float qx = ch.x + 8 + (ch.w - 16) * i / static_cast<float>(N - 1);
        float qy = ch.y + ch.h - 8 - (ch.h - 16) * t;
        if (i > 0) dl.line(px, py, qx, qy, 1.8f, TEAL);
        px = qx;
        py = qy;
      }
      dl.text(ch.x + 6, ch.y + 4, 9.f, SUB, lossStr(std::pow(10.f, hi)));
      dl.text(ch.x + 6, ch.y + ch.h - 13, 9.f, SUB, lossStr(std::pow(10.f, lo)));
    }
    float by = cy + 142;
    float bw1 = (w - 28 - 8) * 0.55f;
    button(dl, Rect{x + 14, by, bw1, 40}, training_ ? "Stop" : "Train", training_ ? rgba(120, 50, 60) : ACCENT,
           rgba(255, 255, 255), [this]() { training_ ? stopTraining() : startTraining(); }, 15.f);
    button(dl, Rect{x + 14 + bw1 + 8, by, w - 28 - bw1 - 8, 40}, "Reset weights", PANEL2, TEXT, [this]() { resetWeights(); }, 12.f);
    Color sc = trainer_.diverged ? CORAL : (!training_ && trainer_.epochsDone && cfg_.targetLoss > 0 && trainer_.lastLoss <= cfg_.targetLoss ? TEAL : SUB);
    std::vector<std::string> sl = wrapText(statusText(), static_cast<size_t>((w - 28) / 6.f));
    for (size_t i = 0; i < sl.size() && i < 2; ++i) dl.text(x + 14, by + 48 + i * 15.f, 12.f, sc, sl[i]);
    y += h + 12;
  }

  // ---- trainer settings
  {
    std::vector<std::string> labels;
    std::vector<TrainerCfg> srcs;
    for (auto& t : builtinTrainers_) {
      labels.push_back(t.name);
      srcs.push_back(t);
    }
    for (auto& t : customTrainers_) {
      labels.push_back(t.name);
      srcs.push_back(t);
    }
    std::vector<Rect> chips;
    float cx = x + 14, cyy = 0, maxX = x + w - 14;
    for (auto& l : labels) {
      float cw = dl.textWidth(l, 12.f) + 24.f;
      if (cx + cw > maxX && cx > x + 14) {
        cx = x + 14;
        cyy += 38;
      }
      chips.push_back(Rect{cx, cyy, cw, 30});
      cx += cw + 8;
    }
    float chipsH = labels.empty() ? 0.f : cyy + 30;
    int rows = 7 + (cfg_.opt == OptKind::Momentum ? 1 : 0);
    float h = 12 + 18 + chipsH + 12 + rows * 38.f + 8 + 40 + 14;
    dl.rrect(x, y, w, h, 14.f, PANEL);
    dl.text(x + 14, y + 12, 11.f, SUB, "TRAINER  (pick one or make your own)");
    float chipTop = y + 34;
    for (size_t i = 0; i < chips.size(); ++i) {
      Rect r{chips[i].x, chipTop + chips[i].y, chips[i].w, chips[i].h};
      bool on = cfg_.name == labels[i];
      TrainerCfg c = srcs[i];
      button(dl, r, labels[i], on ? ACCENT : PANEL2, on ? rgba(255, 255, 255) : TEXT, [this, c]() {
        cfg_ = c;
        toast("Trainer: " + c.name);
      }, 12.f);
    }
    float ry = chipTop + chipsH + 12;
    float rx = x + 14, rw = w - 28;
    auto edited = [this]() { cfg_.name = "Custom"; };
    paramRow(dl, rx, ry, rw, "Optimizer", optName(cfg_.opt), [this, edited]() {
      cfg_.opt = nextOpt(cfg_.opt);
      edited();
    });
    paramRow(dl, rx, ry, rw, "Loss", lossName(cfg_.loss), [this, edited]() {
      cfg_.loss = nextLoss(cfg_.loss);
      edited();
    });
    paramRow(dl, rx, ry, rw, "Learning rate", numS(cfg_.lr), [this, edited]() {
      openKeypad("Learning rate", cfg_.lr, [this, edited](float v) {
        cfg_.lr = std::max(1e-6f, v);
        edited();
      });
    });
    if (cfg_.opt == OptKind::Momentum)
      paramRow(dl, rx, ry, rw, "Momentum", numS(cfg_.momentum), [this, edited]() {
        openKeypad("Momentum (0 to 0.99)", cfg_.momentum, [this, edited](float v) {
          cfg_.momentum = std::max(0.f, std::min(0.99f, v));
          edited();
        });
      });
    paramRow(dl, rx, ry, rw, "Epochs", std::to_string(cfg_.epochs), [this, edited]() {
      openKeypad("Epochs per run", static_cast<float>(cfg_.epochs), [this, edited](float v) {
        cfg_.epochs = static_cast<int>(std::max(1.f, std::min(1000000.f, v)));
        edited();
      }, true);
    });
    paramRow(dl, rx, ry, rw, "Batch (0=all)", std::to_string(cfg_.batch), [this, edited]() {
      openKeypad("Batch size (0 = whole dataset)", static_cast<float>(cfg_.batch), [this, edited](float v) {
        cfg_.batch = static_cast<int>(std::max(0.f, std::min(10000.f, v)));
        edited();
      }, true);
    });
    paramRow(dl, rx, ry, rw, "Shuffle", cfg_.shuffle ? "On" : "Off", [this, edited]() {
      cfg_.shuffle = !cfg_.shuffle;
      edited();
    });
    paramRow(dl, rx, ry, rw, "Stop at loss", cfg_.targetLoss > 0 ? lossStr(cfg_.targetLoss) : "never", [this, edited]() {
      openKeypad("Stop when loss is below (0 = never)", cfg_.targetLoss, [this, edited](float v) {
        cfg_.targetLoss = std::max(0.f, v);
        edited();
      });
    });
    ry += 8;
    button(dl, Rect{rx, ry, rw, 40}, "Save as my trainer", PANEL2, TEAL, [this]() {
      std::string nm;
      for (int n = static_cast<int>(customTrainers_.size()) + 1;; ++n) {
        nm = "My trainer " + std::to_string(n);
        bool used = false;
        for (auto& t : customTrainers_) used |= t.name == nm;
        if (!used) break;
      }
      TrainerCfg c = cfg_;
      c.name = nm;
      customTrainers_.push_back(c);
      cfg_.name = nm;
      saveState();
      toast("Saved " + nm);
    }, 13.f);
    y += h + 12;
  }

  // ---- training data
  {
    size_t nIn = net_.inputIds().size(), nOut = net_.outputIds().size();
    std::string err;
    bool ok = datasetCompatible(net_, data_, &err);
    bool noRows = nIn > 0 && nOut > 0 && data_.rows() == 0;
    std::string title = "TRAINING DATA  (" + std::to_string(data_.rows()) + " rows)";
    if (!ok && !noRows) {
      float h = 12 + 18 + 40 + 44 + 14;
      dl.rrect(x, y, w, h, 14.f, PANEL);
      dl.text(x + 14, y + 12, 11.f, SUB, title);
      std::vector<std::string> el = wrapText(err, static_cast<size_t>((w - 28) / 6.5f));
      for (size_t i = 0; i < el.size() && i < 2; ++i) dl.text(x + 14, y + 34 + i * 16.f, 13.f, AMBER, el[i]);
      if (nIn > 0 && nOut > 0)
        button(dl, Rect{x + 14, y + 12 + 18 + 40, w - 28, 40}, "Fix columns", PANEL2, AMBER, [this]() { autoFix(); }, 13.f);
      y += h + 12;
    } else {
      size_t cols = nIn + 2 * nOut;
      float cw = std::min(70.f, (w - 28 - 30) / static_cast<float>(cols));
      float h = 12 + 18 + 22 + data_.rows() * 34.f + 8 + 40 + 14;
      dl.rrect(x, y, w, h, 14.f, PANEL);
      dl.text(x + 14, y + 12, 11.f, SUB, title);
      float hy = y + 34, x0 = x + 14;
      for (size_t c = 0; c < nIn; ++c) centeredText(dl, Rect{x0 + c * cw, hy, cw, 16}, "x" + std::to_string(c + 1), 11.f, KIN);
      for (size_t c = 0; c < nOut; ++c) {
        centeredText(dl, Rect{x0 + (nIn + c) * cw, hy, cw, 16}, "y" + std::to_string(c + 1), 11.f, KOUT);
        centeredText(dl, Rect{x0 + (nIn + nOut + c) * cw, hy, cw, 16}, "out" + std::to_string(c + 1), 11.f, TEAL);
      }
      // predictions for every row (restore the user's test inputs afterwards)
      std::vector<std::vector<float>> preds;
      if (ok) {
        std::vector<float> saved;
        for (int id : net_.inputIds()) saved.push_back(net_.nodes[net_.nodeIndex(id)].input);
        for (size_t r = 0; r < data_.rows(); ++r) {
          net_.setInputs(data_.X[r]);
          net_.forward();
          preds.push_back(net_.outputs());
        }
        net_.setInputs(saved);
        net_.forward();
      }
      float ry = hy + 22;
      for (size_t r = 0; r < data_.rows(); ++r) {
        for (size_t c = 0; c < nIn; ++c) {
          Rect cell{x0 + c * cw + 2, ry, cw - 4, 30};
          dl.rrect(cell.x, cell.y, cell.w, cell.h, 7.f, PANEL2);
          centeredText(dl, cell, numS(data_.X[r][c]), 12.f, TEXT);
          addHit(cell, [this, r, c]() {
            if (r >= data_.rows() || c >= data_.X[r].size()) return;
            openKeypad("x" + std::to_string(c + 1) + "  (row " + std::to_string(r + 1) + ")", data_.X[r][c], [this, r, c](float v) {
              if (r < data_.rows() && c < data_.X[r].size()) data_.X[r][c] = v;
            });
          }, "x" + std::to_string(r) + "," + std::to_string(c));
        }
        for (size_t c = 0; c < nOut; ++c) {
          Rect cell{x0 + (nIn + c) * cw + 2, ry, cw - 4, 30};
          dl.rrect(cell.x, cell.y, cell.w, cell.h, 7.f, PANEL2);
          centeredText(dl, cell, numS(data_.Y[r][c]), 12.f, KOUT);
          addHit(cell, [this, r, c]() {
            if (r >= data_.rows() || c >= data_.Y[r].size()) return;
            openKeypad("y" + std::to_string(c + 1) + "  (row " + std::to_string(r + 1) + ")", data_.Y[r][c], [this, r, c](float v) {
              if (r < data_.rows() && c < data_.Y[r].size()) data_.Y[r][c] = v;
            });
          }, "y" + std::to_string(r) + "," + std::to_string(c));
          if (ok) {
            Rect pc{x0 + (nIn + nOut + c) * cw + 2, ry, cw - 4, 30};
            float pv = preds[r][c], tv = data_.Y[r][c];
            float err2 = std::fabs(pv - tv);
            centeredText(dl, pc, numS(pv), 12.f, err2 < 0.1f ? TEAL : (err2 < 0.3f ? AMBER : CORAL));
          }
        }
        Rect del{x0 + cols * cw + 4, ry + 2, 26, 26};
        button(dl, del, "x", rgba(90, 36, 48), CORAL, [this, r]() { data_.removeRow(r); }, 13.f);
        ry += 34;
      }
      float by = ry + 8;
      button(dl, Rect{x + 14, by, w - 28, 40}, "+ Add row", PANEL2, TEAL, [this, nIn, nOut]() { data_.addRow(nIn, nOut); }, 13.f);
      y += h + 12;
    }
  }

  contentH_[1] = (y - startY) + 20;
  float viewH = view.h;
  float maxScroll = std::max(0.f, contentH_[1] - viewH + 10);
  scroll_[1] = std::max(0.f, std::min(scroll_[1], maxScroll));
  clearClip(dl);
}

// ================================================================= presets tab
void App::drawPresets(DrawList& dl) {
  Rect view{0, TOP, W_, H_ - NAV - TOP};
  setClip(dl, view);
  const float x = 12, w = W_ - 24;
  float y = TOP + 12 - scroll_[2];
  const float startY = y;
  const size_t maxChars = static_cast<size_t>((w - 28 - 84) / 5.5f);

  auto sectionTitle = [&](const std::string& s) {
    dl.text(x + 4, y, 11.f, SUB, s);
    y += 20;
  };
  auto presetCard = [&](const Preset& p, bool custom, size_t idx) {
    std::vector<std::string> dlines = wrapText(custom ? std::to_string(p.net.nodes.size()) + " nodes, " + std::to_string(p.net.edges.size()) +
                                                            " wires, " + std::to_string(p.data.rows()) + " data rows"
                                                      : p.desc,
                                               maxChars);
    float h = std::max(66.f, 14 + 20 + dlines.size() * 14.f + 12);
    Rect card{x, y, w, h};
    dl.rrect(card.x, card.y, card.w, card.h, 14.f, PANEL);
    Preset copy = p;
    addHit(card, [this, copy]() { loadPreset(copy); }, "preset:" + p.name);
    dl.text(x + 14, y + 12, 15.f, TEXT, p.name.size() > 22 ? p.name.substr(0, 21) + "." : p.name);
    for (size_t i = 0; i < dlines.size(); ++i) dl.text(x + 14, y + 34 + i * 14.f, 11.f, SUB, dlines[i]);
    if (custom) {
      std::string key = "del-preset:" + std::to_string(idx);
      bool armed = confirmKey_ == key && now_ < confirmUntil_;
      button(dl, Rect{x + w - 14 - 70, y + h / 2 - 34, 70, 30}, "Load", ACCENT, rgba(255, 255, 255), [this, copy]() { loadPreset(copy); }, 12.f);
      button(dl, Rect{x + w - 14 - 70, y + h / 2 + 4, 70, 30}, armed ? "Sure?" : "Delete", armed ? CORAL : rgba(90, 36, 48),
             armed ? rgba(40, 0, 0) : CORAL, [this, key, idx]() {
               if (confirm(key) && idx < custom_.size()) {
                 custom_.erase(custom_.begin() + idx);
                 saveState();
                 toast("Deleted");
               }
             }, 12.f);
    } else {
      button(dl, Rect{x + w - 14 - 70, y + h / 2 - 16, 70, 32}, "Load", ACCENT, rgba(255, 255, 255), [this, copy]() { loadPreset(copy); }, 12.f);
    }
    y += h + 10;
  };

  sectionTitle("BUILT-IN PRESETS");
  for (size_t i = 0; i < builtin_.size(); ++i) presetCard(builtin_[i], false, i);

  y += 6;
  sectionTitle("MY PRESETS");
  if (custom_.empty()) {
    dl.text(x + 4, y, 12.f, SUB, "Nothing saved yet. Build something, then save it below.");
    y += 26;
  }
  for (size_t i = 0; i < custom_.size(); ++i) presetCard(custom_[i], true, i);

  button(dl, Rect{x, y, w, 46}, "Save current as new preset", ACCENT, rgba(255, 255, 255), [this]() {
    std::string nm;
    for (int n = static_cast<int>(custom_.size()) + 1;; ++n) {
      nm = "My network " + std::to_string(n);
      bool used = false;
      for (auto& p : custom_) used |= p.name == nm;
      if (!used) break;
    }
    Preset p;
    p.name = nm;
    p.net = net_;
    p.data = data_;
    p.cfg = cfg_;
    custom_.push_back(p);
    presetName_ = nm;
    saveState();
    toast("Saved as " + nm);
  }, 14.f);
  y += 56;
  button(dl, Rect{x, y, w, 46}, "New blank network", PANEL2, TEXT, [this]() { newBlank(); }, 14.f);
  y += 62;

  if (!customTrainers_.empty()) {
    sectionTitle("MY TRAINERS");
    for (size_t i = 0; i < customTrainers_.size(); ++i) {
      const TrainerCfg& t = customTrainers_[i];
      float h = 62;
      dl.rrect(x, y, w, h, 14.f, PANEL);
      dl.text(x + 14, y + 10, 14.f, TEXT, t.name);
      dl.text(x + 14, y + 34, 11.f, SUB, std::string(optName(t.opt)) + "  lr " + numS(t.lr) + "  x " + std::to_string(t.epochs));
      TrainerCfg c = t;
      button(dl, Rect{x + w - 14 - 70 - 8 - 70, y + 16, 70, 30}, "Use", PANEL2, ACCENT, [this, c]() {
        cfg_ = c;
        toast("Trainer: " + c.name);
      }, 12.f);
      std::string key = "del-trainer:" + std::to_string(i);
      bool armed = confirmKey_ == key && now_ < confirmUntil_;
      button(dl, Rect{x + w - 14 - 70, y + 16, 70, 30}, armed ? "Sure?" : "Delete", armed ? CORAL : rgba(90, 36, 48),
             armed ? rgba(40, 0, 0) : CORAL, [this, key, i]() {
               if (confirm(key) && i < customTrainers_.size()) {
                 customTrainers_.erase(customTrainers_.begin() + i);
                 saveState();
                 toast("Deleted");
               }
             }, 12.f);
      y += h + 10;
    }
  }

  contentH_[2] = (y - startY) + 24;
  float maxScroll = std::max(0.f, contentH_[2] - view.h + 10);
  scroll_[2] = std::max(0.f, std::min(scroll_[2], maxScroll));
  clearClip(dl);
}

// ================================================================= frame + input
void App::frame(double nowSeconds, DrawList& dl) {
  now_ = nowSeconds;
  trainSlice();
  hits_.clear();
  hitLabels_.clear();
  hasClip_ = false;
  dl.begin(density_);
  blockInput_ = pad_.open;
  dl.rect(0, 0, W_, H_, BG);
  switch (tab_) {
    case Tab::Build: drawBuild(dl); break;
    case Tab::Train: drawTrain(dl); break;
    case Tab::Presets: drawPresets(dl); break;
  }
  drawTopBar(dl);
  drawNav(dl);
  if (pad_.open) {
    blockInput_ = false;
    drawKeypad(dl);
  }
  drawToast(dl);
}

void App::tap(float x, float y) {
  if (const Hit* h = hitAt(x, y)) {
    if (h->fn) {
      std::function<void()> fn = h->fn;  // hits_ is rebuilt next frame; copy to be safe
      fn();
    }
    return;
  }
  if (pad_.open) return;
  if (tab_ == Tab::Build && canvas_.contains(x, y)) canvasTap(x, y);
}

void App::touch(int action, float xpx, float ypx) {
  float x = xpx / density_, y = ypx / density_;
  const float slop = 10.f;
  if (action == 0) {
    down_ = true;
    moved_ = false;
    downX_ = lastX_ = x;
    downY_ = lastY_ = y;
    drag_ = Drag::None;
    dragNode_ = -1;
    if (pad_.open) return;
    if (tab_ == Tab::Build) {
      if (canvas_.contains(x, y) && !hitAt(x, y)) {
        int ni = pickNode(x, y);
        if (tool_ == Tool::Move && ni >= 0) {
          drag_ = Drag::Node;
          dragNode_ = net_.nodes[ni].id;
        } else {
          drag_ = Drag::Pan;
        }
      }
    } else if (y > TOP && y < H_ - NAV) {
      drag_ = Drag::Scroll;
    }
  } else if (action == 1) {
    if (!down_) return;
    if (!moved_ && std::fabs(x - downX_) + std::fabs(y - downY_) > slop) {
      moved_ = true;
      lastX_ = downX_;  // apply the whole movement so far, so the content doesn't lag the finger
      lastY_ = downY_;
    }
    if (moved_) {
      float dx = x - lastX_, dy = y - lastY_;
      if (drag_ == Drag::Pan) {
        panX_ += dx;
        panY_ += dy;
      } else if (drag_ == Drag::Node) {
        int i = net_.nodeIndex(dragNode_);
        if (i >= 0) {
          net_.nodes[i].x += dx;
          net_.nodes[i].y += dy;
          selNode_ = dragNode_;
          selEdge_ = -1;
        }
      } else if (drag_ == Drag::Scroll) {
        int t = static_cast<int>(tab_);
        float viewH = H_ - NAV - TOP;
        float maxScroll = std::max(0.f, contentH_[t] - viewH + 10);
        scroll_[t] = std::max(0.f, std::min(maxScroll, scroll_[t] - dy));
      }
    }
    lastX_ = x;
    lastY_ = y;
  } else if (action == 2) {
    if (!down_) return;
    down_ = false;
    if (!moved_) tap(x, y);
    drag_ = Drag::None;
  } else {
    down_ = false;
    drag_ = Drag::None;
  }
}

}  // namespace nl
