// NodeLab UI: three tabs (Build / Train / Presets), an in-app number keypad, and a
// node inspector that shows the math. Platform independent - the Android layer
// only forwards touches and uploads the DrawList triangles.
#pragma once
#include <functional>
#include <string>
#include <vector>

#include "../core/engine.h"
#include "draw.h"

namespace nl {

struct Rect {
  float x = 0, y = 0, w = 0, h = 0;
  bool contains(float px, float py) const { return px >= x && px < x + w && py >= y && py < y + h; }
};

enum class Tab { Build = 0, Train = 1, Presets = 2 };
enum class Tool { Move, Link, Erase };

class App {
 public:
  App();

  void setSurface(int pxW, int pxH, float density);
  void setStorageDir(const std::string& dir);  // enables saving; call before loadState()
  void loadState();
  void saveState();

  // action: 0 = down, 1 = move, 2 = up, 3 = cancel. Coordinates in pixels.
  void touch(int action, float xpx, float ypx);
  // Builds the whole frame into `dl` and advances training for a few ms.
  void frame(double nowSeconds, DrawList& dl);

  // ----- state (public so desktop tests can drive it) -----
  Network net_;
  Dataset data_;
  TrainerCfg cfg_;
  Trainer trainer_;
  std::string presetName_ = "XOR";
  std::vector<Preset> builtin_, custom_;
  std::vector<TrainerCfg> builtinTrainers_, customTrainers_;

  Tab tab_ = Tab::Build;
  Tool tool_ = Tool::Move;
  int selNode_ = -1;  // node id
  int selEdge_ = -1;  // edge index
  int linkFrom_ = -1;
  bool training_ = false;
  int runStart_ = 0;
  double trainBudgetSeconds_ = 0.008;

  // True while something on screen changes without input (training, toast, finger down).
  // The platform layer sleeps until the next event when this is false.
  bool animating() const { return training_ || down_ || now_ < toastUntil_ || now_ < confirmUntil_; }

  // Android back button: closes the keypad / returns to Build. False = let the system handle it.
  bool onBack();

  void loadPreset(const Preset& p);
  void newBlank();
  void startTraining();
  void stopTraining();
  void resetWeights();
  void autoFix();
  void toast(const std::string& msg);
  void frameView();
  std::string statusText() const;

  struct Hit {
    Rect r;
    std::function<void()> fn;
  };
  // Pixel position of a node's centre (for tests / tutorials). False if the id is unknown.
  bool nodePixelPos(int id, float& xpx, float& ypx) const;
  // Test hook: tap something by its visible text label (searches last frame's hits).
  bool tapLabel(const std::string& label);
  std::vector<std::string> lastLabels_;
  std::vector<std::string> hitLabels_;

 private:
  // layout metrics (dp)
  float W_ = 360, H_ = 760, density_ = 1.f;
  double now_ = 0, lastNow_ = -1;

  // input
  bool down_ = false, moved_ = false;
  float downX_ = 0, downY_ = 0, lastX_ = 0, lastY_ = 0;
  enum class Drag { None, Pan, Node, Scroll } drag_ = Drag::None;
  int dragNode_ = -1;
  float panX_ = 0, panY_ = 0;
  float scroll_[3] = {0, 0, 0};
  float contentH_[3] = {0, 0, 0};
  Rect canvas_;

  std::vector<Hit> hits_;
  bool blockInput_ = false;
  bool hasClip_ = false;
  Rect clip_;

  // keypad
  struct Keypad {
    bool open = false;
    bool fresh = true;
    bool integer = false;
    std::string title, text;
    std::function<void(float)> apply;
  } pad_;

  std::string toastMsg_;
  double toastUntil_ = 0;
  std::string confirmKey_;
  double confirmUntil_ = 0;
  uint32_t seed_ = 100;
  std::string dir_;

  // drawing helpers
  void addHit(Rect r, std::function<void()> fn, const std::string& label = "");
  const Hit* hitAt(float x, float y) const;
  void button(DrawList& dl, Rect r, const std::string& label, Color bg, Color fg, std::function<void()> fn,
              float textH = 13.f);
  void centeredText(DrawList& dl, Rect r, const std::string& s, float h, Color c);
  void stepper(DrawList& dl, float x, float y, float w, const std::string& label, float value, float step,
               std::function<void(float)> set, bool integer = false);
  void paramRow(DrawList& dl, float x, float& y, float w, const std::string& name, const std::string& value,
                std::function<void()> onTap);
  void setClip(DrawList& dl, Rect r);
  void clearClip(DrawList& dl);

  void drawTopBar(DrawList& dl);
  void drawNav(DrawList& dl);
  void drawBuild(DrawList& dl);
  void drawInspector(DrawList& dl, float bottom);
  void drawTrain(DrawList& dl);
  void drawPresets(DrawList& dl);
  void drawKeypad(DrawList& dl);
  void drawToast(DrawList& dl);

  void openKeypad(const std::string& title, float value, std::function<void(float)> apply, bool integer = false);
  void keypadKey(const std::string& k);

  void tap(float x, float y);
  void canvasTap(float x, float y);
  int pickNode(float x, float y) const;
  int pickEdge(float x, float y) const;
  void nodeScreen(const Node& n, float& sx, float& sy) const;
  void addNode(Kind k);
  void netEdited(bool structural);
  void trainSlice();
  bool runFinished() const;
  bool confirm(const std::string& key);

  void saveFile(const std::string& name, const std::string& text) const;
  std::string readFile(const std::string& name) const;
};

}  // namespace nl
