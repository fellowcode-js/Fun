#include "draw.h"

#include <algorithm>
#include <cmath>

#include "font_data.h"

namespace nl {

static uint32_t packColor(Color c) {
  return static_cast<uint32_t>(c.r) | (static_cast<uint32_t>(c.g) << 8) | (static_cast<uint32_t>(c.b) << 16) |
         (static_cast<uint32_t>(c.a) << 24);
}

void DrawList::begin(float scale) {
  scale_ = scale;
  verts.clear();
  batches.clear();
  batches.push_back(Batch{});
  int col = FONT_WHITE_SLOT % FONT_COLS, row = FONT_WHITE_SLOT / FONT_COLS;
  whiteU_ = (col * FONT_CELL_W + FONT_CELL_W * 0.5f) / FONT_ATLAS_W;
  whiteV_ = (row * FONT_CELL_H + FONT_CELL_H * 0.5f) / FONT_ATLAS_H;
}

void DrawList::startBatch(bool clip, int cx, int cy, int cw, int ch) {
  Batch& cur = batches.back();
  if (cur.count == 0) {  // reuse an empty batch
    cur.first = verts.size();
    cur.clip = clip;
    cur.cx = cx;
    cur.cy = cy;
    cur.cw = cw;
    cur.ch = ch;
    return;
  }
  Batch b;
  b.first = verts.size();
  b.clip = clip;
  b.cx = cx;
  b.cy = cy;
  b.cw = cw;
  b.ch = ch;
  batches.push_back(b);
}

void DrawList::setClip(float x, float y, float w, float h) {
  int cx = static_cast<int>(std::floor(x * scale_)), cy = static_cast<int>(std::floor(y * scale_));
  int cw = static_cast<int>(std::ceil(w * scale_)), ch = static_cast<int>(std::ceil(h * scale_));
  startBatch(true, cx, cy, std::max(0, cw), std::max(0, ch));
}

void DrawList::clearClip() { startBatch(false, 0, 0, 0, 0); }

void DrawList::push(float x, float y, float u, float v, Color c) {
  verts.push_back(Vertex{x, y, u, v, packColor(c)});
  batches.back().count++;
}

void DrawList::quadPx(float x0, float y0, float x1, float y1, float u0, float v0, float u1, float v1, Color c) {
  push(x0, y0, u0, v0, c);
  push(x1, y0, u1, v0, c);
  push(x1, y1, u1, v1, c);
  push(x0, y0, u0, v0, c);
  push(x1, y1, u1, v1, c);
  push(x0, y1, u0, v1, c);
}

void DrawList::rect(float x, float y, float w, float h, Color c) {
  if (w <= 0 || h <= 0 || c.a == 0) return;
  quadPx(x * scale_, y * scale_, (x + w) * scale_, (y + h) * scale_, whiteU_, whiteV_, whiteU_, whiteV_, c);
}

void DrawList::tri(float x1, float y1, float x2, float y2, float x3, float y3, Color c) {
  polyAA({x1 * scale_, y1 * scale_, x2 * scale_, y2 * scale_, x3 * scale_, y3 * scale_}, c);
}

// Convex polygon: solid inner fan, plus a 1px feathered rim for anti-aliasing.
void DrawList::polyAA(const std::vector<float>& pts, Color c) {
  const size_t n = pts.size() / 2;
  if (n < 3 || c.a == 0) return;
  float cx = 0, cy = 0;
  for (size_t i = 0; i < n; ++i) {
    cx += pts[2 * i];
    cy += pts[2 * i + 1];
  }
  cx /= n;
  cy /= n;
  std::vector<float> in(pts.size()), out(pts.size());
  for (size_t i = 0; i < n; ++i) {
    float dx = pts[2 * i] - cx, dy = pts[2 * i + 1] - cy;
    float d = std::sqrt(dx * dx + dy * dy);
    float ux = d > 1e-4f ? dx / d : 0.f, uy = d > 1e-4f ? dy / d : 0.f;
    float inset = std::min(0.5f, d * 0.5f);
    in[2 * i] = pts[2 * i] - ux * inset;
    in[2 * i + 1] = pts[2 * i + 1] - uy * inset;
    out[2 * i] = pts[2 * i] + ux * 0.5f;
    out[2 * i + 1] = pts[2 * i + 1] + uy * 0.5f;
  }
  Color clear = withAlpha(c, 0);
  for (size_t i = 0; i < n; ++i) {
    size_t j = (i + 1) % n;
    push(cx, cy, whiteU_, whiteV_, c);
    push(in[2 * i], in[2 * i + 1], whiteU_, whiteV_, c);
    push(in[2 * j], in[2 * j + 1], whiteU_, whiteV_, c);
    // feather strip between inner rim (opaque) and outer rim (transparent)
    push(in[2 * i], in[2 * i + 1], whiteU_, whiteV_, c);
    push(out[2 * i], out[2 * i + 1], whiteU_, whiteV_, clear);
    push(out[2 * j], out[2 * j + 1], whiteU_, whiteV_, clear);
    push(in[2 * i], in[2 * i + 1], whiteU_, whiteV_, c);
    push(out[2 * j], out[2 * j + 1], whiteU_, whiteV_, clear);
    push(in[2 * j], in[2 * j + 1], whiteU_, whiteV_, c);
  }
}

void DrawList::circle(float cx, float cy, float r, Color c) {
  float rp = r * scale_;
  if (rp <= 0) return;
  int segs = std::max(14, std::min(56, static_cast<int>(rp * 0.9f) + 12));
  std::vector<float> pts;
  pts.reserve(static_cast<size_t>(segs) * 2);
  for (int i = 0; i < segs; ++i) {
    float a = 6.2831853f * i / segs;
    pts.push_back(cx * scale_ + std::cos(a) * rp);
    pts.push_back(cy * scale_ + std::sin(a) * rp);
  }
  polyAA(pts, c);
}

void DrawList::rrect(float x, float y, float w, float h, float radius, Color c) {
  if (w <= 0 || h <= 0 || c.a == 0) return;
  float r = std::min(radius, std::min(w, h) * 0.5f);
  if (r < 0.5f) {
    rect(x, y, w, h, c);
    return;
  }
  int seg = std::max(3, std::min(10, static_cast<int>(r * scale_ * 0.5f) + 2));
  std::vector<float> pts;
  const float corners[4][2] = {{x + w - r, y + r}, {x + w - r, y + h - r}, {x + r, y + h - r}, {x + r, y + r}};
  for (int k = 0; k < 4; ++k) {
    for (int i = 0; i <= seg; ++i) {
      float a = (k * 90.f + 90.f * i / seg - 90.f) * 0.017453293f;
      pts.push_back((corners[k][0] + std::cos(a) * r) * scale_);
      pts.push_back((corners[k][1] + std::sin(a) * r) * scale_);
    }
  }
  polyAA(pts, c);
}

void DrawList::line(float x1, float y1, float x2, float y2, float thickness, Color c) {
  float dx = (x2 - x1) * scale_, dy = (y2 - y1) * scale_;
  float len = std::sqrt(dx * dx + dy * dy);
  if (len < 1e-3f || c.a == 0) return;
  float nx = -dy / len, ny = dx / len;
  float half = std::max(0.5f, thickness * scale_ * 0.5f);
  float core = std::max(0.f, half - 0.5f);
  float ax = x1 * scale_, ay = y1 * scale_, bx = x2 * scale_, by = y2 * scale_;
  Color clear = withAlpha(c, 0);
  // opaque core
  push(ax + nx * core, ay + ny * core, whiteU_, whiteV_, c);
  push(bx + nx * core, by + ny * core, whiteU_, whiteV_, c);
  push(bx - nx * core, by - ny * core, whiteU_, whiteV_, c);
  push(ax + nx * core, ay + ny * core, whiteU_, whiteV_, c);
  push(bx - nx * core, by - ny * core, whiteU_, whiteV_, c);
  push(ax - nx * core, ay - ny * core, whiteU_, whiteV_, c);
  // feathered sides
  const float outer = core + 1.f;
  for (int side = -1; side <= 1; side += 2) {
    float s = static_cast<float>(side);
    push(ax + nx * core * s, ay + ny * core * s, whiteU_, whiteV_, c);
    push(bx + nx * core * s, by + ny * core * s, whiteU_, whiteV_, c);
    push(bx + nx * outer * s, by + ny * outer * s, whiteU_, whiteV_, clear);
    push(ax + nx * core * s, ay + ny * core * s, whiteU_, whiteV_, c);
    push(bx + nx * outer * s, by + ny * outer * s, whiteU_, whiteV_, clear);
    push(ax + nx * outer * s, ay + ny * outer * s, whiteU_, whiteV_, clear);
  }
}

void DrawList::text(float x, float y, float h, Color c, const std::string& s) {
  if (c.a == 0 || s.empty()) return;
  const float cw = h * 0.5f * scale_, ch = h * scale_;
  float px = x * scale_, py = y * scale_;
  for (unsigned char chr : s) {
    if (chr < 32 || chr > 126) chr = '?';
    if (chr != ' ') {
      int slot = chr - 32;
      int col = slot % FONT_COLS, row = slot / FONT_COLS;
      float u0 = (col * FONT_CELL_W + 0.5f) / FONT_ATLAS_W, u1 = ((col + 1) * FONT_CELL_W - 0.5f) / FONT_ATLAS_W;
      float v0 = (row * FONT_CELL_H + 0.5f) / FONT_ATLAS_H, v1 = ((row + 1) * FONT_CELL_H - 0.5f) / FONT_ATLAS_H;
      quadPx(px, py, px + cw, py + ch, u0, v0, u1, v1, c);
    }
    px += cw;
  }
}

}  // namespace nl
