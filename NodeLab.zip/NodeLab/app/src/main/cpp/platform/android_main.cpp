// Android entry point: NativeActivity + EGL + GLES2. This file is deliberately thin:
// it creates the GL surface, forwards touches to nl::App, and draws nl::DrawList triangles.
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <android/configuration.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android_native_app_glue.h>
#include <sys/types.h>
#include <time.h>

#include <string>

#include "../ui/app.h"
#include "../ui/draw.h"
#include "../ui/font_data.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "NodeLab", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "NodeLab", __VA_ARGS__)

namespace {

const char* kVertexShader =
    "attribute vec2 aPos;\n"
    "attribute vec2 aUv;\n"
    "attribute vec4 aCol;\n"
    "uniform vec2 uScreen;\n"
    "varying vec2 vUv;\n"
    "varying vec4 vCol;\n"
    "void main() {\n"
    "  vUv = aUv;\n"
    "  vCol = aCol;\n"
    "  gl_Position = vec4(aPos.x / uScreen.x * 2.0 - 1.0, 1.0 - aPos.y / uScreen.y * 2.0, 0.0, 1.0);\n"
    "}\n";

const char* kFragmentShader =
    "precision mediump float;\n"
    "varying vec2 vUv;\n"
    "varying vec4 vCol;\n"
    "uniform sampler2D uTex;\n"
    "void main() {\n"
    "  gl_FragColor = vec4(vCol.rgb, vCol.a * texture2D(uTex, vUv).a);\n"
    "}\n";

struct Engine {
  android_app* app = nullptr;
  EGLDisplay display = EGL_NO_DISPLAY;
  EGLSurface surface = EGL_NO_SURFACE;
  EGLContext context = EGL_NO_CONTEXT;
  int width = 0, height = 0;
  GLuint program = 0, texture = 0;
  GLint aPos = -1, aUv = -1, aCol = -1, uScreen = -1, uTex = -1;
  nl::App ui;
  nl::DrawList dl;
  bool ready = false;
  bool stateLoaded = false;
  int32_t touchId = -1;      // pointer id of the finger driving the UI
  bool backHandled = false;  // true when the BACK key-down was consumed by the UI
};

double nowSeconds() {
  timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return static_cast<double>(ts.tv_sec) + static_cast<double>(ts.tv_nsec) * 1e-9;
}

GLuint compile(GLenum type, const char* src) {
  GLuint s = glCreateShader(type);
  glShaderSource(s, 1, &src, nullptr);
  glCompileShader(s);
  GLint ok = 0;
  glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
  if (!ok) {
    char log[512];
    glGetShaderInfoLog(s, sizeof log, nullptr, log);
    LOGE("shader compile failed: %s", log);
    glDeleteShader(s);
    return 0;
  }
  return s;
}

bool initGL(Engine& e) {
  GLuint vs = compile(GL_VERTEX_SHADER, kVertexShader);
  GLuint fs = compile(GL_FRAGMENT_SHADER, kFragmentShader);
  if (!vs || !fs) return false;
  e.program = glCreateProgram();
  glAttachShader(e.program, vs);
  glAttachShader(e.program, fs);
  glLinkProgram(e.program);
  GLint ok = 0;
  glGetProgramiv(e.program, GL_LINK_STATUS, &ok);
  if (!ok) {
    LOGE("program link failed");
    return false;
  }
  glDeleteShader(vs);
  glDeleteShader(fs);
  e.aPos = glGetAttribLocation(e.program, "aPos");
  e.aUv = glGetAttribLocation(e.program, "aUv");
  e.aCol = glGetAttribLocation(e.program, "aCol");
  e.uScreen = glGetUniformLocation(e.program, "uScreen");
  e.uTex = glGetUniformLocation(e.program, "uTex");

  glGenTextures(1, &e.texture);
  glBindTexture(GL_TEXTURE_2D, e.texture);
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_ALPHA, nl::FONT_ATLAS_W, nl::FONT_ATLAS_H, 0, GL_ALPHA, GL_UNSIGNED_BYTE,
               nl::FONT_ATLAS);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  return true;
}

float densityScale(android_app* app) {
  int32_t d = app->config ? AConfiguration_getDensity(app->config) : 0;
  if (d <= 0 || d == ACONFIGURATION_DENSITY_ANY || d == ACONFIGURATION_DENSITY_NONE) return 2.75f;
  return static_cast<float>(d) / 160.f;
}

void termDisplay(Engine& e);

bool initDisplayImpl(Engine& e) {
  e.display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
  if (e.display == EGL_NO_DISPLAY || !eglInitialize(e.display, nullptr, nullptr)) {
    LOGE("eglInitialize failed");
    return false;
  }
  const EGLint attribs[] = {EGL_SURFACE_TYPE, EGL_WINDOW_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT, EGL_BLUE_SIZE, 8,
                            EGL_GREEN_SIZE, 8, EGL_RED_SIZE, 8, EGL_NONE};
  EGLConfig config = nullptr;
  EGLint numConfigs = 0;
  if (!eglChooseConfig(e.display, attribs, &config, 1, &numConfigs) || numConfigs < 1) {
    LOGE("no EGL config");
    return false;
  }
  EGLint format = 0;
  eglGetConfigAttrib(e.display, config, EGL_NATIVE_VISUAL_ID, &format);
  ANativeWindow_setBuffersGeometry(e.app->window, 0, 0, format);
  e.surface = eglCreateWindowSurface(e.display, config, e.app->window, nullptr);
  const EGLint ctxAttribs[] = {EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE};
  e.context = eglCreateContext(e.display, config, EGL_NO_CONTEXT, ctxAttribs);
  if (e.surface == EGL_NO_SURFACE || e.context == EGL_NO_CONTEXT ||
      !eglMakeCurrent(e.display, e.surface, e.surface, e.context)) {
    LOGE("EGL surface/context creation failed");
    return false;
  }
  eglSwapInterval(e.display, 1);
  eglQuerySurface(e.display, e.surface, EGL_WIDTH, &e.width);
  eglQuerySurface(e.display, e.surface, EGL_HEIGHT, &e.height);
  if (!initGL(e)) return false;
  e.ui.setSurface(e.width, e.height, densityScale(e.app));
  e.ready = true;
  LOGI("surface %dx%d density %.2f", e.width, e.height, densityScale(e.app));
  return true;
}

// Any failure releases whatever was created, so a retry starts clean.
bool initDisplay(Engine& e) {
  if (initDisplayImpl(e)) return true;
  termDisplay(e);
  return false;
}

void termDisplay(Engine& e) {
  e.ready = false;
  if (e.display != EGL_NO_DISPLAY) {
    eglMakeCurrent(e.display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    if (e.context != EGL_NO_CONTEXT) eglDestroyContext(e.display, e.context);
    if (e.surface != EGL_NO_SURFACE) eglDestroySurface(e.display, e.surface);
    eglTerminate(e.display);
  }
  e.display = EGL_NO_DISPLAY;
  e.context = EGL_NO_CONTEXT;
  e.surface = EGL_NO_SURFACE;
  e.program = 0;
  e.texture = 0;
}

void drawFrame(Engine& e) {
  if (!e.ready) return;
  EGLint w = 0, h = 0;
  eglQuerySurface(e.display, e.surface, EGL_WIDTH, &w);
  eglQuerySurface(e.display, e.surface, EGL_HEIGHT, &h);
  if (w != e.width || h != e.height) {
    e.width = w;
    e.height = h;
    e.ui.setSurface(w, h, densityScale(e.app));
  }
  e.ui.frame(nowSeconds(), e.dl);

  glViewport(0, 0, e.width, e.height);
  glDisable(GL_DEPTH_TEST);
  glDisable(GL_CULL_FACE);
  glClearColor(15.f / 255.f, 18.f / 255.f, 32.f / 255.f, 1.f);
  glDisable(GL_SCISSOR_TEST);  // the clear must cover the whole surface
  glClear(GL_COLOR_BUFFER_BIT);
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glEnable(GL_SCISSOR_TEST);

  glUseProgram(e.program);
  glUniform2f(e.uScreen, static_cast<float>(e.width), static_cast<float>(e.height));
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, e.texture);
  glUniform1i(e.uTex, 0);

  const nl::Vertex* base = e.dl.verts.data();
  glEnableVertexAttribArray(static_cast<GLuint>(e.aPos));
  glEnableVertexAttribArray(static_cast<GLuint>(e.aUv));
  glEnableVertexAttribArray(static_cast<GLuint>(e.aCol));
  glVertexAttribPointer(static_cast<GLuint>(e.aPos), 2, GL_FLOAT, GL_FALSE, sizeof(nl::Vertex), &base[0].x);
  glVertexAttribPointer(static_cast<GLuint>(e.aUv), 2, GL_FLOAT, GL_FALSE, sizeof(nl::Vertex), &base[0].u);
  glVertexAttribPointer(static_cast<GLuint>(e.aCol), 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(nl::Vertex), &base[0].c);

  for (const nl::Batch& b : e.dl.batches) {
    if (b.count == 0) continue;
    if (b.clip)
      glScissor(b.cx, e.height - (b.cy + b.ch), b.cw, b.ch);  // GL origin is bottom-left
    else
      glScissor(0, 0, e.width, e.height);
    glDrawArrays(GL_TRIANGLES, static_cast<GLint>(b.first), static_cast<GLsizei>(b.count));
  }

  if (!eglSwapBuffers(e.display, e.surface)) {
    EGLint err = eglGetError();
    LOGE("eglSwapBuffers failed: 0x%x", err);
    if (err == EGL_CONTEXT_LOST || err == EGL_BAD_CONTEXT || err == EGL_BAD_SURFACE ||
        err == EGL_BAD_NATIVE_WINDOW || err == EGL_BAD_DISPLAY) {
      termDisplay(e);
      if (e.app->window) initDisplay(e);
    }
  }
}

int32_t onInput(android_app* app, AInputEvent* ev) {
  Engine* e = static_cast<Engine*>(app->userData);
  int32_t type = AInputEvent_getType(ev);
  if (type == AINPUT_EVENT_TYPE_MOTION && e->ready) {
    const int32_t action = AMotionEvent_getAction(ev) & AMOTION_EVENT_ACTION_MASK;
    if (action == AMOTION_EVENT_ACTION_DOWN) {
      e->touchId = AMotionEvent_getPointerId(ev, 0);
      e->ui.touch(0, AMotionEvent_getX(ev, 0), AMotionEvent_getY(ev, 0));
      return 1;
    }
    if (e->touchId < 0) return 1;  // not tracking a finger (e.g. mouse hover, stray event)
    const ssize_t idx = AMotionEvent_findPointerIndex(ev, e->touchId);
    if (action == AMOTION_EVENT_ACTION_CANCEL || idx < 0) {  // cancelled, or our finger already lifted
      e->ui.touch(3, 0, 0);
      e->touchId = -1;
      return 1;
    }
    const float x = AMotionEvent_getX(ev, static_cast<size_t>(idx));
    const float y = AMotionEvent_getY(ev, static_cast<size_t>(idx));
    if (action == AMOTION_EVENT_ACTION_MOVE) {
      e->ui.touch(1, x, y);
    } else if (action == AMOTION_EVENT_ACTION_UP) {
      e->ui.touch(2, x, y);
      e->touchId = -1;
    }
    return 1;
  }
  if (type == AINPUT_EVENT_TYPE_KEY && AKeyEvent_getKeyCode(ev) == AKEYCODE_BACK) {
    if (AKeyEvent_getAction(ev) == AKEY_EVENT_ACTION_DOWN) {
      e->backHandled = e->ui.onBack();
      return e->backHandled ? 1 : 0;
    }
    bool handled = e->backHandled;  // the matching UP: swallow it only if we used the DOWN
    e->backHandled = false;
    return handled ? 1 : 0;
  }
  return 0;
}

void onCmd(android_app* app, int32_t cmd) {
  Engine* e = static_cast<Engine*>(app->userData);
  switch (cmd) {
    case APP_CMD_INIT_WINDOW:
      if (app->window) initDisplay(*e);
      break;
    case APP_CMD_TERM_WINDOW:
      e->ui.saveState();
      termDisplay(*e);
      break;
    case APP_CMD_SAVE_STATE:
    case APP_CMD_PAUSE:
    case APP_CMD_STOP:
      e->ui.stopTraining();
      e->ui.saveState();
      break;
    default: break;
  }
}

}  // namespace

void android_main(android_app* app) {
  Engine engine;
  engine.app = app;
  app->userData = &engine;
  app->onAppCmd = onCmd;
  app->onInputEvent = onInput;
  // Load saved work BEFORE anything can trigger a save (pause/stop may arrive before the window exists).
  if (app->activity->internalDataPath) engine.ui.setStorageDir(app->activity->internalDataPath);
  engine.ui.loadState();
  engine.stateLoaded = true;

  while (true) {
    // Sleep until the next event unless something is animating (training, toast, finger down).
    int timeout = (!engine.ready || !engine.ui.animating()) ? -1 : 0;
    int events = 0;
    android_poll_source* source = nullptr;
    while (ALooper_pollOnce(timeout, nullptr, &events, reinterpret_cast<void**>(&source)) >= 0) {
      timeout = 0;  // after the first wake-up just drain what is queued
      if (source) source->process(app, source);
      if (app->destroyRequested) break;
    }
    if (app->destroyRequested) {
      engine.ui.saveState();
      termDisplay(engine);
      return;
    }
    drawFrame(engine);
  }
}
