// NodeLab core engine: a small, dependency-free neural network graph in C++17.
// Nodes are connected by weighted edges; the engine does all the math
// (forward pass, backpropagation, optimizers) so the UI only has to draw.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace nl {

enum class Kind { Input, Hidden, Output };
enum class Act { Linear, Sigmoid, Tanh, ReLU, LeakyReLU, Step };
enum class OptKind { SGD, Momentum, Adam };
enum class LossKind { MSE, MAE };

const char* kindName(Kind k);
const char* actName(Act a);
const char* optName(OptKind o);
const char* lossName(LossKind l);
Act nextAct(Act a);
OptKind nextOpt(OptKind o);
LossKind nextLoss(LossKind l);

float activate(Act a, float x);
// Derivative w.r.t. the pre-activation sum. `out` is activate(a, sum).
// Step uses a smooth stand-in (1 inside |x|<1) so it can still be trained.
float activateDeriv(Act a, float sum, float out);

struct Node {
  int id = 0;
  Kind kind = Kind::Hidden;
  Act act = Act::Tanh;
  float bias = 0.f;
  float input = 0.f;  // only used when kind == Input
  float x = 0.f, y = 0.f;  // canvas position (world units)
  float sum = 0.f;    // computed by forward()
  float value = 0.f;  // computed by forward()
};

struct Edge {
  int from = 0;  // node id
  int to = 0;    // node id
  float w = 0.f;
};

class Network {
 public:
  std::vector<Node> nodes;
  std::vector<Edge> edges;

  int addNode(Kind kind, float x, float y);
  bool removeNode(int id);
  bool connect(int fromId, int toId, std::string* err = nullptr);
  bool connectWithWeight(int fromId, int toId, float w, std::string* err = nullptr);
  bool removeEdge(int edgeIndex);
  int nodeIndex(int id) const;  // -1 if missing
  int edgeIndex(int fromId, int toId) const;
  bool wouldCycle(int fromId, int toId) const;

  std::vector<int> inputIds() const;   // ordered by id
  std::vector<int> outputIds() const;  // ordered by id
  void setInputs(const std::vector<float>& v);
  std::vector<float> outputs() const;
  // Allocation-free variants for the simulator's inner loop (inputs/outputs in id order).
  void setInputsRaw(const float* v, size_t n);
  size_t inputCount();
  size_t outputCount();
  float outputValue(size_t k);  // after forward()
  const Node* outputNode(size_t k);  // k-th output in id order, or nullptr

  // All trainable numbers as one flat vector: edge weights, then biases of non-input nodes.
  std::vector<float> getParams() const;
  void setParams(const std::vector<float>& p);

  void forward();
  void randomize(uint32_t seed);  // fresh weights, zero bias
  void clear();

  // Backprop for one sample. Call forward() first. Adds into gW (per edge) and
  // gB (per node index). Returns the sample loss.
  float backward(const std::vector<float>& target, LossKind loss,
                 std::vector<float>& gW, std::vector<float>& gB);

  // Edge indices that feed node `nodeIdx` (node index, not id).
  const std::vector<int>& incoming(int nodeIdx) const;

  // Human readable problems ("no output node", ...). Empty list = healthy.
  std::vector<std::string> check() const;
  // Resets NaN/inf parameters. Returns true if anything was changed.
  bool sanitize();

  int nextId = 1;

 private:
  void rebuild() const;
  mutable bool dirty_ = true;
  mutable std::vector<int> order_;                 // topological order (node indices)
  mutable std::vector<std::vector<int>> in_;       // incoming edge indices per node index
  mutable std::vector<int> efrom_;                 // node index feeding each edge (-1 if dangling)
  mutable std::vector<int> inIdx_, outIdx_;        // input / output node indices, ordered by id
  friend class Trainer;
};

// "I1", "H3", "O1": kind letter + rank among nodes of the same kind.
std::string nodeLabel(const Network& net, int nodeIdx);

struct Dataset {
  std::vector<std::vector<float>> X, Y;
  size_t rows() const { return X.size(); }
  void addRow(size_t nIn, size_t nOut);
  void removeRow(size_t i);
  void resizeCols(size_t nIn, size_t nOut);  // pad with 0 / truncate
};

bool datasetCompatible(const Network& n, const Dataset& d, std::string* err = nullptr);

struct TrainerCfg {
  std::string name = "Adam";
  OptKind opt = OptKind::Adam;
  LossKind loss = LossKind::MSE;
  float lr = 0.05f;
  float momentum = 0.9f;
  int epochs = 2000;
  int batch = 0;  // 0 = whole dataset
  bool shuffle = true;
  float targetLoss = 0.0005f;  // stop early when reached (0 = never)
};

class Trainer {
 public:
  void reset();                       // forget optimizer state + history
  // Runs one epoch. Returns average loss (or -1 if data is incompatible).
  float epoch(Network& net, const Dataset& data, const TrainerCfg& cfg);
  float evaluate(Network& net, const Dataset& data, LossKind loss);
  bool finished(const TrainerCfg& cfg) const;

  int epochsDone = 0;
  float lastLoss = 0.f;
  bool diverged = false;
  std::vector<float> history;

 private:
  uint32_t rng_ = 12345u;
  std::vector<float> m_, v_;
  long step_ = 0;
  size_t paramCount_ = 0;
};

struct Preset {
  std::string name;
  std::string desc;
  Network net;
  Dataset data;
  TrainerCfg cfg;
};

std::vector<Preset> builtinPresets();
std::vector<TrainerCfg> builtinTrainers();
// Fully connected layered net, laid out for a ~360dp wide canvas.
Network makeLayered(const std::vector<int>& sizes, Act hidden, Act out, uint32_t seed);

std::string fnumStr(float f);  // locale-proof float -> text, non-finite becomes 0
std::string serializePreset(const Preset& p);
bool deserializePreset(const std::string& text, Preset& out, std::string* err = nullptr);
std::string serializePresets(const std::vector<Preset>& v);
std::vector<Preset> deserializePresets(const std::string& text);
std::string serializeTrainers(const std::vector<TrainerCfg>& v);
std::vector<TrainerCfg> deserializeTrainers(const std::string& text);

}  // namespace nl
