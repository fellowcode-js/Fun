#include "engine.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <locale>
#include <sstream>

namespace nl {

// ---------------------------------------------------------------- names
const char* kindName(Kind k) {
  switch (k) {
    case Kind::Input: return "Input";
    case Kind::Hidden: return "Hidden";
    case Kind::Output: return "Output";
  }
  return "?";
}
const char* actName(Act a) {
  switch (a) {
    case Act::Linear: return "Linear";
    case Act::Sigmoid: return "Sigmoid";
    case Act::Tanh: return "Tanh";
    case Act::ReLU: return "ReLU";
    case Act::LeakyReLU: return "Leaky ReLU";
    case Act::Step: return "Step";
  }
  return "?";
}
const char* optName(OptKind o) {
  switch (o) {
    case OptKind::SGD: return "SGD";
    case OptKind::Momentum: return "Momentum";
    case OptKind::Adam: return "Adam";
  }
  return "?";
}
const char* lossName(LossKind l) { return l == LossKind::MSE ? "MSE" : "MAE"; }
Act nextAct(Act a) { return static_cast<Act>((static_cast<int>(a) + 1) % 6); }
OptKind nextOpt(OptKind o) { return static_cast<OptKind>((static_cast<int>(o) + 1) % 3); }
LossKind nextLoss(LossKind l) { return l == LossKind::MSE ? LossKind::MAE : LossKind::MSE; }

// ---------------------------------------------------------------- math
float activate(Act a, float x) {
  switch (a) {
    case Act::Linear: return x;
    case Act::Sigmoid: return 1.f / (1.f + std::exp(-std::max(-60.f, std::min(60.f, x))));
    case Act::Tanh: return std::tanh(x);
    case Act::ReLU: return x > 0.f ? x : 0.f;
    case Act::LeakyReLU: return x > 0.f ? x : 0.01f * x;
    case Act::Step: return x > 0.f ? 1.f : 0.f;
  }
  return x;
}

float activateDeriv(Act a, float sum, float out) {
  switch (a) {
    case Act::Linear: return 1.f;
    case Act::Sigmoid: return out * (1.f - out);
    case Act::Tanh: return 1.f - out * out;
    case Act::ReLU: return sum > 0.f ? 1.f : 0.f;
    case Act::LeakyReLU: return sum > 0.f ? 1.f : 0.01f;
    case Act::Step: return std::fabs(sum) < 1.f ? 1.f : 0.f;
  }
  return 1.f;
}

static float sampleLossValue(float o, float t, LossKind l) {
  float d = o - t;
  return l == LossKind::MSE ? d * d : std::fabs(d);
}

// ---------------------------------------------------------------- network
static uint32_t xorshift(uint32_t& s) {
  s ^= s << 13;
  s ^= s >> 17;
  s ^= s << 5;
  return s;
}
static float rand01(uint32_t& s) { return (xorshift(s) & 0xFFFFFF) / 16777216.0f; }

int Network::addNode(Kind kind, float x, float y) {
  Node n;
  n.id = nextId++;
  n.kind = kind;
  n.x = x;
  n.y = y;
  n.act = kind == Kind::Input ? Act::Linear : (kind == Kind::Hidden ? Act::Tanh : Act::Sigmoid);
  nodes.push_back(n);
  dirty_ = true;
  return n.id;
}

int Network::nodeIndex(int id) const {
  for (size_t i = 0; i < nodes.size(); ++i)
    if (nodes[i].id == id) return static_cast<int>(i);
  return -1;
}

int Network::edgeIndex(int fromId, int toId) const {
  for (size_t i = 0; i < edges.size(); ++i)
    if (edges[i].from == fromId && edges[i].to == toId) return static_cast<int>(i);
  return -1;
}

bool Network::removeNode(int id) {
  int idx = nodeIndex(id);
  if (idx < 0) return false;
  edges.erase(std::remove_if(edges.begin(), edges.end(),
                             [id](const Edge& e) { return e.from == id || e.to == id; }),
              edges.end());
  nodes.erase(nodes.begin() + idx);
  dirty_ = true;
  return true;
}

bool Network::removeEdge(int i) {
  if (i < 0 || i >= static_cast<int>(edges.size())) return false;
  edges.erase(edges.begin() + i);
  dirty_ = true;
  return true;
}

bool Network::wouldCycle(int fromId, int toId) const {
  if (fromId == toId) return true;
  // Is `fromId` reachable from `toId`? Then from->to closes a loop.
  std::vector<int> stack{toId};
  std::vector<int> seen;
  while (!stack.empty()) {
    int cur = stack.back();
    stack.pop_back();
    if (cur == fromId) return true;
    if (std::find(seen.begin(), seen.end(), cur) != seen.end()) continue;
    seen.push_back(cur);
    for (const Edge& e : edges)
      if (e.from == cur) stack.push_back(e.to);
  }
  return false;
}

bool Network::connect(int fromId, int toId, std::string* err) {
  uint32_t h = static_cast<uint32_t>(fromId) * 73856093u ^ static_cast<uint32_t>(toId) * 19349663u ^
               static_cast<uint32_t>(edges.size() + 1) * 83492791u;
  if (h == 0) h = 1;
  float w = (rand01(h) * 2.f - 1.f) * 0.8f;
  return connectWithWeight(fromId, toId, w, err);
}

bool Network::connectWithWeight(int fromId, int toId, float w, std::string* err) {
  auto fail = [&](const char* m) {
    if (err) *err = m;
    return false;
  };
  int a = nodeIndex(fromId), b = nodeIndex(toId);
  if (a < 0 || b < 0) return fail("Node not found");
  if (fromId == toId) return fail("Can't connect a node to itself");
  if (nodes[a].kind == Kind::Output) return fail("Outputs can't feed other nodes");
  if (nodes[b].kind == Kind::Input) return fail("Inputs can't receive wires");
  if (edgeIndex(fromId, toId) >= 0) return fail("Already connected");
  if (wouldCycle(fromId, toId)) return fail("That would create a loop");
  Edge e;
  e.from = fromId;
  e.to = toId;
  e.w = w;
  edges.push_back(e);
  dirty_ = true;
  return true;
}

std::vector<int> Network::inputIds() const {
  std::vector<int> v;
  for (const Node& n : nodes)
    if (n.kind == Kind::Input) v.push_back(n.id);
  std::sort(v.begin(), v.end());
  return v;
}
std::vector<int> Network::outputIds() const {
  std::vector<int> v;
  for (const Node& n : nodes)
    if (n.kind == Kind::Output) v.push_back(n.id);
  std::sort(v.begin(), v.end());
  return v;
}

void Network::setInputs(const std::vector<float>& v) {
  std::vector<int> ids = inputIds();
  for (size_t i = 0; i < ids.size() && i < v.size(); ++i) nodes[nodeIndex(ids[i])].input = v[i];
}

std::vector<float> Network::outputs() const {
  std::vector<float> r;
  for (int id : outputIds()) r.push_back(nodes[nodeIndex(id)].value);
  return r;
}

void Network::setInputsRaw(const float* v, size_t n) {
  if (dirty_) rebuild();
  for (size_t i = 0; i < inIdx_.size() && i < n; ++i) nodes[inIdx_[i]].input = v[i];
}
size_t Network::inputCount() {
  if (dirty_) rebuild();
  return inIdx_.size();
}
size_t Network::outputCount() {
  if (dirty_) rebuild();
  return outIdx_.size();
}
float Network::outputValue(size_t k) {
  if (dirty_) rebuild();
  return k < outIdx_.size() ? nodes[outIdx_[k]].value : 0.f;
}

const Node* Network::outputNode(size_t k) {
  if (dirty_) rebuild();
  return k < outIdx_.size() ? &nodes[outIdx_[k]] : nullptr;
}

std::vector<float> Network::getParams() const {
  std::vector<float> p;
  p.reserve(edges.size() + nodes.size());
  for (const Edge& e : edges) p.push_back(e.w);
  for (const Node& n : nodes)
    if (n.kind != Kind::Input) p.push_back(n.bias);
  return p;
}

void Network::setParams(const std::vector<float>& p) {
  size_t k = 0;
  for (Edge& e : edges) {
    if (k >= p.size()) return;
    e.w = p[k++];
  }
  for (Node& n : nodes) {
    if (n.kind == Kind::Input) continue;
    if (k >= p.size()) return;
    n.bias = p[k++];
  }
}

void Network::rebuild() const {
  const size_t n = nodes.size();
  int maxId = 0;
  for (const Node& nd : nodes) maxId = std::max(maxId, nd.id);
  std::vector<int> idToIdx(static_cast<size_t>(maxId) + 1, -1);
  for (size_t i = 0; i < n; ++i) idToIdx[nodes[i].id] = static_cast<int>(i);

  in_.assign(n, {});
  efrom_.assign(edges.size(), -1);
  std::vector<int> indeg(n, 0);
  std::vector<std::vector<int>> out(n);
  for (size_t e = 0; e < edges.size(); ++e) {
    int a = (edges[e].from >= 0 && edges[e].from <= maxId) ? idToIdx[edges[e].from] : -1;
    int b = (edges[e].to >= 0 && edges[e].to <= maxId) ? idToIdx[edges[e].to] : -1;
    if (a < 0 || b < 0) continue;
    in_[b].push_back(static_cast<int>(e));
    efrom_[e] = a;
    out[a].push_back(b);
    indeg[b]++;
  }
  order_.clear();
  std::vector<int> queue;
  for (size_t i = 0; i < n; ++i)
    if (indeg[i] == 0) queue.push_back(static_cast<int>(i));
  for (size_t qi = 0; qi < queue.size(); ++qi) {
    int cur = queue[qi];
    order_.push_back(cur);
    for (int nx : out[cur])
      if (--indeg[nx] == 0) queue.push_back(nx);
  }
  inIdx_.clear();
  outIdx_.clear();
  for (size_t i = 0; i < n; ++i) {
    if (nodes[i].kind == Kind::Input) inIdx_.push_back(static_cast<int>(i));
    if (nodes[i].kind == Kind::Output) outIdx_.push_back(static_cast<int>(i));
  }
  auto byId = [this](int a, int b) { return nodes[a].id < nodes[b].id; };
  std::sort(inIdx_.begin(), inIdx_.end(), byId);
  std::sort(outIdx_.begin(), outIdx_.end(), byId);
  // A cycle can't be created through connect(); if a loaded file has one, the
  // nodes in it are simply left out of the order and keep value 0.
  dirty_ = false;
}

const std::vector<int>& Network::incoming(int nodeIdx) const {
  if (dirty_) rebuild();
  return in_[nodeIdx];
}

void Network::forward() {
  if (dirty_) rebuild();
  for (Node& n : nodes) {
    n.sum = 0.f;
    n.value = 0.f;
  }
  for (int idx : order_) {
    Node& n = nodes[idx];
    if (n.kind == Kind::Input) {
      n.sum = n.input;
      n.value = n.input;
      continue;
    }
    float s = n.bias;
    for (int e : in_[idx]) {
      s += edges[e].w * nodes[efrom_[e]].value;
    }
    n.sum = s;
    n.value = activate(n.act, s);
  }
}

float Network::backward(const std::vector<float>& target, LossKind loss, std::vector<float>& gW,
                        std::vector<float>& gB) {
  if (dirty_) rebuild();
  const size_t n = nodes.size();
  std::vector<float> dv(n, 0.f);
  std::vector<int> outs = outputIds();
  const float nOut = static_cast<float>(std::max<size_t>(1, outs.size()));
  float total = 0.f;
  for (size_t k = 0; k < outs.size(); ++k) {
    int idx = nodeIndex(outs[k]);
    float o = nodes[idx].value;
    float t = k < target.size() ? target[k] : 0.f;
    total += sampleLossValue(o, t, loss) / nOut;
    float d = o - t;
    dv[idx] += (loss == LossKind::MSE ? 2.f * d : (d > 0.f ? 1.f : (d < 0.f ? -1.f : 0.f))) / nOut;
  }
  for (size_t oi = order_.size(); oi-- > 0;) {
    int idx = order_[oi];
    const Node& nd = nodes[idx];
    if (nd.kind == Kind::Input) continue;
    float d = dv[idx] * activateDeriv(nd.act, nd.sum, nd.value);
    gB[idx] += d;
    for (int e : in_[idx]) {
      const Edge& ed = edges[e];
      int p = efrom_[e];
      gW[e] += d * nodes[p].value;
      dv[p] += d * ed.w;
    }
  }
  return total;
}

void Network::randomize(uint32_t seed) {
  uint32_t s = seed ? seed : 1u;
  for (int i = 0; i < 4; ++i) xorshift(s);
  for (Edge& e : edges) {
    int fanOut = 0, fanIn = 0;
    for (const Edge& o : edges) {
      if (o.from == e.from) ++fanOut;
      if (o.to == e.to) ++fanIn;
    }
    float lim = std::sqrt(6.f / static_cast<float>(std::max(1, fanIn + fanOut)));
    e.w = (rand01(s) * 2.f - 1.f) * lim;
  }
  for (Node& n : nodes) n.bias = 0.f;
  forward();
}

void Network::clear() {
  nodes.clear();
  edges.clear();
  nextId = 1;
  dirty_ = true;
}

bool Network::sanitize() {
  bool changed = false;
  for (Edge& e : edges)
    if (!std::isfinite(e.w)) {
      e.w = 0.f;
      changed = true;
    }
  for (Node& n : nodes) {
    if (!std::isfinite(n.bias)) {
      n.bias = 0.f;
      changed = true;
    }
    if (!std::isfinite(n.input)) {
      n.input = 0.f;
      changed = true;
    }
  }
  if (changed) forward();
  return changed;
}

std::string nodeLabel(const Network& net, int nodeIdx) {
  if (nodeIdx < 0 || nodeIdx >= static_cast<int>(net.nodes.size())) return "?";
  const Node& me = net.nodes[nodeIdx];
  int rank = 1;
  for (const Node& o : net.nodes)
    if (o.kind == me.kind && o.id < me.id) ++rank;
  char c = me.kind == Kind::Input ? 'I' : (me.kind == Kind::Hidden ? 'H' : 'O');
  return std::string(1, c) + std::to_string(rank);
}

std::vector<std::string> Network::check() const {
  std::vector<std::string> p;
  bool anyIn = false, anyOut = false;
  for (const Node& n : nodes) {
    anyIn |= n.kind == Kind::Input;
    anyOut |= n.kind == Kind::Output;
  }
  if (!anyIn) p.push_back("Add an Input node");
  if (!anyOut) p.push_back("Add an Output node");
  if (dirty_) rebuild();
  for (size_t i = 0; i < nodes.size(); ++i) {
    const Node& n = nodes[i];
    bool hasOut = false;
    for (const Edge& e : edges)
      if (e.from == n.id) hasOut = true;
    bool hasIn = !in_[i].empty();
    if (n.kind == Kind::Output && !hasIn) p.push_back(nodeLabel(*this, static_cast<int>(i)) + " has no incoming wires");
    if (n.kind == Kind::Hidden && (!hasIn || !hasOut))
      p.push_back(nodeLabel(*this, static_cast<int>(i)) + " isn't fully wired");
    if (n.kind == Kind::Input && !hasOut) p.push_back(nodeLabel(*this, static_cast<int>(i)) + " isn't wired to anything");
  }
  for (const Edge& e : edges)
    if (!std::isfinite(e.w)) {
      p.push_back("A weight is NaN - tap to fix");
      break;
    }
  return p;
}

// ---------------------------------------------------------------- dataset
void Dataset::addRow(size_t nIn, size_t nOut) {
  X.emplace_back(nIn, 0.f);
  Y.emplace_back(nOut, 0.f);
}
void Dataset::removeRow(size_t i) {
  if (i < X.size()) {
    X.erase(X.begin() + i);
    Y.erase(Y.begin() + i);
  }
}
void Dataset::resizeCols(size_t nIn, size_t nOut) {
  for (auto& r : X) r.resize(nIn, 0.f);
  for (auto& r : Y) r.resize(nOut, 0.f);
}

bool datasetCompatible(const Network& n, const Dataset& d, std::string* err) {
  auto fail = [&](const std::string& m) {
    if (err) *err = m;
    return false;
  };
  size_t nIn = n.inputIds().size(), nOut = n.outputIds().size();
  if (nIn == 0 || nOut == 0) return fail("Network needs an input and an output");
  if (d.rows() == 0) return fail("Add at least one training row");
  if (d.Y.size() != d.X.size()) return fail("Dataset rows are uneven");
  for (size_t i = 0; i < d.rows(); ++i)
    if (d.X[i].size() != nIn || d.Y[i].size() != nOut)
      return fail("Data needs " + std::to_string(nIn) + " inputs and " + std::to_string(nOut) + " outputs");
  return true;
}

// ---------------------------------------------------------------- trainer
void Trainer::reset() {
  epochsDone = 0;
  lastLoss = 0.f;
  diverged = false;
  history.clear();
  m_.clear();
  v_.clear();
  step_ = 0;
  paramCount_ = 0;
}

bool Trainer::finished(const TrainerCfg& cfg) const {
  if (diverged) return true;
  if (epochsDone >= cfg.epochs) return true;
  if (cfg.targetLoss > 0.f && epochsDone > 0 && lastLoss <= cfg.targetLoss) return true;
  return false;
}

float Trainer::evaluate(Network& net, const Dataset& data, LossKind loss) {
  if (!datasetCompatible(net, data)) return -1.f;
  std::vector<float> saved;
  for (int id : net.inputIds()) saved.push_back(net.nodes[net.nodeIndex(id)].input);
  float total = 0.f;
  for (size_t i = 0; i < data.rows(); ++i) {
    net.setInputs(data.X[i]);
    net.forward();
    std::vector<float> o = net.outputs();
    float s = 0.f;
    for (size_t k = 0; k < o.size(); ++k) s += sampleLossValue(o[k], data.Y[i][k], loss);
    total += s / static_cast<float>(std::max<size_t>(1, o.size()));
  }
  net.setInputs(saved);
  net.forward();
  return total / static_cast<float>(data.rows());
}

float Trainer::epoch(Network& net, const Dataset& data, const TrainerCfg& cfg) {
  if (!datasetCompatible(net, data)) return -1.f;
  net.forward();  // also rebuilds topology if needed
  const size_t nE = net.edges.size(), nN = net.nodes.size(), P = nE + nN;
  if (P != paramCount_) {
    m_.assign(P, 0.f);
    v_.assign(P, 0.f);
    step_ = 0;
    paramCount_ = P;
  }
  std::vector<float> savedInputs;
  for (int id : net.inputIds()) savedInputs.push_back(net.nodes[net.nodeIndex(id)].input);

  const size_t n = data.rows();
  std::vector<size_t> order(n);
  for (size_t i = 0; i < n; ++i) order[i] = i;
  if (cfg.shuffle)
    for (size_t i = n; i > 1; --i) std::swap(order[i - 1], order[xorshift(rng_) % i]);
  size_t bs = (cfg.batch <= 0 || static_cast<size_t>(cfg.batch) > n) ? n : static_cast<size_t>(cfg.batch);

  float total = 0.f;
  std::vector<float> gW, gB;
  for (size_t start = 0; start < n; start += bs) {
    size_t end = std::min(n, start + bs);
    gW.assign(nE, 0.f);
    gB.assign(nN, 0.f);
    for (size_t k = start; k < end; ++k) {
      size_t i = order[k];
      net.setInputs(data.X[i]);
      net.forward();
      total += net.backward(data.Y[i], cfg.loss, gW, gB);
    }
    const float inv = 1.f / static_cast<float>(end - start);
    ++step_;
    const float b1 = 0.9f, b2 = 0.999f;
    const float c1 = 1.f - std::pow(b1, static_cast<float>(step_));
    const float c2 = 1.f - std::pow(b2, static_cast<float>(step_));
    auto apply = [&](size_t slot, float& p, float g) {
      g *= inv;
      g = std::max(-10.f, std::min(10.f, g));
      switch (cfg.opt) {
        case OptKind::SGD: p -= cfg.lr * g; break;
        case OptKind::Momentum:
          m_[slot] = cfg.momentum * m_[slot] - cfg.lr * g;
          p += m_[slot];
          break;
        case OptKind::Adam: {
          m_[slot] = b1 * m_[slot] + (1.f - b1) * g;
          v_[slot] = b2 * v_[slot] + (1.f - b2) * g * g;
          p -= cfg.lr * (m_[slot] / c1) / (std::sqrt(v_[slot] / c2) + 1e-8f);
          break;
        }
      }
    };
    for (size_t e = 0; e < nE; ++e) apply(e, net.edges[e].w, gW[e]);
    for (size_t i = 0; i < nN; ++i)
      if (net.nodes[i].kind != Kind::Input) apply(nE + i, net.nodes[i].bias, gB[i]);
  }

  float avg = total / static_cast<float>(n);
  bool bad = !std::isfinite(avg);
  for (const Edge& e : net.edges) bad |= !std::isfinite(e.w);
  for (const Node& nd : net.nodes) bad |= !std::isfinite(nd.bias);
  if (bad) diverged = true;

  net.setInputs(savedInputs);
  if (!bad) net.forward();
  lastLoss = avg;
  ++epochsDone;
  if (!bad) history.push_back(avg);  // never chart a diverged run as "zero loss"
  if (history.size() > 4000) {
    std::vector<float> h;
    for (size_t i = 0; i < history.size(); i += 2) h.push_back(history[i]);
    history.swap(h);
  }
  return avg;
}

// ---------------------------------------------------------------- presets
Network makeLayered(const std::vector<int>& sizes, Act hidden, Act out, uint32_t seed) {
  Network net;
  const int L = static_cast<int>(sizes.size());
  std::vector<std::vector<int>> ids(L);
  float x = 60.f;
  for (int l = 0; l < L; ++l) {
    const int n = std::max(0, sizes[l]);
    // Small layers are one column; big ones (images, many sensors) become a square-ish block.
    const int cols = n <= 8 ? 1 : static_cast<int>(std::ceil(std::sqrt(static_cast<float>(n))));
    const int rows = cols > 0 ? (n + cols - 1) / cols : 0;
    const float cell = n <= 8 ? (n > 6 ? 52.f : (n > 4 ? 66.f : 80.f)) : 52.f;
    for (int i = 0; i < n; ++i) {
      int c = i % cols, r = i / cols;
      float px = x + c * cell;
      float py = 220.f + (r - (rows - 1) / 2.f) * cell;
      Kind k = l == 0 ? Kind::Input : (l == L - 1 ? Kind::Output : Kind::Hidden);
      int id = net.addNode(k, px, py);
      if (k == Kind::Hidden) net.nodes[net.nodeIndex(id)].act = hidden;
      if (k == Kind::Output) net.nodes[net.nodeIndex(id)].act = out;
      ids[l].push_back(id);
    }
    x += (cols - 1) * cell + 120.f;
  }
  for (int l = 0; l + 1 < L; ++l)
    for (int a : ids[l])
      for (int b : ids[l + 1]) net.connect(a, b);
  net.randomize(seed);
  return net;
}

static Dataset rowsOf(const std::vector<std::vector<float>>& x, const std::vector<std::vector<float>>& y) {
  Dataset d;
  d.X = x;
  d.Y = y;
  return d;
}

static void showFirstRow(Preset& p) {
  if (p.data.rows()) p.net.setInputs(p.data.X[0]);
  p.net.forward();
}

std::vector<TrainerCfg> builtinTrainers() {
  std::vector<TrainerCfg> v;
  TrainerCfg a;
  a.name = "Adam (fast)";
  a.opt = OptKind::Adam;
  a.lr = 0.05f;
  a.epochs = 2000;
  v.push_back(a);
  TrainerCfg b;
  b.name = "Gentle SGD";
  b.opt = OptKind::SGD;
  b.lr = 0.3f;
  b.epochs = 5000;
  b.targetLoss = 0.0005f;
  v.push_back(b);
  TrainerCfg c;
  c.name = "Momentum";
  c.opt = OptKind::Momentum;
  c.lr = 0.05f;
  c.momentum = 0.9f;
  c.epochs = 3000;
  v.push_back(c);
  TrainerCfg d;
  d.name = "Slow & careful";
  d.opt = OptKind::Adam;
  d.lr = 0.01f;
  d.epochs = 8000;
  d.batch = 4;
  v.push_back(d);
  return v;
}

std::vector<Preset> builtinPresets() {
  std::vector<Preset> v;
  {
    Preset p;
    p.name = "XOR";
    p.desc = "Classic puzzle: 1 only if exactly one input is 1. Needs a hidden layer.";
    p.net = makeLayered({2, 4, 1}, Act::Tanh, Act::Sigmoid, 7);
    p.data = rowsOf({{0, 0}, {0, 1}, {1, 0}, {1, 1}}, {{0}, {1}, {1}, {0}});
    p.cfg.name = "XOR trainer";
    p.cfg.lr = 0.05f;
    p.cfg.epochs = 2500;
    p.cfg.targetLoss = 0.001f;
    showFirstRow(p);
    v.push_back(p);
  }
  {
    Preset p;
    p.name = "AND gate";
    p.desc = "One neuron is enough: 1 only when both inputs are 1.";
    p.net = makeLayered({2, 1}, Act::Tanh, Act::Sigmoid, 3);
    p.data = rowsOf({{0, 0}, {0, 1}, {1, 0}, {1, 1}}, {{0}, {0}, {0}, {1}});
    p.cfg.name = "Gate trainer";
    p.cfg.lr = 0.2f;
    p.cfg.epochs = 1500;
    p.cfg.targetLoss = 0.002f;
    showFirstRow(p);
    v.push_back(p);
  }
  {
    Preset p;
    p.name = "OR gate";
    p.desc = "1 when at least one input is 1.";
    p.net = makeLayered({2, 1}, Act::Tanh, Act::Sigmoid, 5);
    p.data = rowsOf({{0, 0}, {0, 1}, {1, 0}, {1, 1}}, {{0}, {1}, {1}, {1}});
    p.cfg.name = "Gate trainer";
    p.cfg.lr = 0.2f;
    p.cfg.epochs = 1500;
    p.cfg.targetLoss = 0.002f;
    showFirstRow(p);
    v.push_back(p);
  }
  {
    Preset p;
    p.name = "Half adder";
    p.desc = "Two outputs: the sum bit (XOR) and the carry bit (AND).";
    p.net = makeLayered({2, 4, 2}, Act::Tanh, Act::Sigmoid, 11);
    p.data = rowsOf({{0, 0}, {0, 1}, {1, 0}, {1, 1}}, {{0, 0}, {1, 0}, {1, 0}, {0, 1}});
    p.cfg.name = "Adder trainer";
    p.cfg.lr = 0.05f;
    p.cfg.epochs = 3000;
    p.cfg.targetLoss = 0.001f;
    showFirstRow(p);
    v.push_back(p);
  }
  {
    Preset p;
    p.name = "Line fit";
    p.desc = "Learn y = 0.5x + 0.2 with a single linear neuron.";
    p.net = makeLayered({1, 1}, Act::Linear, Act::Linear, 13);
    for (int i = 0; i <= 10; ++i) {
      float x = i / 10.f;
      p.data.X.push_back({x});
      p.data.Y.push_back({0.5f * x + 0.2f});
    }
    p.cfg.name = "Line trainer";
    p.cfg.opt = OptKind::SGD;
    p.cfg.lr = 0.2f;
    p.cfg.epochs = 3000;
    p.cfg.targetLoss = 0.00001f;
    showFirstRow(p);
    v.push_back(p);
  }
  {
    Preset p;
    p.name = "Sine wave";
    p.desc = "Curve fitting: 8 hidden neurons learn one sine cycle.";
    p.net = makeLayered({1, 8, 1}, Act::Tanh, Act::Sigmoid, 17);
    for (int i = 0; i <= 14; ++i) {
      float x = i / 14.f;
      p.data.X.push_back({x});
      p.data.Y.push_back({0.5f + 0.4f * std::sin(6.2831853f * x)});
    }
    p.cfg.name = "Curve trainer";
    p.cfg.lr = 0.02f;
    p.cfg.epochs = 6000;
    p.cfg.targetLoss = 0.0003f;
    showFirstRow(p);
    v.push_back(p);
  }
  return v;
}

// ---------------------------------------------------------------- serialization
static std::string cleanName(std::string s) {
  for (char& c : s)
    if (c == '\n' || c == '\r' || c == '\t' || c == '|') c = ' ';
  return s;
}
static std::string fnum(float f) {
  if (!std::isfinite(f)) f = 0.f;  // a NaN in a save file would make the whole file unreadable
  char b[40];
  std::snprintf(b, sizeof b, "%.9g", static_cast<double>(f));
  return b;
}

std::string fnumStr(float f) { return fnum(f); }

std::string serializePreset(const Preset& p) {
  std::string s = "NODELAB 1\n";
  s += "name " + cleanName(p.name) + "\n";
  s += "desc " + cleanName(p.desc) + "\n";
  for (const Node& n : p.net.nodes)
    s += "node " + std::to_string(n.id) + " " + std::to_string(static_cast<int>(n.kind)) + " " +
         std::to_string(static_cast<int>(n.act)) + " " + fnum(n.bias) + " " + fnum(n.input) + " " + fnum(n.x) + " " +
         fnum(n.y) + "\n";
  for (const Edge& e : p.net.edges)
    s += "edge " + std::to_string(e.from) + " " + std::to_string(e.to) + " " + fnum(e.w) + "\n";
  for (size_t i = 0; i < p.data.rows(); ++i) {
    s += "row";
    for (float f : p.data.X[i]) s += " " + fnum(f);
    s += " ;";
    for (float f : p.data.Y[i]) s += " " + fnum(f);
    s += "\n";
  }
  const TrainerCfg& c = p.cfg;
  s += "trainer " + cleanName(c.name) + "|" + std::to_string(static_cast<int>(c.opt)) + "|" +
       std::to_string(static_cast<int>(c.loss)) + "|" + fnum(c.lr) + "|" + fnum(c.momentum) + "|" +
       std::to_string(c.epochs) + "|" + std::to_string(c.batch) + "|" + (c.shuffle ? "1" : "0") + "|" +
       fnum(c.targetLoss) + "\n";
  s += "END\n";
  return s;
}

static std::vector<std::string> splitLines(const std::string& t) {
  std::vector<std::string> out;
  std::string cur;
  for (char c : t) {
    if (c == '\n') {
      out.push_back(cur);
      cur.clear();
    } else if (c != '\r') {
      cur += c;
    }
  }
  if (!cur.empty()) out.push_back(cur);
  return out;
}

static std::vector<std::string> splitBar(const std::string& s) {
  std::vector<std::string> out;
  std::string cur;
  for (char c : s) {
    if (c == '|') {
      out.push_back(cur);
      cur.clear();
    } else {
      cur += c;
    }
  }
  out.push_back(cur);
  return out;
}

static bool parseTrainer(const std::string& body, TrainerCfg& c) {
  std::vector<std::string> f = splitBar(body);
  if (f.size() < 9) return false;
  c.name = f[0];
  int o = std::atoi(f[1].c_str()), l = std::atoi(f[2].c_str());
  if (o < 0 || o > 2 || l < 0 || l > 1) return false;
  c.opt = static_cast<OptKind>(o);
  c.loss = static_cast<LossKind>(l);
  c.lr = static_cast<float>(std::atof(f[3].c_str()));
  c.momentum = static_cast<float>(std::atof(f[4].c_str()));
  c.epochs = std::atoi(f[5].c_str());
  c.batch = std::atoi(f[6].c_str());
  c.shuffle = f[7] == "1";
  c.targetLoss = static_cast<float>(std::atof(f[8].c_str()));
  if (c.epochs < 1 || c.batch < 0 || !std::isfinite(c.lr) || !std::isfinite(c.momentum) ||
      !std::isfinite(c.targetLoss))
    return false;
  return true;
}

bool deserializePreset(const std::string& text, Preset& out, std::string* err) {
  auto fail = [&](const std::string& m) {
    if (err) *err = m;
    return false;
  };
  std::vector<std::string> lines = splitLines(text);
  if (lines.empty() || lines[0].compare(0, 8, "NODELAB ") != 0) return fail("Not a NodeLab file");
  Preset p;
  int maxId = 0;
  for (size_t li = 1; li < lines.size(); ++li) {
    const std::string& ln = lines[li];
    if (ln == "END") break;
    if (ln.compare(0, 5, "name ") == 0) {
      p.name = ln.substr(5);
    } else if (ln.compare(0, 5, "desc ") == 0) {
      p.desc = ln.substr(5);
    } else if (ln.compare(0, 5, "node ") == 0) {
      std::istringstream is(ln.substr(5));
      is.imbue(std::locale::classic());
      Node n;
      int k = 0, a = 0;
      if (!(is >> n.id >> k >> a >> n.bias >> n.input >> n.x >> n.y)) return fail("Bad node line");
      if (k < 0 || k > 2 || a < 0 || a > 5) return fail("Bad node values");
      if (n.id < 1 || n.id > 1000000) return fail("Bad node id");
      for (const Node& o : p.net.nodes)
        if (o.id == n.id) return fail("Duplicate node id");
      n.kind = static_cast<Kind>(k);
      n.act = static_cast<Act>(a);
      maxId = std::max(maxId, n.id);
      p.net.nodes.push_back(n);
    } else if (ln.compare(0, 5, "edge ") == 0) {
      std::istringstream is(ln.substr(5));
      is.imbue(std::locale::classic());
      Edge e;
      if (!(is >> e.from >> e.to >> e.w)) return fail("Bad edge line");
      p.net.edges.push_back(e);
    } else if (ln.compare(0, 4, "row ") == 0) {
      std::istringstream is(ln.substr(4));
      is.imbue(std::locale::classic());
      std::vector<float> x, y;
      std::string tok;
      bool afterSemi = false;
      while (is >> tok) {
        if (tok == ";") {
          afterSemi = true;
          continue;
        }
        float f = static_cast<float>(std::atof(tok.c_str()));
        (afterSemi ? y : x).push_back(f);
      }
      p.data.X.push_back(x);
      p.data.Y.push_back(y);
    } else if (ln.compare(0, 8, "trainer ") == 0) {
      if (!parseTrainer(ln.substr(8), p.cfg)) return fail("Bad trainer line");
    }
  }
  // Drop edges that point at missing nodes so the engine never sees them.
  p.net.nextId = maxId + 1;
  p.net.edges.erase(std::remove_if(p.net.edges.begin(), p.net.edges.end(),
                                   [&](const Edge& e) {
                                     return p.net.nodeIndex(e.from) < 0 || p.net.nodeIndex(e.to) < 0;
                                   }),
                    p.net.edges.end());
  p.net.forward();
  out = p;
  return true;
}

std::string serializePresets(const std::vector<Preset>& v) {
  std::string s;
  for (const Preset& p : v) s += serializePreset(p);
  return s;
}

std::vector<Preset> deserializePresets(const std::string& text) {
  std::vector<Preset> out;
  std::vector<std::string> lines = splitLines(text);
  std::string block;
  for (const std::string& ln : lines) {
    block += ln + "\n";
    if (ln == "END") {
      Preset p;
      if (deserializePreset(block, p)) out.push_back(p);
      block.clear();
    }
  }
  return out;
}

std::string serializeTrainers(const std::vector<TrainerCfg>& v) {
  std::string s;
  for (const TrainerCfg& c : v) {
    s += "trainer " + cleanName(c.name) + "|" + std::to_string(static_cast<int>(c.opt)) + "|" +
         std::to_string(static_cast<int>(c.loss)) + "|" + fnum(c.lr) + "|" + fnum(c.momentum) + "|" +
         std::to_string(c.epochs) + "|" + std::to_string(c.batch) + "|" + (c.shuffle ? "1" : "0") + "|" +
         fnum(c.targetLoss) + "\n";
  }
  return s;
}

std::vector<TrainerCfg> deserializeTrainers(const std::string& text) {
  std::vector<TrainerCfg> out;
  for (const std::string& ln : splitLines(text)) {
    if (ln.compare(0, 8, "trainer ") != 0) continue;
    TrainerCfg c;
    if (parseTrainer(ln.substr(8), c)) out.push_back(c);
  }
  return out;
}

}  // namespace nl
